import concurrent.futures
import hashlib
import json
import shutil
import sys
import xml.etree.ElementTree as ET
from datetime import datetime, timezone
from pathlib import Path
from backend_inventory import source_paths

base=Path(__file__).resolve().parent
root=base.parents[3]
label,key=sys.argv[1:]
assert label in {'metadata-A','metadata-B'} and key in {'A','B'}
requirements=json.loads((base/'required-targets.json').read_text(encoding='utf-8'))
manifest=json.loads((base/'source-input.json').read_text(encoding='utf-8-sig'))
inventory=json.loads((base/'complete-input-inventory.json').read_text(encoding='utf-8-sig'))
execution=json.loads((base/(label+'-execution.json')).read_text(encoding='utf-8-sig'))
assert execution['state']=='completed' and execution['actualExitCode'] is not None
assert execution['sourceAggregateSha256']==manifest['aggregateSha256']==requirements['source']
assert inventory['primaryDeclaredSourceAggregateSha256']==manifest['aggregateSha256']
primary={entry['path']:entry['sha256'] for entry in manifest['files']}
assert len(primary)==len(manifest['files'])
def aggregate(files):
    return hashlib.sha256(''.join(path+'\0'+files[path]+'\n' for path in sorted(files)).encode('utf-8')).hexdigest()
assert aggregate(primary)==manifest['aggregateSha256']
supplemental={entry['path']:entry['sha256'] for entry in inventory['supplementalFiles']}
assert len(supplemental)==len(inventory['supplementalFiles']) and not set(primary)&set(supplemental)
assert set(primary)|set(supplemental)==set(inventory['inventoryPaths'])
assert aggregate({**primary,**supplemental})==inventory['completeInputInventoryAggregateSha256']
required=requirements['groups'][key]['classes']
assert execution['selection'].split(',')==required

def check(entry):
    path=root/entry['path']
    actual=hashlib.sha256(path.read_bytes()).hexdigest() if path.is_file() else None
    return {'path':entry['path'],'expected':entry['sha256'],'actual':actual} if actual!=entry['sha256'] else None
actual_paths=source_paths(root)
expected_paths=set(inventory['inventoryPaths'])
assert actual_paths==expected_paths,{'sourceAdded':sorted(actual_paths-expected_paths),'sourceRemoved':sorted(expected_paths-actual_paths)}
with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
    drift=[entry for entry in pool.map(check,manifest['files']+inventory['supplementalFiles']) if entry is not None]
if drift:
    raise SystemExit(json.dumps({'sourceDrift':drift},ensure_ascii=False))

directory=base/(label+'-receipt')
reports=sorted(directory.glob('TEST-*.xml'))
classes=[]
ledger=[]
for path in reports:
    suite=ET.parse(path).getroot()
    assert int(suite.attrib['tests'])>0,'A required class cannot pass with zero executed tests: '+path.name
    classes.append(suite.attrib['name'].rsplit('.',1)[-1])
    local=[]
    for case in suite.findall('testcase'):
        failure=case.find('failure')
        error=case.find('error')
        skipped=case.find('skipped')
        status='failed' if failure is not None else 'error' if error is not None else 'skipped' if skipped is not None else 'passed'
        local.append({'class':case.attrib['classname'],'case':case.attrib['name'],'status':status,
                      'message':failure.attrib.get('message') if failure is not None else error.attrib.get('message') if error is not None else None})
    assert len(local)==int(suite.attrib['tests']),path.name
    assert sum(c['status']=='failed' for c in local)==int(suite.attrib['failures']),path.name
    assert sum(c['status']=='error' for c in local)==int(suite.attrib['errors']),path.name
    assert sum(c['status']=='skipped' for c in local)==int(suite.attrib['skipped']),path.name
    ledger.extend(local)
assert len(classes)==len(set(classes)) and set(classes)==set(required),(classes,required)
counts={name:sum(case['status']==status for case in ledger)
        for name,status in [('passed','passed'),('failed','failed'),('errors','error'),('skipped','skipped')]}
keys=[(case['class'],case['case']) for case in ledger]
assert len(keys)==len(set(keys)),'Duplicate class+case keys within one run'
if key=='B':
    measured=[case for case in ledger if case['case']=='aRealDraftOnPageElevenIsNotTruncatedOrExpandedIntoDetails']
    assert len(measured)==1 and measured[0]['status']=='passed'
    sample_path=root/'server/build/loading-validation/daily-report-draft-claims/current-task-service-comparison.json'
    started=datetime.fromisoformat(execution['startedAtUtc'].replace('Z','+00:00')).timestamp()
    completed=datetime.fromisoformat(execution['completedAtUtc'].replace('Z','+00:00')).timestamp()
    assert started<=sample_path.stat().st_mtime<=completed,'The producer sample must be written within this actual run'
    sample=json.loads(sample_path.read_text(encoding='utf-8'))
    assert sample['activeDraftHeaders']==1001 and sample['acceptedTaskSegments']==1
    assert sample['globalHeaderBatches']==11 and sample['selectedHeaderBatches']==1
    assert sample['sameRealDraftClaimRetained'] is True
    shutil.copy2(sample_path,directory/sample_path.name)
    (directory/'current-task-service-comparison-provenance.json').write_text(json.dumps({
        'sourceAggregateSha256':manifest['aggregateSha256'],
        'completeInputInventoryAggregateSha256':inventory['completeInputInventoryAggregateSha256'],
        'qualifiedCase':measured[0],
        'actualRunLabel':label,'actualNativeExitCode':execution['actualExitCode'],
        'sampleSha256':hashlib.sha256(sample_path.read_bytes()).hexdigest(),
        'scope':'One original maker-limited current-subject service fixture, actual Spring public service/RR/JDBC. HTTP/JWT/native-publication/client actions-ready latency is not included. Independent actual ordinary-principal HTTP and revocation cases remain in this same run ledger. No production SLA or arithmetic combination with older samples.',
    },ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
artifacts=[]
for path in sorted(directory.iterdir()):
    if path.is_file() and path.name!='seal.json':
        artifacts.append({'path':str(path.relative_to(root)).replace('\\','/'),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
receipt={'sealedAtUtc':datetime.now(timezone.utc).isoformat(),'label':label,
         'sourceAggregateSha256':manifest['aggregateSha256'],'primarySourceFilesChecked':len(manifest['files']),
         'completeInputInventoryAggregateSha256':inventory['completeInputInventoryAggregateSha256'],
         'sourceFilesChecked':len(expected_paths),'sourceAdded':[],'sourceRemoved':[],
         'upstreamMainHead':manifest['upstreamMainHead'],'candidateHead':manifest['candidateHead'],
         'sourceDrift':[],'executionState':execution['state'],'actualExitCode':execution['actualExitCode'],
         'classes':len(classes),'tests':len(ledger),'counts':counts,
         'allRequiredClassesPresent':True,
         'green':execution['actualExitCode']==0 and counts['failed']==counts['errors']==counts['skipped']==0,
         'caseLedger':ledger,'artifacts':artifacts,
         'scope':requirements['groups'][key]['reason'],
         'historicalResultsExcluded':True}
(directory/'seal.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({key:receipt[key] for key in ['label','sourceAggregateSha256','actualExitCode','classes','tests','counts','green']}))
