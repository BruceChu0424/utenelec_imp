import concurrent.futures
import hashlib
import json
from pathlib import Path

base=Path(__file__).resolve().parent
root=base.parents[3]
manifest=json.loads((base/'source-input.json').read_text(encoding='utf-8-sig'))
prefix='server/src/main/resources/db/migration/'
sources={entry['path'][len(prefix):]:entry['sha256'] for entry in manifest['files'] if entry['path'].startswith(prefix)}
compiled=root/'server/target-loading-main-f6e-metadata/classes/db/migration'
actual={path.name:path for path in compiled.glob('V*.sql')}
assert len(sources)==len(actual)==1003
assert set(sources)==set(actual)
def inspect(name):
    digest=hashlib.sha256(actual[name].read_bytes()).hexdigest()
    assert digest==sources[name],name
    return {'name':name,'sha256':digest}
with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
    artifacts=list(pool.map(inspect,sorted(sources)))
receipt={'sourceAggregateSha256':manifest['aggregateSha256'],'compiledTarget':'server/target-loading-main-f6e-metadata',
         'migrationCount':1003,'maximumMigrationVersion':1064,'compiledMissing':[],'compiledExtra':[],'compiledSourceMismatches':[],
         'schemaMinimum':1061,'mappingVersion':'bootstrap-v22','resources':artifacts}
(base/'compiled-migration-resources.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'compiledMigrations':1003,'sourceMismatches':0,'missing':0,'extra':0}))
