import hashlib
import json
import shutil
import xml.etree.ElementTree as ET
from datetime import datetime, timezone
from pathlib import Path

base=Path(__file__).resolve().parent
root=base.parents[3]
source=json.loads((base/'source-input.json').read_text(encoding='utf-8-sig'))
inventory=json.loads((base/'complete-input-inventory.json').read_text(encoding='utf-8'))
execution=json.loads((base/'metadata-B-execution.json').read_text(encoding='utf-8-sig'))
xml=root/'server/target-loading-main-f6e-metadata/surefire-reports/TEST-com.uten.imp.businesschain.DailyReportDraftClaimsPostgresTest.xml'
suite=ET.parse(xml).getroot()
assert int(suite.attrib['tests'])==10 and all(int(suite.attrib[name])==0 for name in ['failures','errors','skipped'])
case=[case for case in suite.findall('testcase') if case.attrib['name']=='aRealDraftOnPageElevenIsNotTruncatedOrExpandedIntoDetails']
assert len(case)==1 and not any(case[0].find(tag) is not None for tag in ['failure','error','skipped'])
sample=root/'server/build/loading-validation/daily-report-draft-claims/current-task-service-comparison.json'
assert sample.stat().st_mtime>=datetime.fromisoformat(execution['startedAtUtc'].replace('Z','+00:00')).timestamp()
output=base/'current-source-claims-sample'
output.mkdir(exist_ok=False)
for path in [sample,xml]:
    shutil.copy2(path,output/path.name)
provenance={'capturedAtUtc':datetime.now(timezone.utc).isoformat(),
            'sourceAggregateSha256':source['aggregateSha256'],
            'completeInputInventoryAggregateSha256':inventory['completeInputInventoryAggregateSha256'],
            'measuredCase':case[0].attrib,'wholeClass':{'tests':10,'passed':10,'failed':0,'errors':0,'skipped':0},
            'actualRunSnapshot':execution,'wholeBRunComplete':execution['state']=='completed',
            'sampleSha256':hashlib.sha256(sample.read_bytes()).hexdigest(),
            'xmlSha256':hashlib.sha256(xml.read_bytes()).hexdigest(),
            'scope':'Actual public service sample under original maker-limited subject; not HTTP/JWT/native-publication or client latency. Class10 is green; full B native outcome remains separately required. Older a5ed sample remains separately sealed and is not relabelled current.',
            'previousMeasuredSource':'a5ed5b7a883891d58f7402daa0056a376f5aa95378f7bd4891485f64f491ff48',
            'previousSealedSample':'server/build/loading-validation/main-f6e-scoped/draft-scoped-pg-receipt/current-task-service-comparison.json'}
(output/'provenance.json').write_text(json.dumps(provenance,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'source':source['aggregateSha256'],'classTests':10,'classPassed':10,'wholeBComplete':provenance['wholeBRunComplete'],'sampleSha256':provenance['sampleSha256']}))
