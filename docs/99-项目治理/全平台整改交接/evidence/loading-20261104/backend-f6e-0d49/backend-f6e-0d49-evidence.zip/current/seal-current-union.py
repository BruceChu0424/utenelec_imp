import hashlib
import json
from pathlib import Path

base=Path(__file__).resolve().parent
root=base.parents[3]
requirements=json.loads((base/'required-targets.json').read_text(encoding='utf-8'))
source=json.loads((base/'source-input.json').read_text(encoding='utf-8-sig'))
inventory=json.loads((base/'complete-input-inventory.json').read_text(encoding='utf-8'))
receipts=[]
ledger={}
for group in ['A','B']:
    path=base/('metadata-'+group+'-receipt/seal.json')
    receipt=json.loads(path.read_text(encoding='utf-8'))
    assert receipt['green'] is True and receipt['executionState']=='completed' and receipt['actualExitCode']==0
    assert all(receipt['counts'][name]==0 for name in ['failed','errors','skipped'])
    assert receipt['sourceAggregateSha256']==requirements['source']==source['aggregateSha256']
    assert receipt['completeInputInventoryAggregateSha256']==inventory['completeInputInventoryAggregateSha256']
    assert receipt['sourceDrift']==receipt['sourceAdded']==receipt['sourceRemoved']==[]
    assert receipt['classes']==len(requirements['groups'][group]['classes'])
    assert receipt['tests']>0
    for case in receipt['caseLedger']:
        assert case['status']=='passed'
        key=(case['class'],case['case'])
        assert key not in ledger,key
        ledger[key]={'class':case['class'],'case':case['case'],'status':'passed','receipt':group}
    receipts.append({'group':group,'path':str(path.relative_to(root)).replace('\\','/'),
                     'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'classes':receipt['classes'],'tests':receipt['tests']})
classes={case['class'].rsplit('.',1)[-1] for case in ledger.values()}
assert classes==set(requirements['groups']['A']['classes'])|set(requirements['groups']['B']['classes'])
assert len(classes)==47
growth=[]
for path in sorted((base/'metadata-A-growth').glob('*.json')):
    sample=json.loads(path.read_text(encoding='utf-8'))
    assert sample['fixedActiveRows']==50 and sample['historicalRows'] in [10000,100000,1000000]
    assert sample['before']['samples']==sample['after']['samples']==3
    growth.append({'scenario':sample['scenario'],'history':sample['historicalRows'],
                   'path':str(path.relative_to(root)).replace('\\','/'),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
assert len(growth)==len({(row['scenario'],row['history']) for row in growth})==6
result={'sourceAggregateSha256':source['aggregateSha256'],
        'completeInputInventoryAggregateSha256':inventory['completeInputInventoryAggregateSha256'],
        'primaryFiles':7000,'completeInputPaths':7354,'upstreamMainHead':source['upstreamMainHead'],
        'candidateHead':source['candidateHead'],'freshCompiledMain':3204,'freshCompiledTests':2561,
        'migrationCount':1003,'maximumMigrationVersion':1064,'legacyMinSchema':1061,'mappingVersion':'bootstrap-v22',
        'requiredJavaClasses':47,'uniqueJavaTests':len(ledger),'javaFailed':0,'javaErrors':0,'javaSkipped':0,
        'allRequiredJavaGreen':True,'receipts':receipts,'caseLedger':sorted(ledger.values(),key=lambda row:(row['class'],row['case'])),
        'growth':growth,'growthScope':'Six disposable structural fixtures, fixed active50/history10k100k1m, three warm observations; exact broad statistics remain N and this is not a production SLA.',
        'legacyCoveragePath':'server/build/loading-validation/main-f6e-metadata/legacy-qualified-case-coverage.json',
        'legacyCaveat':'Private PostgreSQL18 whole run passed. Focused67 native run remains exit1/66pass1launcher CreateProcessError; exact original CLI case rerun passed with the established executable launcher. Qualified85 case coverage is not a whole85-green run or full684 discovery green.',
        'historical377':'Original058da source result remains historical and separate. No addition of old143/348/55/195/377 or diagnostic matrix counts to this current Java ledger.',
        'performanceScopeNotes':'server/build/loading-validation/main-f6e-metadata/performance-scope-notes.json',
        'companyDbWritten':False,'mainWrittenByBackend':False,'published':False}
(base/'backend-current-acceptance.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({key:result[key] for key in ['sourceAggregateSha256','requiredJavaClasses','uniqueJavaTests','javaFailed','javaErrors','javaSkipped']}))
