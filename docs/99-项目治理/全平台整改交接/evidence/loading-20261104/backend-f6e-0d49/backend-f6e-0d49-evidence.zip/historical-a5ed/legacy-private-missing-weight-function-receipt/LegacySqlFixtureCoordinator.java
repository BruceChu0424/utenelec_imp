import com.fasterxml.jackson.databind.ObjectMapper;
import java.nio.file.*;
import java.util.*;
import org.testcontainers.postgresql.PostgreSQLContainer;

/** Ignored coordinator. Real immutable Testcontainers identity, nonce label and rollback-only Python guard. */
public class LegacySqlFixtureCoordinator {
    public static void main(String[] arguments) throws Exception {
        String nonce=UUID.randomUUID().toString();
        String database="legacy_bootstrap_f6e_loading";
        int exit;
        var proof=new LinkedHashMap<String,Object>();
        try(var postgres=new PostgreSQLContainer("postgres:16-alpine").withDatabaseName(database)
                .withUsername("fixture_admin").withPassword(UUID.randomUUID().toString())
                .withLabel("uten.imp.legacy.fixture",nonce)) {
            postgres.start();
            String python="C:/Program Files/LibreOffice/program/python.exe";
            String code="import sys,os,unittest;sys.path.insert(0,os.getcwd());sys.executable="+new ObjectMapper().writeValueAsString(python)
                    +";suite=unittest.TestSuite(unittest.defaultTestLoader.loadTestsFromName(name) for name in "
                    +"['test_legacy_bom_disabled_components','test_rehearsal_stock_checks']);"
                    +"r=unittest.TextTestRunner(verbosity=2).run(suite);sys.exit(0 if r.wasSuccessful() else 1)";
            Path runner=Path.of("build/loading-validation/main-f6e-scoped/legacy-private-16-runner.py").toAbsolutePath();
            Files.writeString(runner,code+"\n");
            var process=new ProcessBuilder(python,runner.toString()).directory(Path.of("legacy_migration").toFile())
                    .redirectErrorStream(true).inheritIO();
            var environment=process.environment();
            environment.put("UTEN_LEGACY_TEST_PG_CONTAINER",postgres.getContainerId());
            environment.put("UTEN_LEGACY_TEST_PG_DATABASE",database);
            environment.put("UTEN_LEGACY_TEST_PG_USER","fixture_admin");
            environment.put("UTEN_LEGACY_TEST_PG_NONCE",nonce);
            environment.put("PYTHONIOENCODING","utf-8");
            proof.put("containerId",postgres.getContainerId());proof.put("nonce",nonce);proof.put("database",database);
            proof.put("user","fixture_admin");proof.put("modules",List.of("test_legacy_bom_disabled_components","test_rehearsal_stock_checks"));
            proof.put("scope","Real private Testcontainers, original safety gate and BEGIN/ROLLBACK fixtures; no product or company database writes");
            exit=process.start().waitFor();proof.put("pythonActualExitCode",exit);
        }
        proof.put("containerNaturallyClosed",true);
        var destination=Path.of("build/loading-validation/main-f6e-scoped/legacy-private-16-receipt.json");
        new ObjectMapper().writerWithDefaultPrettyPrinter().writeValue(destination.toFile(),proof);
        if(exit!=0)throw new IllegalStateException("Private legacy SQL fixtures failed: "+exit);
    }
}
