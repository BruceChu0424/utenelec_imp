import json
from pathlib import Path

base=Path(__file__).resolve().parent
old=base.parent/'main-f6e-scoped/run-suite.ps1'
runner=old.read_text(encoding='utf-8-sig').replace('main-f6e-scoped','main-f6e-metadata')
(base/'run-suite.ps1').write_text(runner,encoding='utf-8',newline='\n')
a=[
    'ArchitectureBoundaryTest','DailyReportDraftClaimsJsonTest','ProductionExecutionWorkbenchQuantityExactJsonTest',
    'ProductionDraftClaimsReadRoutesTest','ExactBodyReadRoutesTest','NativeTaskReadScopeInterceptorTest',
    'DailyReportExactQuantityJsonTest','ProductionDailyReportControllerBatchFilterTest','ProductionDailyReportCommandTest',
    'FulfillmentWorkbenchPageReadTest','FulfillmentWorkbenchPageReadPostgresTest','FulfillmentWorkbenchQueryServiceTest',
    'FulfillmentWorkbenchEmptyPageLatencyPostgresTest','FulfillmentWorkbenchTaskAudiencePostgresTest',
    'FulfillmentWorkbenchProvisionalStockPostgresTest','WarehouseTaskPageMetadataPostgresTest',
    'InteractiveTaskReadScopePostgresTest','ProductionExecutionWorkbenchQueryPostgresTest',
    'DirectMakeDeliveryClosedCreditPostgresTest','FinancialSubversionAuditPolicyForwardPostgresTest',
    'SalesShipmentOrderMoneySnapshotTest','ShipmentReceivableFilterAdapterTest','ShipmentReceivablePositionAdapterTest',
    'ShipmentReceivablePositionConsumerTest','SalesFinanceSnapshotIsolationContractTest','ReceiptSourcePermissionContractTest',
    'FinancePartyReferenceLabelsAdapterTest','OrderListEmployeeProjectionTest',
]
b=(base.parent/'combined-integration-selection.txt').read_text(encoding='utf-8-sig').strip().split(',')
b=[name for name in b if name not in {'ArchitectureBoundaryTest','ProductionExecutionWorkbenchQueryPostgresTest'}]
b+=['DailyReportDraftClaimsPostgresTest','ReceiptExplicitOrderAttributionPostgresTest','ReceiptExplicitOrderLifecyclePostgresTest',
    'FinanceDocumentPartyReferenceHttpPostgresTest','ProcurementFirstPayablePostgresTest']
assert not set(a)&set(b)
assert len(a)==len(set(a))==28 and len(b)==len(set(b))==19
for label,selection in [('A',a),('B',b)]:
    (base/('selection-'+label+'.txt')).write_text(','.join(selection)+'\n',encoding='utf-8')
(base/'required-targets.json').write_text(json.dumps({
    'source':'0d49fabceb36b97e6c871ab47762231f59bf4533e1bbdb46deab690c75377bbb',
    'execution':'One frozen compiled target; groups run sequentially to avoid competing growth samples or target/report/cache writes.',
    'groups':{'A':{'classes':a,'reason':'Current API/body classifiers, original-MATERIALIZED metadata SQL and facets/null/department guards, warehouse/current-workshop/JIT/closed-MAKE restoration, Main audit migration and affected money/employee read projections.'},
              'B':{'classes':b,'reason':'Real ten-case draft HTTP/service ownership/revocation/proofs, finance reverse actual transactions, affected sales/shipment/legacy-quantity/source chains and newly composed Main receipt attribution/lifecycle/reference authority.'}},
    'historical377':'Remains the original 058da source result; no broad-current377 or full-project green claim. Untouched paths require explicit input-closure applicability, never arithmetic addition.',
},indent=2)+'\n',encoding='utf-8')
print(json.dumps({'A':len(a),'B':len(b),'classUnion':len(set(a+b))}))
