package com.uten.imp.businesschain;

import com.uten.imp.common.time.BusinessTime;
import com.uten.imp.features.documents.DocumentUnapprovalService;
import com.uten.imp.features.common.taskclaim.TaskClaimService;
import com.uten.imp.features.finance.procurement.ProcurementFinanceApprovalService;
import com.uten.imp.features.purchase.order.PurchaseOrderService;
import com.uten.imp.features.purchase.receipt.PurchaseReceiptService;
import com.uten.imp.features.purchase.request.PurchaseRequestService;
import com.uten.imp.features.purchase.ret.PurchaseReturnService;
import com.uten.imp.features.warehouse.inbound.ProcurementInspectionService;
import com.uten.imp.features.warehouse.inbound.ProcurementIqcStockInService;
import com.uten.imp.features.warehouse.inbound.dto.InspectionDispositionRequest;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.condition.EnabledIfEnvironmentVariable;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.AutowireCapableBeanFactory;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.springframework.test.util.ReflectionTestUtils;
import java.math.BigDecimal;
import java.util.*;
import static com.uten.imp.features.finance.procurement.ProcurementApprovalContracts.*;
import static org.assertj.core.api.Assertions.*;

/** One isolated migrated context; new business data and actual approval/quality/stock/value ports in every case. */
@EnabledIfEnvironmentVariable(named="UTEN_RUN_DB_TESTS",matches="(?i)true")
// Shares FullChain singleton PostgreSQL: bootstrap identity and crypto must match its existing context.
@SpringBootTest(properties={"spring.profiles.active=dev","uten.audit.retention.enabled=false",
    "uten.reporting.materialized-view-refresh.enabled=false","uten.production.readiness-reconcile.enabled=false",
    "uten.features.goods-owner-scope-enabled=false","uten.storage.uploads-enabled=false",
    "uten.jwt.secret=full-chain-harness-jwt-secret-0123456789-test-only", // gitleaks:allow synthetic cryptographic key for this isolated JUnit SpringBootTest.
    "uten.crypto.pgp-master-key=full-chain-harness-pgp-master-key-test-only-0123456789", // gitleaks:allow synthetic cryptographic key for this isolated JUnit SpringBootTest.
    "uten.crypto.hmac-key=full-chain-harness-hmac-key-test-only",
    "uten.bootstrap.admin-login=full-chain-bootstrap-admin-test","uten.bootstrap.admin-password=HarnessAdminPass-1!"})
class GiftPhysicalConservationEndToEndTest {
    @DynamicPropertySource static void database(DynamicPropertyRegistry registry){FullChainEndToEndTest.registerDataSource(registry);}
    @Autowired AutowireCapableBeanFactory beans;
    @Autowired JdbcTemplate db;
    @Autowired PurchaseRequestService requests;
    @Autowired PurchaseOrderService orders;
    @Autowired PurchaseReceiptService receipts;
    @Autowired PurchaseReturnService returns;
    @Autowired ProcurementFinanceApprovalService finance;
    @Autowired TaskClaimService claims;
    @Autowired ProcurementInspectionService inspection;
    @Autowired ProcurementIqcStockInService stockIn;
    @Autowired DocumentUnapprovalService unapproval;
    private FullChainEndToEndTest harness;
    private record F(FullChainEndToEndTest.World w,UUID requestItem,UUID order,UUID orderItem,UUID currency){}
    @BeforeEach void prepare(){harness=new FullChainEndToEndTest();beans.autowireBean(harness);}
    @AfterEach void clear(){SecurityContextHolder.clearContext();}

    @Test void chargedTenAndFreeOneCreateTwoQualityIdentitiesStockElevenAndOnlyOneHundredPayable(){
        F f=fixture();UUID receipt=receipt(f,"10","1");receipts.approve(receipt);
        assertThat(number("SELECT count(*) FROM procurement_inspection_items WHERE receipt_id=?",receipt)).isEqualByComparingTo("2");
        assertThat(db.queryForList("SELECT quantity_tranche FROM procurement_inspection_items WHERE receipt_id=? ORDER BY quantity_tranche",String.class,receipt)).containsExactly("CHARGED","GIFT");
        assertThat(new BigDecimal(receipts.detail(receipt).getItems().getFirst().getPhysicalQtyExact())).isEqualByComparingTo("11");
        assertThat(ap(receipt)).isEqualByComparingTo("100");assertThat(stock(f)).isZero();
        assertThat(number("SELECT received_qty FROM purchase_order_items WHERE id=?",f.orderItem())).isEqualByComparingTo("10");
        assertThat(number("SELECT gift_received_qty FROM purchase_order_items WHERE id=?",f.orderItem())).isEqualByComparingTo("1");
        assertThat(number("SELECT gift_ordered_qty FROM purchase_request_items WHERE id=?",f.requestItem())).isEqualByComparingTo("1");
        passAndStock(f,receipt);assertThat(stock(f)).isEqualByComparingTo("11");assertThat(value(f)).isEqualByComparingTo("100");
        assertThat(db.queryForObject("SELECT is_closed FROM purchase_orders WHERE id=?",Boolean.class,f.order())).isTrue();
        assertThat(number("SELECT nominal_original FROM procurement_receipt_consideration_parts WHERE receipt_id=? AND quantity_tranche='GIFT'",receipt)).isZero();
        assertThat(new BigDecimal(receipts.detail(receipt).getItems().getFirst().getReturnableGiftQtyExact())).isEqualByComparingTo("1");
    }

    @Test void freeOneCanArriveAfterAllTenChargedUnitsWithoutChangingApOrChargingAnOverage(){
        F f=fixture();UUID paid=receipt(f,"10","0");receipts.approve(paid);passAndStock(f,paid);
        assertThat(stock(f)).isEqualByComparingTo("10");assertThat(ap(paid)).isEqualByComparingTo("100");
        assertThat(db.queryForObject("SELECT is_closed FROM purchase_orders WHERE id=?",Boolean.class,f.order())).isFalse();
        UUID free=receipt(f,"0","1");receipts.approve(free);passAndStock(f,free);
        assertThat(stock(f)).isEqualByComparingTo("11");assertThat(value(f)).isEqualByComparingTo("100");
        assertThat(ap(free)).isZero();assertThat(number("SELECT count(*) FROM ar_ap_ledger WHERE source_doc_id=?",free)).isZero();
        assertThat(number("SELECT count(*) FROM procurement_arrival_exceptions WHERE receipt_id=?",free)).isZero();
        assertThat(number("SELECT received_qty FROM purchase_order_items WHERE id=?",f.orderItem())).isEqualByComparingTo("10");
    }

    @Test void freeAndChargedReturnsCreditOnlyChargedUnitsAndMirrorOriginalIssueValueOnReverse() throws Exception{
        F f=fixture();UUID receipt=receipt(f,"10","1");receipts.approve(receipt);passAndStock(f,receipt);
        UUID source=receipts.detail(receipt).getItems().getFirst().getId();BigDecimal originalValue=value(f);
        UUID free=returned(f,source,"0","1");approveWithActualBookShare(free);
        assertThat(stock(f)).isEqualByComparingTo("10");assertThat(ap(free)).isZero();
        assertThat(number("SELECT count(*) FROM ar_ap_ledger WHERE source_doc_id=?",free)).isZero();
        assertThat(number("SELECT returned_qty FROM purchase_receipt_items WHERE id=?",source)).isZero();
        assertThat(number("SELECT gift_returned_qty FROM purchase_receipt_items WHERE id=?",source)).isEqualByComparingTo("1");
        returns.reverse(free);assertThat(stock(f)).isEqualByComparingTo("11");assertThat(value(f)).isEqualByComparingTo(originalValue);
        UUID paid=returned(f,source,"1","0");approveWithActualBookShare(paid);
        assertThat(ap(paid)).isEqualByComparingTo("-10");assertThat(stock(f)).isEqualByComparingTo("10");
        returns.reverse(paid);assertThat(stock(f)).isEqualByComparingTo("11");assertThat(value(f)).isEqualByComparingTo(originalValue);
        assertThat(ap(receipt)).isEqualByComparingTo("100");
    }

    @Test void receiptUnapprovalAndRepeatedCommandsRestoreBothSourceCountersThenNewGenerationPostsExactlyOnce(){
        F f=fixture();UUID receipt=receipt(f,"10","1",new BigDecimal("11.0000"));receipts.approve(receipt);passAndStock(f,receipt);
        var request=new DocumentUnapprovalService.UnapproveRequest("gift-unapprove-"+receipt,"收费和免费实物同代际守恒");
        var draft=(com.uten.imp.features.purchase.receipt.dto.ReceiptDetail)unapproval.unapprove("purchaseReceipt",receipt,request);
        assertThat(stock(f)).isZero();assertThat(value(f)).isZero();assertThat(ap(receipt)).isZero();
        assertThat(number("SELECT received_qty+gift_received_qty FROM purchase_order_items WHERE id=?",f.orderItem())).isZero();
        var again=(com.uten.imp.features.purchase.receipt.dto.ReceiptDetail)unapproval.unapprove("purchaseReceipt",receipt,request);
        assertThat(again.getId()).isEqualTo(draft.getId());assertThat(stock(f)).isZero();
        assertThat(draft.getItems().getFirst().getQuantitySemantics()).isEqualTo("CHARGED_PLUS_GIFT_V1");
        assertThat(number("SELECT original_decimal::numeric FROM business_numeric_input_evidence WHERE owner_kind='PURCHASE_RECEIPT' AND owner_id=? AND source_row_id=? AND field_key='actualWeightKg'",draft.getId(),draft.getItems().getFirst().getId())).isEqualByComparingTo("11");
        assertThat(number("SELECT count(*) FROM business_numeric_input_evidence WHERE owner_kind='PURCHASE_RECEIPT' AND owner_id IN (?,?) AND field_key='actualWeightKg'",receipt,draft.getId())).isEqualByComparingTo("2");
        assertThat(number("SELECT count(DISTINCT source_action_id) FROM business_numeric_input_evidence WHERE owner_kind='PURCHASE_RECEIPT' AND owner_id IN (?,?) AND field_key='actualWeightKg'",receipt,draft.getId())).isEqualByComparingTo("2");
        assertThat(db.queryForObject("SELECT precision_policy->'choices'='{}'::jsonb AND original_unit->>'code'='KG' AND recorded_unit=original_unit FROM business_numeric_input_evidence WHERE owner_kind='PURCHASE_RECEIPT' AND owner_id=? AND source_row_id=? AND field_key='actualWeightKg'",Boolean.class,draft.getId(),draft.getItems().getFirst().getId())).isTrue();
        receipts.approve(draft.getId());passAndStock(f,draft.getId());
        assertThat(stock(f)).isEqualByComparingTo("11");assertThat(value(f)).isEqualByComparingTo("100");assertThat(ap(draft.getId())).isEqualByComparingTo("100");
        assertThat(number("SELECT count(*) FROM procurement_inspection_items WHERE receipt_id=? AND status='RESOLVED'",draft.getId())).isEqualByComparingTo("2");
        assertThatThrownBy(()->receipts.approve(draft.getId())).isInstanceOf(com.uten.imp.common.web.ApiException.class);
        assertThat(stock(f)).isEqualByComparingTo("11");
    }

    @Test void legacyGiftAnnotationKeepsRecordedTenOnReverseAndCloneUnlessOwnerExplicitlyUpgradesDraft(){
        F f=fixture();UUID receipt=receipt(f,"10","1");
        // A pre-V843 persisted draft has annotation-only gift and no extra physical authority.
        db.update("UPDATE purchase_receipts SET quantity_semantics='LEGACY_RECORDED' WHERE id=?",receipt);
        // V1033: re-tagging the annotation-only legacy semantics adopts its physical
        // facts too — the gift is no longer a physical tranche, so its base is 0.
        db.update("UPDATE purchase_receipt_items SET quantity_semantics='LEGACY_RECORDED',gift_base_qty=0 WHERE receipt_id=?",receipt);
        receipts.approve(receipt);passAndStock(f,receipt);assertThat(stock(f)).isEqualByComparingTo("10");
        var draft=(com.uten.imp.features.purchase.receipt.dto.ReceiptDetail)unapproval.unapprove("purchaseReceipt",receipt,new DocumentUnapprovalService.UnapproveRequest("gift-legacy-"+receipt,"保原历史实物量"));
        assertThat(stock(f)).isZero();assertThat(draft.getItems().getFirst().getQuantitySemantics()).isEqualTo("LEGACY_RECORDED");
        assertThat(db.queryForObject("SELECT weight IS NULL FROM purchase_receipt_items WHERE receipt_id=?",Boolean.class,draft.getId())).isTrue();
        assertThat(number("SELECT count(*) FROM business_numeric_input_evidence WHERE owner_kind='PURCHASE_RECEIPT' AND owner_id=? AND field_key='actualWeightKg'",draft.getId())).isZero();
        receipts.approve(draft.getId());passAndStock(f,draft.getId());assertThat(stock(f)).isEqualByComparingTo("10");
        assertThat(number("SELECT gift_received_qty FROM purchase_order_items WHERE id=?",f.orderItem())).isZero();
    }

    @Test void directPostedGiftReplacementIntentTamperingIsRejectedWithoutChangingOriginalFacts(){
        F f=fixture();UUID received=receipt(f,"10","1");receipts.approve(received);
        UUID line=db.queryForObject("SELECT id FROM purchase_receipt_items WHERE receipt_id=?",UUID.class,received);
        String facts="""
                SELECT header.status,header.total_original::text AS total_original,header.total_local::text AS total_local,
                       item.qty::text AS qty,item.gift_qty::text AS gift_qty,
                       item.charged_base_qty::text AS charged_base_qty,item.gift_base_qty::text AS gift_base_qty,
                       item.gift_replacement_intent,ordered.received_qty::text AS ordered_received_qty,
                       ordered.gift_received_qty::text AS ordered_gift_received_qty
                FROM purchase_receipt_items item JOIN purchase_receipts header ON header.id=item.receipt_id
                JOIN purchase_order_items ordered ON ordered.id=item.order_item_id WHERE item.id=?
                """;
        var before=db.queryForMap(facts,line);
        assertThat(((Number)before.get("status")).intValue()).isEqualTo(1);
        assertThat(before.get("gift_replacement_intent")).isEqualTo("NORMAL");
        Throwable rejected=catchThrowable(()->db.update("UPDATE purchase_receipt_items SET gift_replacement_intent='RETURN_REPLACEMENT' WHERE id=?",line));
        assertThat(rejected).isInstanceOf(org.springframework.dao.DataAccessException.class);
        Throwable cause=org.springframework.core.NestedExceptionUtils.getMostSpecificCause(rejected);
        assertThat(cause).isInstanceOf(java.sql.SQLException.class);
        assertThat(((java.sql.SQLException)cause).getSQLState()).isEqualTo("23514");
        assertThat(cause).hasMessageContaining("posted charged/free input and base facts are immutable");
        assertThat(db.queryForMap(facts,line)).isEqualTo(before);
    }

    private F fixture(){
        var w=harness.seedWorld("gift-"+UUID.randomUUID());harness.loginAs(w.superAdminUserId());
        UUID currency=db.queryForObject("SELECT id FROM currencies WHERE is_base_currency AND NOT is_deleted",UUID.class);
        var req=new com.uten.imp.features.purchase.request.dto.RequestSaveRequest();req.setBillDate(BusinessTime.today());req.setWarehouseId(w.warehouseId());
        var rl=new com.uten.imp.features.purchase.request.dto.RequestItemLine();rl.setGoodsId(w.goodsD());rl.setUnitId(w.unitId());rl.setUnitRate(BigDecimal.ONE);rl.setQty(new BigDecimal("10"));rl.setGiftQty(BigDecimal.ONE);req.setItems(List.of(rl));
        var source=requests.create(req);requests.approve(source.getId());UUID requestItem=source.getItems().getFirst().getId();
        UUID reviewer=harness.createUserWithPerms(w,"gift-finance-"+UUID.randomUUID(),"finance_order_approval:view","finance_order_approval:approve");harness.loginAs(w.superAdminUserId());
        var order=new com.uten.imp.features.purchase.order.dto.OrderSaveRequest();order.setBillDate(BusinessTime.today());order.setSupplierId(w.supplierId());order.setWarehouseId(w.warehouseId());order.setCurrencyId(currency);order.setExchangeRate(BigDecimal.ONE);order.setTaxRate(BigDecimal.ZERO);order.setSettlementMethodId(settlement());
        var line=new com.uten.imp.features.purchase.order.dto.OrderItemLine();line.setGoodsId(w.goodsD());line.setUnitId(w.unitId());line.setUnitRate(BigDecimal.ONE);line.setQty(new BigDecimal("10"));line.setGiftQty(BigDecimal.ONE);line.setPrice(new BigDecimal("10"));line.setRequestItemId(requestItem);order.setItems(List.of(line));
        UUID id=orders.create(order).getId();finance.submit("PURCHASE",id);harness.loginAs(reviewer);
        var approval=db.queryForMap("SELECT id,version FROM procurement_order_approval_cases WHERE order_type='PURCHASE' AND order_id=? AND status='PENDING'",id);UUID caseId=(UUID)approval.get("id");
        UUID claim=claims.claim("PROCUREMENT_FINANCE_APPROVE",caseId.toString()).claimId();finance.approveBatch(List.of(new BatchDecisionItem(caseId,((Number)approval.get("version")).longValue(),claim)),null,BigDecimal.ONE);harness.loginAs(w.superAdminUserId());
        return new F(w,requestItem,id,db.queryForObject("SELECT id FROM purchase_order_items WHERE order_id=?",UUID.class,id),currency);
    }
    private UUID receipt(F f,String charged,String gift){return receipt(f,charged,gift,null);}
    private UUID receipt(F f,String charged,String gift,BigDecimal weight){
        var request=new com.uten.imp.features.purchase.receipt.dto.ReceiptSaveRequest();request.setBillDate(BusinessTime.today());request.setSupplierId(f.w().supplierId());request.setWarehouseId(f.w().warehouseId());
        var line=new com.uten.imp.features.purchase.receipt.dto.ReceiptItemLine();line.setGoodsId(f.w().goodsD());line.setUnitId(f.w().unitId());line.setUnitRate(BigDecimal.ONE);line.setQty(new BigDecimal(charged));line.setGiftQty(new BigDecimal(gift));line.setWeight(weight);line.setOrderItemId(f.orderItem());request.setItems(List.of(line));
        return receipts.create(request).getId();
    }
    private void approveWithActualBookShare(UUID returned) throws Exception {
        try(var choice=com.uten.imp.common.finance.BusinessPrecisionContext.use(Map.of(
                "stock.value.interval",new com.uten.imp.common.finance.BusinessPrecisionContext.Choice(24,"HALF_UP")))) {
            returns.approve(returned);
        }
    }
    private UUID returned(F f,UUID source,String charged,String gift){
        var request=new com.uten.imp.features.purchase.ret.dto.ReturnSaveRequest();request.setBillDate(BusinessTime.today());request.setSupplierId(f.w().supplierId());request.setWarehouseId(f.w().warehouseId());
        var line=new com.uten.imp.features.purchase.ret.dto.ReturnItemLine();line.setGoodsId(f.w().goodsD());line.setUnitId(f.w().unitId());line.setUnitRate(BigDecimal.ONE);line.setQty(new BigDecimal(charged));line.setGiftQty(new BigDecimal(gift));line.setReceiptItemId(source);line.setOrderItemId(f.orderItem());request.setItems(List.of(line));
        return returns.create(request).getId();
    }
    private void passAndStock(F f,UUID receipt){
        harness.loginAs(f.w().superAdminUserId());List<UUID> ids=db.queryForList("SELECT id FROM procurement_inspection_items WHERE receipt_id=? ORDER BY quantity_tranche",UUID.class,receipt);
        for(UUID id:ids)inspection.dispose("PURCHASE",receipt,id,new InspectionDispositionRequest("PASS",null,"真实收费/赠品质检","gift-pass-"+id));
        UUID keeper=ReflectionTestUtils.invokeMethod(harness,"createIqcWarehouseConfirmer",f.w(),"gift-keeper-"+receipt);harness.loginAs(keeper);
        for(UUID id:ids){BigDecimal qty=number("SELECT received_base_qty FROM procurement_inspection_items WHERE id=?",id);
            var command=ReflectionTestUtils.<com.uten.imp.features.warehouse.inbound.ProcurementIqcStockInContracts.ConfirmRequest>invokeMethod(harness,"latestIqcStockInRequest","PURCHASE",receipt,id,qty,"gift-stock-"+id,"GIFT-BIN");
            var result=stockIn.confirm("PURCHASE",receipt,command);assertThat(stockIn.confirm("PURCHASE",receipt,command).batchId()).isEqualTo(result.batchId());
        }
        harness.loginAs(f.w().superAdminUserId());ReflectionTestUtils.invokeMethod(harness,"drainCosts",f.w());
    }
    private UUID settlement(){return db.queryForObject("SELECT id FROM settlement_methods WHERE status='使用' AND NOT is_deleted ORDER BY code LIMIT 1",UUID.class);}
    private BigDecimal number(String sql,Object...args){return db.queryForObject(sql,BigDecimal.class,args);}
    private BigDecimal stock(F f){return number("SELECT COALESCE(SUM(qty),0) FROM stock_balances WHERE goods_id=?",f.w().goodsD());}
    private BigDecimal value(F f){return number("SELECT COALESCE(SUM(amount_local),0) FROM stock_balances WHERE goods_id=?",f.w().goodsD());}
    private BigDecimal ap(UUID receipt){return number("SELECT COALESCE(SUM(amount_original_local),0) FROM ar_ap_ledger WHERE source_doc_id=? AND status=1 AND direction='AP'",receipt);}
}
