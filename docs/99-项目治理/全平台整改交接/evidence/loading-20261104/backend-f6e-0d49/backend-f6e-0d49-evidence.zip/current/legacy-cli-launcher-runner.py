import os
import sys
import unittest
sys.path.insert(0,os.getcwd())
sys.executable='C:/Program Files/LibreOffice/program/python.exe'
suite=unittest.defaultTestLoader.loadTestsFromName('test_compose_bootstrap.BootstrapComposerTest.test_cli_rejects_before_emitting_any_partial_module')
result=unittest.TextTestRunner(verbosity=2).run(suite)
sys.exit(0 if result.wasSuccessful() else 1)
