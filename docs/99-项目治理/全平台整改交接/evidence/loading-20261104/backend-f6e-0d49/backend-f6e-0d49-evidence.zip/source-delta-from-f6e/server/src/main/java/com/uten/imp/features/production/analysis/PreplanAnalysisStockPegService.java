package com.uten.imp.features.production.analysis;

import com.uten.imp.application.port.PreplanAnalysisPegPort;
import com.uten.imp.common.util.CanonicalFingerprint;
import com.uten.imp.common.util.NativeQueryResults;
import com.uten.imp.common.web.ApiException;
import com.uten.imp.common.web.ErrorCode;
import com.uten.imp.features.production.fulfillment.PlanningPackageFingerprint;
import com.uten.imp.features.stock.InventoryKey;
import com.uten.imp.features.stock.InventoryMutationLock;
import com.uten.imp.security.SecurityContextCurrentUser;
import com.uten.imp.security.TxSessionVars;
import jakarta.persistence.EntityManager;
import org.springframework.beans.factory.ObjectProvider;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.math.BigDecimal;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Set;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;

/**
 * 计划前物料分析备料库存绑定（V298）。
 *
 * <p>收货 IQC 合格入库 / 自制成品入库时，把入库量按来源单据链溯源到物料分析，
 * 写 {@code owner_type='PREPLAN_ANALYSIS'} 软预留（供应锚点 = 采购申请行 /
 * 委外申请行 / 生产计划行）。统一可用量口径自动对其它分析、销售和 MRP 隐藏这批料；
 * 归属分析自己的可用量由 {@link MaterialAnalysisService} 加回。
 *
 * <p>对称反向：收货红冲按来源单据释放；分析取消/任务撤回按归属释放；
 * 计划包确认时按需求维度转移（释放回池，需求分配器同事务再为 demand 建行）。
 */
@Service
@RequiredArgsConstructor
public class PreplanAnalysisStockPegService implements PreplanAnalysisPegPort {
    @org.springframework.beans.factory.annotation.Autowired
    private MaterialAnalysisRootSupplyService rootSupply;


    public static final String OWNER_TYPE = "PREPLAN_ANALYSIS";
    public static final String PURPOSE = "PREPLAN_MATERIAL";
    /** stock_reservations.source：0下单现货 / 1生产入库 / 2计划包物料 / 3分析备料。 */
    public static final short SOURCE_PREPLAN_ANALYSIS = 3;

    private static final short STATUS_EFFECTIVE = 0;
    private static final short STATUS_DONE = 1;

    private static final String SUPPLY_PURCHASE_REQUEST_ITEM = "PURCHASE_REQUEST_ITEM";
    private static final String SUPPLY_SUBCONTRACT_APPLICATION_ITEM =
            "SUBCONTRACT_APPLICATION_ITEM";
    private static final String SUPPLY_PRODUCTION_PLAN_ITEM = "PRODUCTION_PLAN_ITEM";

    /**
     * 同一供应行动里各份额的「先急后缓」次序(ADR-127 §7.2 第 5 点)：份额所属产品行的优先级、交期，
     * 再按建立先后；同一笔事务里建立的份额不再按随机 UUID 抢先。别名固定：{@code owner} = 份额所属的
     * 物料分析行，{@code allocation} = 份额。
     */
    static final String ALLOCATION_URGENCY_ORDER =
            "owner.line_priority NULLS LAST, owner.delivery_date NULLS LAST, allocation.created_at, allocation.id";

    /**
     * 采购/委外到货分给各份额的次序：先转交、再普通、最后共享认领，同类按供应行动先后，行动内先急后缓。
     * 入库时的真实归属与到货预览({@link PreplanInboundAllocationProjectionService})共用这一份，预览才会
     * 与实际入库落到同一个产品、计划、车间与仓库。别名固定：{@code action}、{@code owner}、{@code allocation}。
     */
    static final String INBOUND_ALLOCATION_ORDER =
            "CASE action.operation_type WHEN 'FUTURE_TRANSFER' THEN -1 WHEN 'SHARED_FUTURE_CLAIM' THEN 1 ELSE 0 END, "
                    + "action.created_at, action.id, " + ALLOCATION_URGENCY_ORDER;

    private final EntityManager em;
    private final TxSessionVars tx;
    private final SecurityContextCurrentUser currentUser;
    private final InventoryMutationLock inventoryLock;
    private final PreplanStockEntitlementService entitlement;
    private final ObjectProvider<PreplanOriginEntitlementHook> originHooks;
    @org.springframework.beans.factory.annotation.Autowired
    private ObjectProvider<MaterialAnalysisService> admissionSnapshots;

    // ============================ 收货入库绑定 ============================

    @Override
    @Transactional(propagation = Propagation.MANDATORY)
    public void attributeInspectionStockIn(
            String receiptType,
            UUID receiptId,
            UUID inspectionItemId,
            UUID dispositionEventId,
            UUID warehouseStockInItemId,
            BigDecimal stockedBaseQty,
            UUID warehouseId) {
        tx.bind();
        if (stockedBaseQty == null || stockedBaseQty.signum() <= 0
                || inspectionItemId == null || dispositionEventId == null
                || warehouseStockInItemId == null || warehouseId == null) {
            return;
        }
        boolean purchase = "PURCHASE".equals(receiptType);
        if (!purchase && !"SUBCONTRACT".equals(receiptType)) {
            return;
        }
        // 待检行 → 收货行 → 订货行 → 来源申请/委外申请明细（外部锚点）。
        // V463：合并订货行逐来源展开（按 sources.line_no FIFO），入库量在来源间
        // 先到先得，各来源的分摊容量（action allocation）仍逐来源封顶防重复归属。
        List<Object[]> anchors = NativeQueryResults.objectArrayRows(em.createNativeQuery("""
                        SELECT DISTINCT inspection.goods_id, inspection.color_id,
                               order_item.id, src.%1$s AS external_item_id,
                               src.line_no, src.id,
                               CASE WHEN EXISTS (
                                   SELECT 1
                                   FROM preplan_supply_action_allocations original_allocation
                                   JOIN preplan_supply_actions original_action
                                     ON original_action.id = original_allocation.action_id
                                    AND original_action.operation_type = 'SUPPLY'
                                   WHERE original_allocation.external_item_id = src.%1$s
                               ) THEN 0 ELSE 1 END AS claimant_priority,
                               order_item.order_id,
                               %5$s(order_item.id,src.%1$s,
                                   order_item.qty*COALESCE(order_item.unit_rate,1))
                                   AS source_base_qty,
                               COALESCE(fn_preplan_order_public_source_qty(
                                   public_source.source_action_id,src.%1$s,
                                   :receiptType,order_item.order_id),0)
                                   AS public_base_qty,
                               fn_preplan_order_exact_attributed_qty(
                                   :receiptType,order_item.order_id,src.%1$s,'SUPPLY')
                                   AS exact_used_qty,
                               fn_preplan_order_exact_attributed_qty(
                                   :receiptType,order_item.order_id,src.%1$s,
                                   'SHARED_FUTURE_CLAIM') AS claim_used_qty
                        FROM procurement_inspection_items inspection
                        JOIN %2$s receipt_item
                          ON receipt_item.id = inspection.receipt_item_id
                         AND receipt_item.is_deleted = FALSE
                        JOIN %3$s order_item
                          ON order_item.id = receipt_item.order_item_id
                         AND order_item.is_deleted = FALSE
                        JOIN %4$s src
                          ON src.order_item_id = order_item.id
                        LEFT JOIN LATERAL (
                            SELECT public.source_action_id
                            FROM v_preplan_public_supply_sources_v474 public
                            JOIN preplan_supply_actions source_action
                              ON source_action.id=public.source_action_id
                             AND source_action.status <> 'CANCELLED'
                            WHERE public.external_item_id=src.%1$s
                            ORDER BY source_action.created_at,source_action.id
                            LIMIT 1
                        ) public_source ON TRUE
                        WHERE inspection.id = :inspectionItemId
                          AND inspection.receipt_type = :receiptType
                          AND inspection.receipt_id = :receiptId
                        ORDER BY claimant_priority, src.line_no, src.id
                        """.formatted(
                        purchase ? "request_item_id" : "application_item_id",
                        purchase ? "purchase_receipt_items" : "subcontract_receipt_items",
                        purchase ? "purchase_order_items" : "subcontract_order_items",
                        purchase
                                ? "purchase_order_item_sources"
                                : "subcontract_order_item_sources",
                        purchase
                                ? "fn_purchase_order_source_share"
                                : "fn_subcontract_order_source_share"))
                .setParameter("inspectionItemId", inspectionItemId)
                .setParameter("receiptType", receiptType)
                .setParameter("receiptId", receiptId));
        if (anchors.isEmpty()) {
            // 无 sources 的历史/手工行：退回订货行主锚点单来源（V463 前行为）。
            anchors = NativeQueryResults.objectArrayRows(em.createNativeQuery("""
                            SELECT DISTINCT inspection.goods_id, inspection.color_id,
                                   order_item.id, order_item.%1$s,
                                   0,NULL,0,order_item.order_id,
                                   order_item.qty*COALESCE(order_item.unit_rate,1),
                                   0,0,0
                            FROM procurement_inspection_items inspection
                            JOIN %2$s receipt_item
                              ON receipt_item.id = inspection.receipt_item_id
                             AND receipt_item.is_deleted = FALSE
                            JOIN %3$s order_item
                              ON order_item.id = receipt_item.order_item_id
                             AND order_item.is_deleted = FALSE
                            WHERE inspection.id = :inspectionItemId
                              AND inspection.receipt_type = :receiptType
                              AND inspection.receipt_id = :receiptId
                            """.formatted(
                            purchase ? "request_item_id" : "application_item_id",
                            purchase ? "purchase_receipt_items" : "subcontract_receipt_items",
                            purchase ? "purchase_order_items" : "subcontract_order_items"))
                    .setParameter("inspectionItemId", inspectionItemId)
                    .setParameter("receiptType", receiptType)
                    .setParameter("receiptId", receiptId));
        }
        anchors = anchors.stream()
                .filter(row -> row[3] != null)
                .toList();
        if (anchors.isEmpty()) {
            return; // 订货行无申请来源（历史/手工），不参与分析绑定
        }
        UUID goodsId = (UUID) anchors.getFirst()[0];
        UUID colorId = (UUID) anchors.getFirst()[1];
        inventoryLock.lock(new InventoryKey(goodsId, colorId));
        String supplyType = purchase
                ? SUPPLY_PURCHASE_REQUEST_ITEM
                : SUPPLY_SUBCONTRACT_APPLICATION_ITEM;
        // 先锁定全部来源的候选分析（analysis.id 全序），再逐来源 FIFO 分摊。
        for (Object[] anchor : anchors) {
            lockClaimantAnalyses(
                    (UUID) anchor[3], goodsId, colorId);
        }
        if(admissionSnapshots!=null)refreshRetainedReceiptSnapshots(NativeQueryResults.typedRows(em.createNativeQuery("""
                SELECT DISTINCT analysis_id FROM preplan_supply_action_allocations WHERE external_item_id IN(:items)
                """).setParameter("items",anchors.stream().map(row->(UUID)row[3]).distinct().toList()),UUID.class));

        // 精确归属候选：按供应行动分摊行（analysis_material_id）逐行锁定容量。
        // V307 之前只有 analysis_id 粒度；现在每次 PASS 建一条物理预留及其
        // 一对一 exact-peg 子账，避免同分析内相同物料的兄弟产品抢占。
        BigDecimal remaining = stockedBaseQty;
        Map<UUID, BigDecimal> legacyRemainingByAnalysis = new LinkedHashMap<>();
        Map<UUID,Map<UUID,List<RetainedReceiptSource>>> retainedByAnalysis=new HashMap<>();
        List<PreplanStockEntitlementService.OriginAppendResult> origins = new ArrayList<>();
        for (Object[] anchor : anchors) {
            if (remaining.signum() <= 0) {
                break;
            }
            UUID externalItemId = (UUID) anchor[3];
            BigDecimal exactOrderBudget = decimal(anchor[8])
                    .subtract(decimal(anchor[9]))
                    .subtract(decimal(anchor[10])).max(BigDecimal.ZERO);
            BigDecimal sharedOrderBudget = decimal(anchor[9])
                    .subtract(decimal(anchor[11])).max(BigDecimal.ZERO);
            List<Object[]> claimants = NativeQueryResults.objectArrayRows(em.createNativeQuery("""
                        SELECT allocation.id, allocation.analysis_id,
                               allocation.analysis_material_id,
                               fn_preplan_allocation_admitted_qty(allocation.id), analysis.status,
                               action.operation_type, action.status
                        FROM preplan_supply_action_allocations allocation
                        JOIN preplan_supply_actions action
                          ON action.id = allocation.action_id
                         AND (action.status <> 'CANCELLED'
                              OR fn_iqc_cancelled_supply_can_continue(action.id))
                        JOIN production_material_analyses analysis
                          ON analysis.id = allocation.analysis_id
                         AND analysis.is_deleted = FALSE
                         AND analysis.status IN (
                             'ACTIVE', 'PARTIALLY_PLANNED', 'COMPLETED')
                        JOIN production_material_analysis_materials material
                          ON material.id = allocation.analysis_material_id
                         AND material.analysis_id = allocation.analysis_id
                         AND material.active = TRUE
                        LEFT JOIN production_material_analysis_items owner
                          ON owner.id = material.analysis_item_id
                        WHERE allocation.external_item_id = :externalItemId
                          AND material.goods_id = :goodsId
                          AND material.color_id IS NOT DISTINCT FROM CAST(:colorId AS uuid)
                        ORDER BY %s
                        FOR UPDATE OF action, allocation
                        """.formatted(INBOUND_ALLOCATION_ORDER))
                    .setParameter("externalItemId", externalItemId)
                    .setParameter("goodsId", goodsId)
                    .setParameter("colorId", colorId));

            for (Object[] claimant : claimants) {
                if (remaining.signum() <= 0) {
                    break;
                }
                UUID allocationId = (UUID) claimant[0];
                UUID analysisId = (UUID) claimant[1];
                UUID analysisMaterialId = (UUID) claimant[2];
                String analysisStatus = Objects.toString(claimant[4], "");
                // 全量先排 WAITING 后 analysis 会按数量守恒进入 COMPLETED。
                // 只有该精确物料仍存在已批准、可自动提升的 WAITING demand 时，
                // 才允许继续承接原 action/allocation 的到仓权益；公共库存不兜底。
                if ("COMPLETED".equals(analysisStatus)
                        && !hasAutoPromotableWaitingDemand(
                                analysisId, analysisMaterialId)) {
                    continue;
                }
                BigDecimal allocatedCap = decimal(claimant[3]);
                BigDecimal exactAttributed = exactAttributed(allocationId);
                // 历史 V298 预留没有 exact 子账。它们仍保留分析级池语义，但必须
                // 先按稳定顺序占用该分析的分摊容量，避免升级后重复绑定超量。
                BigDecimal legacyRemaining = legacyRemainingByAnalysis.computeIfAbsent(
                        analysisId, ignored -> legacyAttributed(
                                analysisId, supplyType, externalItemId));
                BigDecimal capacityAfterExact = allocatedCap.subtract(exactAttributed)
                        .max(BigDecimal.ZERO);
                BigDecimal legacyUse = capacityAfterExact.min(legacyRemaining);
                legacyRemainingByAnalysis.put(
                        analysisId, legacyRemaining.subtract(legacyUse));
                BigDecimal headroom = capacityAfterExact.subtract(legacyUse);
                if ("CANCELLED".equals(Objects.toString(claimant[6], ""))) {
                    // A terminal IQC action stays cancelled. Only the actual V518
                    // replacement part on this stock-in may continue its old origin,
                    // within current node demand and other live supply commitments.
                    headroom = headroom.min(decimal(em.createNativeQuery("""
                            SELECT fn_iqc_replacement_origin_capacity(:stockItemId,:allocationId,NULL)
                            """).setParameter("stockItemId", warehouseStockInItemId)
                            .setParameter("allocationId", allocationId).getSingleResult()));
                }
                boolean sharedClaim = "SHARED_FUTURE_CLAIM".equals(
                        Objects.toString(claimant[5], ""));
                BigDecimal orderBudget = sharedClaim
                        ? sharedOrderBudget : exactOrderBudget;
                BigDecimal take = remaining.min(headroom.max(BigDecimal.ZERO))
                        .min(orderBudget);
                if (take.signum() <= 0) {
                    continue;
                }
                var retained=retainedByAnalysis.computeIfAbsent(analysisId,this::retainedReceiptSources).get(allocationId);
                if(retained==null) {
                    requireNoUnprovenCancelledMaterial(analysisMaterialId);
                    origins.add(insertExactReservation(allocationId, analysisId, analysisMaterialId,
                            warehouseId, goodsId, colorId, take,supplyType, externalItemId, receiptType, receiptId,
                            dispositionEventId, warehouseStockInItemId));
                } else {
                    requireRetainedSourcesWritable(retained);
                    var slices=retainedReceiptSlices(retained,take);take=slices.stream().map(RetainedReceiptSource::remaining).reduce(BigDecimal.ZERO,BigDecimal::add);
                    for(var slice:slices)origins.add(insertExactReservation(allocationId,analysisId,slice.original(),warehouseId,
                            goodsId,colorId,slice.remaining(),supplyType,externalItemId,receiptType,receiptId,dispositionEventId,warehouseStockInItemId,true));
                }
                remaining = remaining.subtract(take);
                if (sharedClaim) {
                    sharedOrderBudget = sharedOrderBudget.subtract(take);
                } else {
                    exactOrderBudget = exactOrderBudget.subtract(take);
                }
            }
        }
        // The whole physical receipt is already in stock. Establish every
        // beneficiary before readiness can consume its unassigned remainder;
        // otherwise a continuous task can take a later claimant's slice as public.
        applyOriginPriority(origins);
        // 超出分析分摊量的部分（含财务特批超收）不绑定，按公共现货处理。
    }

    // ============================ 自制成品入库绑定 ============================
    @Override
    @Transactional(propagation = Propagation.MANDATORY)
    public void pegFinishedInbound(
            UUID stockDocumentId,
            UUID planId,
            UUID warehouseId,
            List<FinishedInboundSlice> lines) {
        tx.bind();
        if (lines == null || lines.isEmpty() || planId == null
                || warehouseId == null || stockDocumentId == null) return;
        if(admissionSnapshots!=null)refreshRetainedReceiptSnapshots(NativeQueryResults.typedRows(em.createNativeQuery("""
                SELECT material_analysis_id FROM (SELECT * FROM production_plans archive_origin WHERE NULLIF(to_jsonb(archive_origin)->>'legacy_id','') IS NULL AND NULLIF(to_jsonb(archive_origin)->>'legacy_import_run_id','') IS NULL AND NOT fn_imported_business_document_row('production_plans',to_jsonb(archive_origin))) production_plans WHERE id=:plan AND material_analysis_id IS NOT NULL
                """).setParameter("plan",planId),UUID.class));
        MakeInboundSplit split = splitMakeInbound(stockDocumentId, lines);
        // Establish all claimed public ownership before readiness can consume
        // unassigned stock from this same physical movement batch.
        List<PreplanStockEntitlementService.OriginAppendResult> publicOrigins =
                pegClaimedPublicMake(stockDocumentId, warehouseId, split.publicLines());
        pegDemandFinishedInbound(stockDocumentId, planId, warehouseId, split.privateLines());
        applyOriginPriority(publicOrigins);
    }

    record MakeInboundSplit(List<FinishedInboundSlice> privateLines,
                                    List<FinishedInboundSlice> publicLines) { }

    private MakeInboundSplit splitMakeInbound(UUID document, List<FinishedInboundSlice> lines) {
        List<UUID> planItems = lines.stream().map(FinishedInboundSlice::planItemId).distinct().toList();
        Map<UUID, BigDecimal> privateRemaining = new HashMap<>();
        for (Object[] row : NativeQueryResults.objectArrayRows(em.createNativeQuery("""
                SELECT item.id,GREATEST(item.qty*COALESCE(item.unit_rate,1)
                    -COALESCE(source.planned_public_qty,0)-COALESCE((
                        SELECT SUM(stock.base_qty)
                        FROM (SELECT * FROM stock_document_items archive_origin WHERE NULLIF(to_jsonb(archive_origin)->>'legacy_id','') IS NULL AND NULLIF(to_jsonb(archive_origin)->>'legacy_import_run_id','') IS NULL AND NOT fn_imported_business_document_row('stock_document_items',to_jsonb(archive_origin))) stock JOIN (SELECT * FROM stock_documents archive_origin WHERE NULLIF(to_jsonb(archive_origin)->>'legacy_id','') IS NULL AND NULLIF(to_jsonb(archive_origin)->>'legacy_import_run_id','') IS NULL AND NOT fn_imported_business_document_row('stock_documents',to_jsonb(archive_origin))) doc ON doc.id=stock.doc_id
                        WHERE stock.upstream_item_id=item.id AND stock.bill_type='FINISHED_IN'
                          AND NOT stock.is_deleted AND NOT doc.is_deleted AND doc.status=1
                          AND doc.id<>:document AND NOT fn_finished_in_is_public_output(stock.id)
                    ),0),0)
                FROM (SELECT * FROM production_plan_items archive_origin WHERE NULLIF(to_jsonb(archive_origin)->>'legacy_id','') IS NULL AND NULLIF(to_jsonb(archive_origin)->>'legacy_import_run_id','') IS NULL AND NOT fn_imported_business_document_row('production_plan_items',to_jsonb(archive_origin))) item
                LEFT JOIN LATERAL fn_preplan_make_public_supply_sources(NULL::uuid,item.id) source ON TRUE
                WHERE item.id IN(:items) AND NOT item.is_deleted
                ORDER BY item.id
                """).setParameter("document", document).setParameter("items", planItems))) {
            privateRemaining.put((UUID) row[0], decimal(row[1]));
        }
        Set<UUID> explicitPublic = new HashSet<>(NativeQueryResults.typedRows(em.createNativeQuery("""
                SELECT id FROM (SELECT * FROM stock_document_items archive_origin WHERE NULLIF(to_jsonb(archive_origin)->>'legacy_id','') IS NULL AND NULLIF(to_jsonb(archive_origin)->>'legacy_import_run_id','') IS NULL AND NOT fn_imported_business_document_row('stock_document_items',to_jsonb(archive_origin))) stock_document_items WHERE doc_id=:document
                  AND NOT is_deleted AND fn_finished_in_is_public_output(id)
                """).setParameter("document", document), UUID.class));
        return splitMakeInbound(lines, privateRemaining, explicitPublic);
    }

    static MakeInboundSplit splitMakeInbound(List<FinishedInboundSlice> lines,
                                            Map<UUID, BigDecimal> privateBudget,
                                            Set<UUID> explicitPublic) {
        Map<UUID, BigDecimal> privateRemaining = new HashMap<>(privateBudget);
        List<FinishedInboundSlice> privateLines = new ArrayList<>(), publicLines = new ArrayList<>();
        for (FinishedInboundSlice line : lines.stream()
                .sorted(Comparator.comparing(FinishedInboundSlice::planItemId)
                        .thenComparing(FinishedInboundSlice::stockDocumentItemId)).toList()) {
            BigDecimal amount = line.baseQty();
            if (amount == null || amount.signum() <= 0) continue;
            BigDecimal privateQty = explicitPublic.contains(line.stockDocumentItemId()) ? BigDecimal.ZERO
                    : amount.min(privateRemaining.getOrDefault(line.planItemId(), amount));
            if (privateQty.signum() > 0) {
                privateLines.add(makeSlice(line, privateQty));
                privateRemaining.computeIfPresent(line.planItemId(), (id, remaining) -> remaining.subtract(privateQty));
            }
            if (amount.compareTo(privateQty) > 0) publicLines.add(makeSlice(line, amount.subtract(privateQty)));
        }
        return new MakeInboundSplit(List.copyOf(privateLines), List.copyOf(publicLines));
    }

    private static FinishedInboundSlice makeSlice(FinishedInboundSlice line, BigDecimal qty) {
        return new FinishedInboundSlice(line.stockDocumentItemId(), line.planItemId(),
                line.goodsId(), line.colorId(), qty);
    }

    private List<PreplanStockEntitlementService.OriginAppendResult> pegClaimedPublicMake(
            UUID document, UUID warehouse, List<FinishedInboundSlice> lines) {
        List<PreplanStockEntitlementService.OriginAppendResult> origins = new ArrayList<>();
        for (FinishedInboundSlice line : lines) {
            inventoryLock.lock(new InventoryKey(line.goodsId(), line.colorId()));
            BigDecimal remaining = line.baseQty().subtract(decimal(em.createNativeQuery("""
                    SELECT COALESCE(SUM(qty),0) FROM preplan_analysis_stock_exact_pegs
                    WHERE source_stock_document_item_id=:item AND make_public_claim_id IS NOT NULL
                    """).setParameter("item", line.stockDocumentItemId()).getSingleResult())).max(BigDecimal.ZERO);
            if (remaining.signum() == 0) continue;
            List<Object[]> claims = NativeQueryResults.objectArrayRows(em.createNativeQuery("""
                    SELECT claim.id,claim.target_analysis_id,claim.target_material_id,
                        GREATEST(fn_preplan_make_public_claim_pending_qty(claim.id)-COALESCE((
                            SELECT SUM(peg.qty) FROM preplan_analysis_stock_exact_pegs peg
                            JOIN (SELECT * FROM stock_documents archive_origin WHERE NULLIF(to_jsonb(archive_origin)->>'legacy_id','') IS NULL AND NULLIF(to_jsonb(archive_origin)->>'legacy_import_run_id','') IS NULL AND NOT fn_imported_business_document_row('stock_documents',to_jsonb(archive_origin))) doc ON doc.id=peg.source_stock_document_id
                            WHERE peg.make_public_claim_id=claim.id AND doc.id=:document
                              AND doc.status<>1 AND NOT doc.is_deleted),0),0)
                    FROM preplan_make_public_claims claim
                    JOIN production_material_analyses analysis ON analysis.id=claim.target_analysis_id
                      AND NOT analysis.is_deleted AND analysis.status<>'CANCELLED'
                    WHERE claim.source_plan_item_id=:planItem
                      AND NOT EXISTS(SELECT 1 FROM preplan_analysis_stock_exact_pegs previous
                        WHERE previous.make_public_claim_id=claim.id
                          AND previous.source_stock_document_item_id=:stockItem)
                    ORDER BY claim.created_at,claim.id FOR UPDATE OF claim
                    """).setParameter("planItem", line.planItemId()).setParameter("document", document)
                    .setParameter("stockItem", line.stockDocumentItemId()));
            for (Object[] claim : claims) {
                BigDecimal take = remaining.min(decimal(claim[3]));
                if (take.signum() <= 0) continue;
                origins.add(insertExactMakeReservation(null, null, (UUID) claim[1], (UUID) claim[2],
                        warehouse, line.goodsId(), line.colorId(), take, line.planItemId(), document,
                        line.stockDocumentItemId(), (UUID) claim[0]));
                remaining = remaining.subtract(take);
                if (remaining.signum() == 0) break;
            }
        }
        return origins;
    }

    private void pegDemandFinishedInbound(
            UUID stockDocumentId,
            UUID planId,
            UUID warehouseId,
            List<FinishedInboundSlice> lines) {
        tx.bind();
        if (lines == null || lines.isEmpty() || planId == null
                || warehouseId == null || stockDocumentId == null) {
            return;
        }
        // Public output retains the originating plan for audit and costing,
        // but cannot inherit that plan's original material/sales obligation.
        List<UUID> publicItems = NativeQueryResults.typedRows(em.createNativeQuery("""
                SELECT id FROM (SELECT * FROM stock_document_items archive_origin WHERE NULLIF(to_jsonb(archive_origin)->>'legacy_id','') IS NULL AND NULLIF(to_jsonb(archive_origin)->>'legacy_import_run_id','') IS NULL AND NOT fn_imported_business_document_row('stock_document_items',to_jsonb(archive_origin))) stock_document_items
                WHERE doc_id = :documentId AND fn_finished_in_is_public_output(id)
                """).setParameter("documentId", stockDocumentId), UUID.class);
        lines = lines.stream().filter(line -> !publicItems.contains(line.stockDocumentItemId())).toList();
        if (lines.isEmpty()) return;
        List<Object[]> contexts = NativeQueryResults.objectArrayRows(
                em.createNativeQuery("""
                        SELECT plan.material_analysis_id,
                               plan.material_analysis_item_id,
                               item.source_type,
                               item.parent_analysis_material_id,
                               analysis.status
                        FROM (SELECT * FROM production_plans archive_origin WHERE NULLIF(to_jsonb(archive_origin)->>'legacy_id','') IS NULL AND NULLIF(to_jsonb(archive_origin)->>'legacy_import_run_id','') IS NULL AND NOT fn_imported_business_document_row('production_plans',to_jsonb(archive_origin))) plan
                        JOIN production_material_analyses analysis
                          ON analysis.id = plan.material_analysis_id
                         AND analysis.is_deleted = FALSE
                        JOIN production_material_analysis_items item
                          ON item.id = plan.material_analysis_item_id
                         AND item.analysis_id = plan.material_analysis_id
                         AND item.is_deleted = FALSE
                        WHERE plan.id = :planId
                          AND plan.is_deleted = FALSE
                          AND plan.material_analysis_id IS NOT NULL
                          AND plan.material_analysis_item_id IS NOT NULL
                        FOR UPDATE OF analysis, item
                        """).setParameter("planId", planId));
        if (contexts.isEmpty()) {
            return;
        }
        Object[] context = contexts.getFirst();
        UUID analysisId = (UUID) context[0];
        UUID analysisItemId = (UUID) context[1];
        UUID parentAnalysisMaterialId = (UUID) context[3];
        String sourceType = Objects.toString(context[2], "");
        String analysisStatus = Objects.toString(context[4], "");
        boolean aggregateMake="AGGREGATE_MAKE".equals(sourceType);
        if(aggregateMake) {
            List<?> routes=em.createNativeQuery("""
                    SELECT route FROM preplan_aggregate_batches WHERE analysis_id=:analysis
                      AND anchor_analysis_item_id=:anchor AND plan_id=:plan
                    """).setParameter("analysis",analysisId).setParameter("anchor",analysisItemId).setParameter("plan",planId).getResultList();
            if(routes.size()!=1)throw new ApiException(ErrorCode.CONFLICT,"共享生产缺少准确的来源批次证明");
            if(!"MAKE".equals(routes.getFirst()))throw new ApiException(ErrorCode.CONFLICT,"共享生产来源路线不匹配");
        }
        boolean activeAnalysis = List.of("ACTIVE", "PARTIALLY_PLANNED")
                .contains(analysisStatus);
        boolean completedWaitingOwner = "COMPLETED".equals(analysisStatus)
                && ((parentAnalysisMaterialId != null && (hasAutoPromotableWaitingDemand(analysisId,parentAnalysisMaterialId)
                    || Boolean.TRUE.equals(em.createNativeQuery("""
                        SELECT EXISTS(SELECT 1 FROM preplan_aggregate_material_aliases alias
                          WHERE alias.source_material_id=:material AND fn_preplan_aggregate_alias_identity_valid(alias.id))
                        """).setParameter("material",parentAnalysisMaterialId).getSingleResult())))
                    || (aggregateMake && Boolean.TRUE.equals(em.createNativeQuery("""
                        SELECT EXISTS(SELECT 1 FROM preplan_supply_action_allocations allocation
                          JOIN preplan_aggregate_batches batch ON batch.action_id=allocation.action_id
                          WHERE batch.anchor_analysis_item_id=:anchor AND fn_preplan_aggregate_material_has_waiting_demand(allocation.analysis_material_id))
                        """).setParameter("anchor",analysisItemId).getSingleResult())));
        if (!activeAnalysis && !completedWaitingOwner) {
            return;
        }
        if (!"MAKE_COMPONENT".equals(sourceType) && !aggregateMake) {
            // Preserve the historical analysis-pool behavior for non-MAKE
            // analysis products. Only PREPLAN_MAKE_TASK output has an exact
            // parent material allocation that V309 can prove.
            for (FinishedInboundSlice line : lines) {
                if (line.baseQty() == null || line.baseQty().signum() <= 0) continue;
                inventoryLock.lock(new InventoryKey(
                        line.goodsId(), line.colorId()));
                insertReservation(
                        analysisId, warehouseId, line.goodsId(), line.colorId(),
                        line.baseQty(), SUPPLY_PRODUCTION_PLAN_ITEM,
                        line.planItemId(), "PRODUCTION_INBOUND", stockDocumentId,
                        "PREPLAN-MAKE-IN:" + line.stockDocumentItemId());
            }
            return;
        }

        Map<UUID, BigDecimal> formalRemainingByPlanItem = new HashMap<>();
        Map<UUID, BigDecimal> legacyRemainingByAnalysis = new HashMap<>();
        List<PreplanStockEntitlementService.OriginAppendResult> origins = new ArrayList<>();
        Map<UUID,List<RetainedReceiptSource>> retainedSources=aggregateMake?retainedReceiptSources(analysisId):Map.of();
        if(!aggregateMake&&parentAnalysisMaterialId!=null)requireNoUnprovenCancelledMaterial(parentAnalysisMaterialId);
        for (FinishedInboundSlice line : lines) {
            if (line.baseQty() == null || line.baseQty().signum() <= 0) continue;
            inventoryLock.lock(new InventoryKey(line.goodsId(), line.colorId()));
            Map<UUID,BigDecimal> directMembers=new HashMap<>();
            if(aggregateMake) {
                for(Object[] slice:NativeQueryResults.objectArrayRows(em.createNativeQuery("""
                        SELECT proof.supply_action_allocation_id,SUM(proof.qty_base)
                        FROM preplan_aggregate_direct_transfer_slices proof
                        JOIN production_workshop_direct_transfer_items transfer ON transfer.id=proof.transfer_item_id AND transfer.reversal_id IS NULL
                        JOIN (SELECT * FROM stock_document_items archive_origin WHERE NULLIF(to_jsonb(archive_origin)->>'legacy_id','') IS NULL AND NULLIF(to_jsonb(archive_origin)->>'legacy_import_run_id','') IS NULL AND NOT fn_imported_business_document_row('stock_document_items',to_jsonb(archive_origin))) item ON item.source_daily_report_item_id=transfer.source_report_item_id
                        WHERE item.id=:item AND proof.supply_action_allocation_id IS NOT NULL
                        GROUP BY proof.supply_action_allocation_id
                        """).setParameter("item",line.stockDocumentItemId())))directMembers.put((UUID)slice[0],decimal(slice[1]));
            }
            BigDecimal unrecorded=line.baseQty();
            if(aggregateMake) {
                BigDecimal already=decimal(em.createNativeQuery("""
                        SELECT COALESCE((SELECT SUM(qty) FROM preplan_analysis_stock_exact_pegs
                            WHERE source_receipt_type='MAKE' AND source_stock_document_item_id=:item
                              AND make_public_claim_id IS NULL),0)
                          +COALESCE((SELECT SUM(allocated_qty) FROM production_material_make_receipt_allocations
                            WHERE receipt_item_id=:item AND status='EFFECTIVE'),0)
                        """).setParameter("item",line.stockDocumentItemId()).getSingleResult());
                unrecorded=unrecorded.subtract(already).max(BigDecimal.ZERO);
                if(unrecorded.signum()==0)continue;
            }
            BigDecimal formalRemaining = formalRemainingByPlanItem.computeIfAbsent(
                    line.planItemId(), this::activeFormalMakeCommitment);
            BigDecimal formalUse = unrecorded.min(formalRemaining);
            formalRemainingByPlanItem.put(
                    line.planItemId(), formalRemaining.subtract(formalUse));
            BigDecimal remaining = unrecorded.subtract(formalUse);
            if (remaining.signum() <= 0) continue;

            List<Object[]> allocations = NativeQueryResults.objectArrayRows(
                    em.createNativeQuery("""
                            SELECT allocation.id, allocation.analysis_id,
                                   allocation.analysis_material_id,
                                   fn_preplan_allocation_admitted_qty(allocation.id)
                            FROM preplan_supply_action_allocations allocation
                            JOIN preplan_supply_actions action
                              ON action.id = allocation.action_id
                             AND action.analysis_id = allocation.analysis_id
                             AND action.route = 'MAKE'
                             AND action.status <> 'CANCELLED'
                             AND action.external_document_type =
                                 'PREPLAN_MAKE_TASK'
                            JOIN production_material_analysis_materials material
                              ON material.id = allocation.analysis_material_id
                             AND material.analysis_id = allocation.analysis_id
                             AND material.active = TRUE
                            LEFT JOIN production_material_analysis_items owner
                              ON owner.id = material.analysis_item_id
                            WHERE allocation.analysis_id = :analysisId
                              AND allocation.external_item_id = :analysisItemId
                              AND (allocation.analysis_material_id = :parentMaterialId
                                  OR EXISTS(SELECT 1 FROM preplan_aggregate_batches batch
                                      WHERE batch.action_id=action.id AND batch.anchor_analysis_item_id=:analysisItemId
                                        AND batch.plan_id=:planId AND batch.route='MAKE'))
                              AND material.goods_id = :goodsId
                              AND material.color_id IS NOT DISTINCT FROM
                                  CAST(:colorId AS uuid)
                            -- 先急后缓(V736/ADR-127)：与车间直送、ADR-120 §3 同一次序——所属产品行的
                            -- 优先级、交期；同时建立的份额不再按随机 UUID 抢先占用。
                            ORDER BY %s
                            FOR UPDATE OF action, allocation
                            """.formatted(ALLOCATION_URGENCY_ORDER))
                            .setParameter("analysisId", analysisId)
                            .setParameter("analysisItemId", analysisItemId)
                            .setParameter("goodsId", line.goodsId())
                            .setParameter("parentMaterialId", parentAnalysisMaterialId)
                            .setParameter("planId",planId)
                            .setParameter("colorId", line.colorId()));
            for (Object[] allocation : allocations) {
                if (remaining.signum() <= 0) break;
                UUID allocationId = (UUID) allocation[0];
                UUID materialId = (UUID) allocation[2];
                if(!directMembers.isEmpty()&&!directMembers.containsKey(allocationId))continue;
                BigDecimal exactAttributed = exactAttributed(allocationId,stockDocumentId);
                BigDecimal capacity = decimal(allocation[3])
                        .subtract(exactAttributed).max(BigDecimal.ZERO);
                BigDecimal legacyRemaining = legacyRemainingByAnalysis
                        .computeIfAbsent(analysisId, ignored ->
                                legacyMakeAttributed(analysisId, analysisItemId));
                BigDecimal legacyUse = capacity.min(legacyRemaining);
                legacyRemainingByAnalysis.put(
                        analysisId, legacyRemaining.subtract(legacyUse));
                BigDecimal take = capacity.subtract(legacyUse)
                        .max(BigDecimal.ZERO).min(remaining);
                if(!directMembers.isEmpty())take=take.min(directMembers.get(allocationId));
                if (take.signum() <= 0) continue;
                var retained=retainedSources.get(allocationId);
                if(retained==null) {
                    requireNoUnprovenCancelledMaterial(materialId);
                    origins.add(insertExactMakeReservation(allocationId, null, analysisId, materialId,
                            warehouseId, line.goodsId(), line.colorId(), take,line.planItemId(), stockDocumentId,line.stockDocumentItemId()));
                } else {
                    requireRetainedSourcesWritable(retained);
                    var slices=retainedReceiptSlices(retained,take);take=slices.stream().map(RetainedReceiptSource::remaining).reduce(BigDecimal.ZERO,BigDecimal::add);
                    for(var slice:slices)origins.add(insertExactMakeReservation(allocationId,null,analysisId,slice.original(),
                            warehouseId,line.goodsId(),line.colorId(),slice.remaining(),line.planItemId(),stockDocumentId,line.stockDocumentItemId(),null,true));
                }
                remaining = remaining.subtract(take);
            }
            if (remaining.signum() > 0 && parentAnalysisMaterialId != null && !aggregateMake) {
                // Current issuance retains a real MAKE_COMPONENT/parent-material
                // anchor without creating a legacy notification action or another BOM.
                BigDecimal capacity = directMakeCapacity(analysisId, analysisItemId,
                        parentAnalysisMaterialId, stockDocumentId);
                BigDecimal take = remaining.min(capacity);
                if (take.signum() > 0) {
                    origins.add(insertExactMakeReservation(null, analysisItemId, analysisId,
                            parentAnalysisMaterialId, warehouseId, line.goodsId(), line.colorId(), take,
                            line.planItemId(), stockDocumentId, line.stockDocumentItemId()));
                }
            }
            // Output beyond original demand plus recorded reallocation make responsibility remains public.
        }
        // All FINISHED_IN lines share the same already-booked stock movement batch.
        // Reserve every source slice before any task may acquire public output.
        applyOriginPriority(origins);
    }

    private BigDecimal directMakeCapacity(UUID analysisId, UUID childId, UUID materialId, UUID currentDocument) {
        return decimal(em.createNativeQuery("""
                WITH budget AS (
                SELECT child.requested_qty,fn_preplan_direct_make_total_capacity(child.id,material.id) AS required_qty,
                    fn_preplan_direct_make_admitted_qty(child.id,material.id) AS admitted_qty,
                    COALESCE((
                    SELECT SUM(exact.qty) FROM preplan_analysis_stock_exact_pegs exact
                    JOIN (SELECT * FROM stock_document_items archive_origin WHERE NULLIF(to_jsonb(archive_origin)->>'legacy_id','') IS NULL AND NULLIF(to_jsonb(archive_origin)->>'legacy_import_run_id','') IS NULL AND NOT fn_imported_business_document_row('stock_document_items',to_jsonb(archive_origin))) stock_item ON stock_item.id=exact.source_stock_document_item_id
                    JOIN (SELECT * FROM stock_documents archive_origin WHERE NULLIF(to_jsonb(archive_origin)->>'legacy_id','') IS NULL AND NULLIF(to_jsonb(archive_origin)->>'legacy_import_run_id','') IS NULL AND NOT fn_imported_business_document_row('stock_documents',to_jsonb(archive_origin))) document ON document.id=stock_item.doc_id
                    JOIN (SELECT * FROM production_plan_items archive_origin WHERE NULLIF(to_jsonb(archive_origin)->>'legacy_id','') IS NULL AND NULLIF(to_jsonb(archive_origin)->>'legacy_import_run_id','') IS NULL AND NOT fn_imported_business_document_row('production_plan_items',to_jsonb(archive_origin))) plan_item ON plan_item.id=stock_item.upstream_item_id
                    JOIN (SELECT * FROM production_plans archive_origin WHERE NULLIF(to_jsonb(archive_origin)->>'legacy_id','') IS NULL AND NULLIF(to_jsonb(archive_origin)->>'legacy_import_run_id','') IS NULL AND NOT fn_imported_business_document_row('production_plans',to_jsonb(archive_origin))) plan ON plan.id=plan_item.plan_id
                    WHERE exact.source_receipt_type='MAKE' AND exact.make_public_claim_id IS NULL
                      AND plan.material_analysis_item_id=child.id
                      AND NOT document.is_deleted AND (document.status=1 OR document.id=:currentDocument)
                ),0) AS attributed_qty,
                    COALESCE((SELECT SUM(LEAST(proof.qty,relation.qty-relation.priority_fulfilled_qty))
                        FROM (SELECT reallocation_id,SUM(qty) AS qty
                              FROM preplan_reallocation_make_supplements
                              WHERE child_analysis_item_id=child.id AND source_analysis_material_id=material.id
                              GROUP BY reallocation_id) proof
                        JOIN preplan_material_reallocations relation ON relation.id=proof.reallocation_id
                        WHERE relation.status IN ('OPEN','PARTIAL')),0) AS outstanding_supplement_qty
                FROM production_material_analysis_items child
                JOIN production_material_analysis_materials material ON material.id=child.parent_analysis_material_id
                  AND material.analysis_id=child.analysis_id AND (material.active OR EXISTS(
                    SELECT 1 FROM preplan_aggregate_material_aliases alias WHERE alias.source_material_id=material.id
                      AND fn_preplan_aggregate_alias_identity_valid(alias.id)))
                WHERE child.id=:child AND child.analysis_id=:analysis AND child.source_type='MAKE_COMPONENT'
                  AND NOT child.is_deleted AND material.id=:material
                )
                SELECT LEAST(GREATEST(admitted_qty-attributed_qty,0),
                    GREATEST(LEAST(requested_qty,required_qty)-attributed_qty,0)+outstanding_supplement_qty)
                FROM budget
                """).setParameter("analysis",analysisId).setParameter("child",childId)
                .setParameter("material",materialId).setParameter("currentDocument",currentDocument).getSingleResult());
    }

    /** Global lock order for analysis-derived plan/package mutations: inventory first. */
    @Override
    @Transactional(propagation = Propagation.MANDATORY)
    public UUID lockPlanningPackageInventoryDimensions(UUID planId) {
        tx.bind();
        if (planId == null) return null;
        List<?> sourceAnalyses = em.createNativeQuery("""
                        SELECT material_analysis_id
                        FROM (SELECT * FROM production_plans archive_origin WHERE NULLIF(to_jsonb(archive_origin)->>'legacy_id','') IS NULL AND NULLIF(to_jsonb(archive_origin)->>'legacy_import_run_id','') IS NULL AND NOT fn_imported_business_document_row('production_plans',to_jsonb(archive_origin))) production_plans
                        WHERE id = :planId
                          AND is_deleted = FALSE
                          AND material_analysis_id IS NOT NULL
                        """)
                .setParameter("planId", planId)
                .getResultList();
        if (sourceAnalyses.isEmpty()) return null;
        if (sourceAnalyses.size() != 1) {
            throw new IllegalStateException("生产计划存在多个来源物料分析身份");
        }
        UUID analysisId = (UUID) sourceAnalyses.getFirst();
        List<Object[]> dimensions = NativeQueryResults.objectArrayRows(
                em.createNativeQuery("""
                        SELECT dimension.goods_id, dimension.color_id
                        FROM (
                            SELECT material.goods_id, material.color_id
                            FROM production_material_analysis_materials material
                            WHERE material.analysis_id = :analysisId
                              AND material.active = TRUE
                            UNION
                            SELECT reservation.goods_id, reservation.color_id
                            FROM stock_reservations reservation
                            WHERE reservation.owner_type = :ownerType
                              AND reservation.owner_id = :analysisId
                              AND reservation.is_deleted = FALSE
                              AND (
                                  (reservation.status = :effective
                                   AND GREATEST(reservation.qty
                                       - reservation.consumed_qty
                                       - reservation.released_qty, 0) > 0)
                                  OR reservation.release_reason = 'TRANSFERRED_TO_PLAN'
                              )
                        ) dimension
                        ORDER BY dimension.goods_id, dimension.color_id NULLS FIRST
                        """)
                        .setParameter("analysisId", analysisId)
                        .setParameter("ownerType", OWNER_TYPE)
                        .setParameter("effective", STATUS_EFFECTIVE));
        inventoryLock.lockAll(dimensions.stream()
                .map(row -> new InventoryKey((UUID) row[0], (UUID) row[1]))
                .toList());
        return analysisId;
    }

    @Override
    @Transactional(propagation = Propagation.MANDATORY)
    public void requirePlanningPackageLifecycleReversible(UUID planId) {
        tx.bind();
        if (planId == null) return;
        List<UUID> transferred = NativeQueryResults.typedRows(em.createNativeQuery("""
                        SELECT reservation.id
                        FROM (SELECT * FROM production_plans archive_origin WHERE NULLIF(to_jsonb(archive_origin)->>'legacy_id','') IS NULL AND NULLIF(to_jsonb(archive_origin)->>'legacy_import_run_id','') IS NULL AND NOT fn_imported_business_document_row('production_plans',to_jsonb(archive_origin))) plan
                        JOIN stock_reservations reservation
                          ON reservation.owner_type = :ownerType
                         AND reservation.owner_id = plan.material_analysis_id
                         AND reservation.is_deleted = FALSE
                         AND reservation.release_reason = 'TRANSFERRED_TO_PLAN'
                        WHERE plan.id = :planId
                         AND NOT EXISTS (
                             SELECT 1
                             FROM preplan_analysis_stock_exact_pegs exact_peg
                             WHERE exact_peg.stock_reservation_id =
                                 reservation.id)
                          AND plan.is_deleted = FALSE
                          AND plan.material_analysis_id IS NOT NULL
                        ORDER BY reservation.id
                        FOR UPDATE OF reservation
                        """)
                .setParameter("ownerType", OWNER_TYPE)
                .setParameter("planId", planId), UUID.class);
        if (!transferred.isEmpty()) {
            throw new ApiException(ErrorCode.CONFLICT,
                    "该计划来源分析已有库存归属转入正式需求；当前没有一对一可逆转移桥，"
                            + "禁止取消或红冲计划包，请提交受控异常处理");
        }
    }

    private void lockClaimantAnalyses(
            UUID externalItemId, UUID goodsId, UUID colorId) {
        em.createNativeQuery("""
                        SELECT analysis.id
                        FROM production_material_analyses analysis
                        WHERE analysis.is_deleted = FALSE
                          AND analysis.status IN (
                              'ACTIVE', 'PARTIALLY_PLANNED', 'COMPLETED')
                          AND analysis.id IN (
                              SELECT allocation.analysis_id
                              FROM preplan_supply_action_allocations allocation
                              JOIN preplan_supply_actions action
                                ON action.id = allocation.action_id
                               AND action.status <> 'CANCELLED'
                              JOIN production_material_analysis_materials material
                                ON material.id = allocation.analysis_material_id
                               AND material.analysis_id = allocation.analysis_id
                               AND material.active = TRUE
                              WHERE allocation.external_item_id = :externalItemId
                                AND material.goods_id = :goodsId
                                AND material.color_id IS NOT DISTINCT FROM
                                    CAST(:colorId AS uuid)
                          )
                        ORDER BY analysis.id
                        FOR UPDATE OF analysis
                        """)
                .setParameter("externalItemId", externalItemId)
                .setParameter("goodsId", goodsId)
                .setParameter("colorId", colorId)
                .getResultList();
    }

    /**
     * Narrow compatibility for an analysis whose full remaining quantity has
     * already become approved WAITING work.  The exact analysis material must
     * still back a live demand on an auto-promotable segment; analysis status or
     * matching goods alone is never sufficient to claim public stock.
     */
    boolean hasAutoPromotableWaitingDemand(
            UUID analysisId, UUID analysisMaterialId) {
        if (analysisId == null || analysisMaterialId == null) return false;
        Object value = em.createNativeQuery("""
                SELECT EXISTS (
                    SELECT 1
                    FROM production_material_analysis_materials material
                    JOIN production_material_analysis_plan_links analysis_link
                      ON analysis_link.analysis_id = material.analysis_id
                     AND analysis_link.analysis_item_id = material.analysis_item_id
                     AND analysis_link.allocation_status = 'APPROVED'
                    JOIN (SELECT * FROM production_plans archive_origin WHERE NULLIF(to_jsonb(archive_origin)->>'legacy_id','') IS NULL AND NULLIF(to_jsonb(archive_origin)->>'legacy_import_run_id','') IS NULL AND NOT fn_imported_business_document_row('production_plans',to_jsonb(archive_origin))) plan
                      ON plan.id = analysis_link.plan_id
                     AND plan.material_analysis_id = material.analysis_id
                     AND plan.material_analysis_item_id = material.analysis_item_id
                     AND plan.status = 1
                     AND plan.is_deleted = FALSE
                     AND plan.is_canceled = FALSE
                    JOIN production_planning_packages package
                      ON package.plan_id = plan.id
                     AND package.status = 'CONFIRMED'
                     AND package.is_deleted = FALSE
                    JOIN production_execution_segments segment
                      ON segment.package_id = package.id
                     AND segment.plan_id = plan.id
                     AND segment.status = 'WAITING'
                     AND segment.auto_promote_when_ready = TRUE
                     AND segment.is_deleted = FALSE
                    JOIN production_material_demands demand
                      ON demand.execution_segment_id = segment.id
                     AND demand.goods_id = material.goods_id
                     AND demand.color_id IS NOT DISTINCT FROM material.color_id
                     AND demand.unit_id = material.unit_id
                     AND demand.status NOT IN ('RELEASED', 'REVERSED')
                     AND demand.is_deleted = FALSE
                    WHERE material.analysis_id = :analysisId
                      AND material.id IN(SELECT material_id FROM fn_preplan_aggregate_material_targets(:analysisMaterialId))
                      AND material.active = TRUE
                )
                """)
                .setParameter("analysisId", analysisId)
                .setParameter("analysisMaterialId", analysisMaterialId)
                .getSingleResult();
        return Boolean.TRUE.equals(value);
    }
    // ============================ 对称释放 ============================

    @Override
    @Transactional(propagation=Propagation.MANDATORY,readOnly=true,noRollbackFor={ApiException.class,IllegalStateException.class})
    public void requireReceiptReversible(String receiptType,UUID receiptId,Collection<UUID> reversibleFormalReservations){
        if(rootSupply!=null)rootSupply.requireReceiptReversible(receiptType,receiptId);
        var formalizations=entitlement.previewActiveFormalizationsAfterUnstartedRelease(reversibleFormalReservations);
        Map<UUID,BigDecimal> restoring=new java.util.HashMap<>();
        formalizations.forEach(row->restoring.merge(row.sourceStockReservationId(),row.qty(),BigDecimal::add));
        var rows=NativeQueryResults.objectArrayRows(em.createNativeQuery("""
            SELECT r.id,r.qty,r.consumed_qty,r.released_qty,r.status,r.release_reason,%s component_handoff
            FROM stock_reservations r
            WHERE r.source_doc_type=:type AND r.source_doc_id=:id AND r.owner_type=:owner AND r.is_deleted=FALSE
              AND (r.status=:effective OR r.release_reason='TRANSFERRED_TO_PLAN' OR %s)
            ORDER BY r.id
            """.formatted(activeComponentHandoff("r.id"),activeComponentHandoff("r.id")))
            .setParameter("type",receiptType+"_RECEIPT").setParameter("id",receiptId).setParameter("owner",OWNER_TYPE).setParameter("effective",STATUS_EFFECTIVE));
        requireReservationsReallocationSafe(rows.stream().map(row->(UUID)row[0]).toList(),"库存归属释放",false);
        for(Object[] row:rows){
            if(Boolean.TRUE.equals(row[6]))throw new ApiException(ErrorCode.CONFLICT,"该收货的分析归属库存仍有未恢复委外发料转移，请先撤回下游");
            if("TRANSFERRED_TO_PLAN".equals(row[5])){
                BigDecimal restores=restoring.getOrDefault((UUID)row[0],BigDecimal.ZERO);
                if(decimal(row[2]).signum()!=0 || restores.compareTo(decimal(row[3]))!=0)
                    throw new ApiException(ErrorCode.CONFLICT,"该收货的分析归属库存仍有不能完整恢复的生产转移，请先撤回下游");
            }
        }
    }

    @Override
    @Transactional(propagation = Propagation.MANDATORY)
    public void releaseForReceipt(String receiptType, UUID receiptId) {
        tx.bind();
        if (rootSupply != null) rootSupply.reverseReceipt(receiptType, receiptId);
        requireNoTransferredReservation(
                receiptType + "_RECEIPT", receiptId,
                "该收货的分析归属库存已转入生产领料或委外发料；请先撤回或红冲对应下游并恢复原归属，"
                        + "禁止直接红冲。无法恢复一对一可逆转移链时，请提交受控异常处理");
        releaseRows(
                "r.source_doc_type = :sourceDocType AND r.source_doc_id = :sourceDocId",
                Map.of(
                        "sourceDocType", receiptType + "_RECEIPT",
                        "sourceDocId", receiptId),
                "PREPLAN_RECEIPT_REVERSED");
    }

    @Override
    @Transactional(propagation = Propagation.MANDATORY)
    public void requireFinishedInboundReversible(UUID stockDocumentId) {
        tx.bind();
        requireNoTransferredReservation(
                "PRODUCTION_INBOUND", stockDocumentId,
                "该成品入库的分析归属库存已转入生产领料或委外发料；请先撤回或红冲对应下游并恢复原归属，"
                        + "禁止直接红冲。无法恢复一对一可逆转移链时，请提交受控异常处理");
        entitlement.restoreAggregateDelegationsForFinishedInbound(stockDocumentId);
        prepareEntitlementRelease("PRODUCTION_INBOUND", stockDocumentId);
    }

    private void prepareEntitlementRelease(
            String sourceDocType, UUID sourceDocId) {
        List<UUID> reservationIds = NativeQueryResults.typedRows(
                em.createNativeQuery("""
                        SELECT reservation.id
                        FROM stock_reservations reservation
                        WHERE reservation.is_deleted = FALSE
                          AND reservation.status = :effective
                          AND reservation.owner_type = :ownerType
                          AND reservation.source_doc_type = :sourceDocType
                          AND reservation.source_doc_id = :sourceDocId
                          AND reservation.qty - reservation.consumed_qty
                              - reservation.released_qty > 0
                        ORDER BY reservation.id
                        FOR UPDATE OF reservation
                        """)
                        .setParameter("effective", STATUS_EFFECTIVE)
                        .setParameter("ownerType", OWNER_TYPE)
                        .setParameter("sourceDocType", sourceDocType)
                        .setParameter("sourceDocId", sourceDocId),
                UUID.class);
        requireReservationsReallocationSafe(
                reservationIds, "成品入库红冲");
        for (UUID reservationId : reservationIds) {
            entitlement.appendReleaseForReservation(
                    reservationId, sourceDocId,
                    "PREPLAN-RELEASE:" + reservationId);
        }
    }

    private void requireNoTransferredReservation(
            String sourceDocType, UUID sourceDocId, String conflictMessage) {
        List<UUID> transferred = NativeQueryResults.typedRows(em.createNativeQuery("""
                SELECT reservation.id
                FROM stock_reservations reservation
                WHERE reservation.is_deleted = FALSE
                  AND reservation.owner_type = :ownerType
                  AND reservation.source_doc_type = :sourceDocType
                  AND reservation.source_doc_id = :sourceDocId
                  AND (reservation.release_reason = 'TRANSFERRED_TO_PLAN'
                       OR %s)
                ORDER BY reservation.id
                FOR UPDATE
                """.formatted(activeComponentHandoff("reservation.id")))
                .setParameter("ownerType", OWNER_TYPE)
                .setParameter("sourceDocType", sourceDocType)
                .setParameter("sourceDocId", sourceDocId), UUID.class);
        if (!transferred.isEmpty()) {
            throw new ApiException(ErrorCode.CONFLICT, conflictMessage);
        }
    }

    @Override
    @Transactional(propagation = Propagation.MANDATORY)
    public void releaseForAnalysis(
            UUID analysisId,
            String reason,
            String cancellationIdempotencyKey) {
        tx.bind();
        String cancellationKey = Objects.requireNonNull(
                cancellationIdempotencyKey,
                "cancellationIdempotencyKey").strip();
        if (cancellationKey.isEmpty()) {
            throw new IllegalArgumentException(
                    "cancellationIdempotencyKey must not be blank");
        }
        String releaseReason =
                normalizeReason(reason, "PREPLAN_ANALYSIS_CANCELLED");
        entitlement.requireNoActiveFormalizationForBeneficiary(
                analysisId, true);
        requireAnalysisCancellationSafe(analysisId);
        String eventPrefix = "PREPLAN-ANALYSIS-CANCEL:"
                + PlanningPackageFingerprint.sha256(List.of(
                        analysisId.toString(), cancellationKey));
        List<PreplanStockEntitlementService.ReservationRelease> slices =
                entitlement.appendReleaseForBeneficiaryAnalysis(
                        analysisId, analysisId, eventPrefix);
        applyBeneficiaryReleaseSlices(slices, releaseReason);
        releaseRows(
                """
                r.owner_id = :analysisId
                AND NOT EXISTS (
                    SELECT 1
                    FROM preplan_stock_entitlement_events event
                    WHERE event.stock_reservation_id = r.id)
                """,
                Map.of("analysisId", analysisId),
                releaseReason);
        closeFulfilledReallocations(
                analysisId, releaseReason, cancellationKey);
    }

    @Override
    @Transactional(propagation = Propagation.MANDATORY)
    public void releaseForSupplyItems(
            UUID analysisId, Collection<UUID> externalItemIds, String reason) {
        tx.bind();
        if (externalItemIds == null || externalItemIds.isEmpty()) {
            return;
        }
        releaseRows(
                "r.owner_id = :analysisId AND r.supply_id IN (:supplyIds)",
                Map.of("analysisId", analysisId, "supplyIds", externalItemIds),
                normalizeReason(reason, "PREPLAN_ACTION_CANCELLED"));
    }

    /** Release only exact rows sourced by one claim action's allocations. */
    @Transactional(propagation = Propagation.MANDATORY)
    public void releaseForAction(
            UUID analysisId, UUID actionId, String reason) {
        tx.bind();
        releaseRows(
                "r.owner_id = :analysisId AND EXISTS ("
                        + "SELECT 1 FROM preplan_analysis_stock_exact_pegs exact "
                        + "JOIN preplan_supply_action_allocations allocation "
                        + "ON allocation.id = exact.supply_action_allocation_id "
                        + "WHERE exact.stock_reservation_id = r.id "
                        + "AND allocation.action_id = :actionId)",
                Map.of("analysisId", analysisId, "actionId", actionId),
                normalizeReason(reason, "PREPLAN_SHARED_FUTURE_CLAIM_CANCELLED"));
    }

    // ============================ 下达计划包转移 ============================
    @Override
    @Transactional(propagation = Propagation.MANDATORY)
    public List<PreparedPlanTransfer> transferToPlanDemands(
            UUID analysisId, UUID planId,
            UUID warehouseId, List<DemandSlice> demands) {
        return transferToPlanDemands(analysisId, planId, warehouseId, demands, null, false);
    }

    @Override
    @Transactional(propagation = Propagation.MANDATORY)
    public List<PreparedPlanTransfer> transferToPlanDemands(
            UUID analysisId, UUID planId, UUID warehouseId,
            List<DemandSlice> demands, UUID actorId) {
        entitlement.requireFormalizationActor(actorId);
        return transferToPlanDemands(analysisId, planId, warehouseId, demands, actorId, true);
    }

    private List<PreparedPlanTransfer> transferToPlanDemands(
            UUID analysisId, UUID planId, UUID warehouseId,
            List<DemandSlice> demands, UUID actorId, boolean explicitActor) {
        return selectPlanDemandTransfers(analysisId,planId,warehouseId,demands,actorId,explicitActor,true,null,false);
    }

    /**
     * 线边仓叶仓内的权益转正(V595)：批次只取 {@code leafWarehouseId} 这一个叶仓(不同主仓、不跟合格
     * 来源跨仓)，其余选源顺序、预算与绑定规则与 {@link #transferToPlanDemands} 完全相同。
     */
    @Override
    @Transactional(propagation = Propagation.MANDATORY)
    public List<PreparedPlanTransfer> transferToPlanDemandsWithinWarehouse(
            UUID analysisId, UUID planId, UUID leafWarehouseId, List<DemandSlice> demands) {
        return selectPlanDemandTransfers(analysisId,planId,leafWarehouseId,demands,null,false,true,null,true);
    }

    @Override
    @Transactional(readOnly = true)
    public List<PreviewPlanTransfer> previewPlanDemandTransfers(UUID analysisId,UUID planId,
                                                               UUID warehouseId,List<DemandSlice> demands) {
        List<PreviewPlanTransfer> preview=new ArrayList<>();
        selectPlanDemandTransfers(analysisId,planId,warehouseId,demands,null,false,false,preview,false);
        return List.copyOf(preview);
    }

    @Override
    @Transactional(readOnly = true)
    public List<PreviewPlanTransfer> previewAnalysisDemandTransfers(UUID analysisId, UUID warehouseId,
            List<DemandSlice> demands, List<UUID> matchingMaterialIds,
            List<PreviewPlanTransfer> priorTransfers, List<PreviewPublicReservation> priorPublicReservations) {
        if (demands.isEmpty()) return List.of();
        List<UUID> materials = matchingMaterialIds.stream().distinct().toList();
        if (analysisId == null || !materials.isEmpty() && ((Number) em.createNativeQuery("""
                SELECT COUNT(*) FROM production_material_analysis_materials
                WHERE analysis_id=:analysis AND id IN (:ids) AND active
                """).setParameter("analysis", analysisId).setParameter("ids", materials).getSingleResult()).intValue() != materials.size()) {
            throw new IllegalStateException("Issue preview lacks its original analysis material identities");
        }
        if (materials.isEmpty() && ((Number)em.createNativeQuery("""
                SELECT COUNT(*) FROM production_material_demands demand JOIN (SELECT * FROM production_plans archive_origin WHERE NULLIF(to_jsonb(archive_origin)->>'legacy_id','') IS NULL AND NULLIF(to_jsonb(archive_origin)->>'legacy_import_run_id','') IS NULL AND NOT fn_imported_business_document_row('production_plans',to_jsonb(archive_origin))) plan ON plan.id=demand.plan_id
                WHERE demand.id IN (:ids) AND NOT demand.is_deleted AND plan.material_analysis_id=:analysis
                """).setParameter("ids",demands.stream().map(DemandSlice::demandId).distinct().toList())
                .setParameter("analysis",analysisId).getSingleResult()).intValue()!=demands.size())
            throw new IllegalStateException("Issue preview lacks its original frozen demand identities");
        List<PreviewPlanTransfer> preview = new ArrayList<>();
        selectPlanDemandTransfers(analysisId, null, warehouseId, demands, null, false, false, preview, false,
                materials, priorTransfers, priorPublicReservations);
        return List.copyOf(preview);
    }

    /**
     * @param leafOnly 只取 {@code warehouseId} 这一个叶仓里的批次(V595 线边仓补投)；false 时按
     *                 「同主仓 + 合格来源跟随实际仓」的下达口径选源。
     */
    private List<PreparedPlanTransfer> selectPlanDemandTransfers(UUID analysisId,UUID planId,UUID warehouseId,
            List<DemandSlice> demands,UUID actorId,boolean explicitActor,boolean write,List<PreviewPlanTransfer> preview,
            boolean leafOnly) {
        return selectPlanDemandTransfers(analysisId, planId, warehouseId, demands, actorId, explicitActor,
                write, preview, leafOnly, null, List.of(), List.of());
    }

    private List<PreparedPlanTransfer> selectPlanDemandTransfers(UUID analysisId, UUID planId, UUID warehouseId,
            List<DemandSlice> demands, UUID actorId, boolean explicitActor, boolean write, List<PreviewPlanTransfer> preview,
            boolean leafOnly, List<UUID> previewMaterials, List<PreviewPlanTransfer> priorTransfers,
            List<PreviewPublicReservation> priorPublicReservations) {
        if(write)tx.bind();
        if (analysisId == null || (planId == null && previewMaterials == null) || warehouseId == null
                || demands == null || demands.isEmpty()) {
            return List.of();
        }
        if (write && previewMaterials != null) throw new IllegalStateException("Memory-only material scope cannot write");
        List<UUID> analysisItemIds = previewMaterials != null ? List.of() : NativeQueryResults.typedRows(
                em.createNativeQuery("""
                        SELECT material_analysis_item_id
                        FROM (SELECT * FROM production_plans archive_origin WHERE NULLIF(to_jsonb(archive_origin)->>'legacy_id','') IS NULL AND NULLIF(to_jsonb(archive_origin)->>'legacy_import_run_id','') IS NULL AND NOT fn_imported_business_document_row('production_plans',to_jsonb(archive_origin))) production_plans
                        WHERE id = :planId
                          AND material_analysis_id = :analysisId
                          AND material_analysis_item_id IS NOT NULL
                          AND is_deleted = FALSE
                        """)
                        .setParameter("planId", planId)
                        .setParameter("analysisId", analysisId),
                UUID.class);
        if (previewMaterials == null && analysisItemIds.size() != 1) {
            throw new IllegalStateException(
                    "Formal plan lacks one material-analysis item identity");
        }
        UUID analysisItemId = analysisItemIds.isEmpty() ? null : analysisItemIds.getFirst();
        List<DemandSlice> orderedDemands = demands.stream()
                .filter(demand -> demand != null
                        && demand.demandId() != null
                        && demand.goodsId() != null
                        && demand.requiredQty() != null
                        && demand.requiredQty().signum() > 0)
                .sorted(Comparator
                        .comparing(DemandSlice::goodsId)
                        .thenComparing(demand ->
                                Objects.toString(demand.colorId(), ""))
                        .thenComparing(DemandSlice::demandId))
                .toList();
        if (orderedDemands.isEmpty()) {
            return List.of();
        }

        List<PreparedPlanTransfer> prepared = new ArrayList<>();
        Map<UUID, BigDecimal> preparedByEntitlementLot = new HashMap<>();
        Map<UUID, BigDecimal> priorByReservation = new HashMap<>();
        Map<UUID, BigDecimal> priorLegacy = new HashMap<>();
        for (PreviewPlanTransfer prior : priorTransfers) {
            if (prior.sourceEntitlementEventId() != null) preparedByEntitlementLot.merge(
                    prior.sourceEntitlementEventId(), prior.qty(), BigDecimal::add);
            else if (prior.sourceReservationId() != null) priorLegacy.merge(prior.sourceReservationId(), prior.qty(), BigDecimal::add);
            if (prior.sourceReservationId() != null && (prior.beneficiaryMaterialId() == null
                    || previewMaterials != null && previewMaterials.contains(prior.beneficiaryMaterialId()))) {
                priorByReservation.merge(prior.sourceReservationId(), prior.qty(), BigDecimal::add);
            }
        }
        Map<TransferDimension, BigDecimal> transferableByDimension = new HashMap<>();
        Map<UUID,Boolean> qualifiedByReservation=new HashMap<>();
        for (DemandSlice demand : orderedDemands) {
            if(write)inventoryLock.lock(new InventoryKey(demand.goodsId(), demand.colorId()));
            BigDecimal remaining = demand.requiredQty();
            var materialQuery = em.createNativeQuery("""
                            SELECT id
                            FROM production_material_analysis_materials
                            WHERE analysis_id = :analysisId
                              AND %s
                              AND goods_id = :goodsId
                              AND color_id IS NOT DISTINCT FROM
                                  CAST(:colorId AS uuid)
                              AND active = TRUE
                            ORDER BY path, id
                            """.formatted(previewMaterials == null
                                    ? "fn_analysis_plan_material_matches(:analysisItemId, id)" : previewMaterials.isEmpty()?"FALSE":"id IN (:previewMaterials)"))
                            .setParameter("analysisId", analysisId)
                            .setParameter("goodsId", demand.goodsId())
                            .setParameter("colorId", demand.colorId());
            if (previewMaterials == null) materialQuery.setParameter("analysisItemId", analysisItemId);
            else if(!previewMaterials.isEmpty()) materialQuery.setParameter("previewMaterials", previewMaterials);
            List<UUID> materialIds = NativeQueryResults.typedRows(materialQuery, UUID.class);
            for (UUID materialId : materialIds) {
                if (remaining.signum() <= 0) break;
                List<PreplanStockEntitlementService.AvailableLot> lots = leafOnly
                        ? entitlement.listAvailableBeneficiaryLots(
                                analysisId, materialId, warehouseId,
                                demand.goodsId(), demand.colorId(), write)
                        : entitlement.listAvailableBeneficiaryLotsForProduction(
                                analysisId, materialId, warehouseId,
                                demand.goodsId(), demand.colorId(), write);
                Set<UUID> allowedSources=lots.isEmpty()?Set.of():new java.util.HashSet<>(NativeQueryResults.typedRows(
                        em.createNativeQuery("""
                                SELECT source.id FROM stock_reservations source
                                JOIN warehouses warehouse ON warehouse.id=source.warehouse_id
                                WHERE source.id IN (:sources)
                                  AND (NOT warehouse.is_line_side OR fn_workshop_entitlement_source_allows(source.id,:demand))
                                """,UUID.class).setParameter("sources",lots.stream().map(PreplanStockEntitlementService.AvailableLot::stockReservationId).distinct().toList())
                                .setParameter("demand",demand.demandId()),UUID.class));
                for (PreplanStockEntitlementService.AvailableLot lot : lots) {
                    if (remaining.signum() <= 0) break;
                    if (!allowedSources.contains(lot.stockReservationId())) continue;
                    BigDecimal alreadyPrepared = preparedByEntitlementLot
                            .getOrDefault(lot.entitlementEventId(), BigDecimal.ZERO);
                    BigDecimal available = lot.remainingQty()
                            .subtract(alreadyPrepared).max(BigDecimal.ZERO);
                    TransferDimension dimension = new TransferDimension(
                            lot.warehouseId(), demand.goodsId(), demand.colorId());
                    BigDecimal budget = transferableByDimension.computeIfAbsent(
                            dimension, ignored -> formalTransferBudget(
                                    analysisId, analysisItemId, warehouseId, dimension, previewMaterials,
                                    priorByReservation, priorPublicReservations));
                    BigDecimal take = available.min(remaining).min(budget);
                    if (take.signum() <= 0) continue;
                    if(write)consumeForFormalize(lot.stockReservationId(), take, actorId, explicitActor);
                    if(preview!=null)preview.add(new PreviewPlanTransfer(demand.demandId(),lot.warehouseId(),take,
                            qualifiedByReservation.computeIfAbsent(lot.stockReservationId(),reservationId->Boolean.TRUE.equals(
                                    em.createNativeQuery("SELECT fn_preplan_reservation_has_qualified_origin(:id)")
                                            .setParameter("id",reservationId).getSingleResult())),true,
                            lot.stockReservationId(), lot.entitlementEventId(), lot.beneficiaryAnalysisMaterialId()));
                    transferableByDimension.put(dimension, budget.subtract(take));
                    prepared.add(new PreparedPlanTransfer(
                            lot.entitlementEventId(), lot.stockReservationId(),
                            lot.beneficiaryAnalysisId(),
                            lot.beneficiaryAnalysisMaterialId(),
                            demand.demandId(), take, lot.warehouseId()));
                    preparedByEntitlementLot.merge(
                            lot.entitlementEventId(), take, BigDecimal::add);
                    remaining = remaining.subtract(take);
                }
            }

            // Historical V298 rows deliberately have no entitlement event.
            // Preserve their analysis-pool behavior, but do not invent a
            // reversible event lineage for them.
            if (remaining.signum() > 0) {
                List<Object[]> legacyRows = NativeQueryResults.objectArrayRows(
                        em.createNativeQuery("""
                                SELECT reservation.id,
                                       reservation.qty
                                           - reservation.consumed_qty
                                           - reservation.released_qty,
                                       reservation.warehouse_id
                                FROM stock_reservations reservation
                                WHERE reservation.is_deleted = FALSE
                                  AND reservation.status = :effective
                                  AND reservation.owner_type = :ownerType
                                  AND reservation.owner_id = :analysisId
                                  AND %s
                                  AND reservation.goods_id = :goodsId
                                  AND reservation.color_id IS NOT DISTINCT FROM
                                      CAST(:colorId AS uuid)
                                  AND NOT EXISTS (
                                      SELECT 1
                                      FROM preplan_analysis_stock_exact_pegs exact_peg
                                      WHERE exact_peg.stock_reservation_id =
                                          reservation.id)
                                  AND NOT EXISTS (
                                      SELECT 1
                                      FROM preplan_stock_entitlement_events event
                                      WHERE event.stock_reservation_id =
                                          reservation.id)
                                ORDER BY reservation.created_at, reservation.id
                                %s
                                """.formatted(leafOnly
                                        ? "reservation.warehouse_id = :warehouseId"
                                        : "fn_warehouse_same_main(reservation.warehouse_id, :warehouseId)",
                                        write?"FOR UPDATE OF reservation":""))
                                .setParameter("effective", STATUS_EFFECTIVE)
                                .setParameter("ownerType", OWNER_TYPE)
                                .setParameter("analysisId", analysisId)
                                .setParameter("warehouseId", warehouseId)
                                .setParameter("goodsId", demand.goodsId())
                                .setParameter("colorId", demand.colorId()));
                for (Object[] row : legacyRows) {
                    if (remaining.signum() <= 0) break;
                    TransferDimension dimension = new TransferDimension(
                            (UUID) row[2], demand.goodsId(), demand.colorId());
                    BigDecimal budget = transferableByDimension.computeIfAbsent(
                            dimension, ignored -> formalTransferBudget(
                                    analysisId, analysisItemId, warehouseId, dimension, previewMaterials,
                                    priorByReservation, priorPublicReservations));
                    BigDecimal take = decimal(row[1]).subtract(priorLegacy.getOrDefault((UUID) row[0], BigDecimal.ZERO)).max(BigDecimal.ZERO)
                            .min(remaining).min(budget);
                    if (take.signum() <= 0) continue;
                    if(write)consumeForFormalize((UUID) row[0], take, actorId, explicitActor);
                    if(preview!=null)preview.add(new PreviewPlanTransfer(demand.demandId(),(UUID)row[2],take,false,false,
                            (UUID) row[0], null, null));
                    if (!write) priorLegacy.merge((UUID) row[0], take, BigDecimal::add);
                    transferableByDimension.put(dimension, budget.subtract(take));
                    remaining = remaining.subtract(take);
                }
            }
        }
        return List.copyOf(prepared);
    }

    private void consumeForFormalize(UUID reservationId, BigDecimal qty, UUID actorId, boolean explicitActor) {
        if (explicitActor) entitlement.consumePhysicalForFormalize(reservationId, qty, actorId);
        else entitlement.consumePhysicalForFormalize(reservationId, qty);
    }

    /** Qualified owned stock follows its actual leaf. Public/legacy stock keeps the normal local safety floor. */
    private BigDecimal formalTransferBudget(
            UUID analysisId, UUID analysisItemId, UUID plannedWarehouseId, TransferDimension dimension,
            List<UUID> previewMaterials, Map<UUID, BigDecimal> priorByReservation,
            List<PreviewPublicReservation> priorPublicReservations) {
        BigDecimal priorPublic = priorPublicReservations.stream().filter(value ->
                value.warehouseId().equals(dimension.warehouseId()) && value.goodsId().equals(dimension.goodsId())
                        && Objects.equals(value.colorId(), dimension.colorId()))
                .map(PreviewPublicReservation::qty).reduce(BigDecimal.ZERO, BigDecimal::add);
        var query = em.createNativeQuery("""
                WITH physical AS (
                    SELECT COALESCE(stock.qty,0) AS stock_qty,
                    COALESCE((SELECT SUM(r.qty-r.consumed_qty-r.released_qty)
                        FROM stock_reservations r
                        WHERE r.goods_id = :goodsId
                          AND r.color_id IS NOT DISTINCT FROM CAST(:colorId AS uuid)
                          AND (r.warehouse_id IS NULL OR r.warehouse_id = :warehouseId)
                          AND r.status = 0 AND r.is_deleted = FALSE), 0) + :previewPublic AS reserved_qty,
                    GREATEST(COALESCE(goods.min_qty,0),0)::numeric AS safety_qty,
                    (NOT warehouse.is_defective AND NOT warehouse.is_line_side
                     AND fn_warehouse_same_main(warehouse.id,:plannedWarehouseId)) AS local_normal
                    FROM goods JOIN warehouses warehouse ON warehouse.id=:warehouseId
                      AND NOT warehouse.is_deleted AND warehouse.is_accountable
                      AND fn_warehouse_is_operational_leaf(warehouse.id)
                    LEFT JOIN v_stock_operable_balances stock ON stock.goods_id=goods.id
                      AND stock.color_id IS NOT DISTINCT FROM CAST(:colorId AS uuid) AND stock.warehouse_id=warehouse.id
                    WHERE goods.id=:goodsId AND NOT goods.is_deleted
                ), owned AS (
                    SELECT fn_preplan_reservation_has_qualified_origin(owned.id) AS qualified,
                        GREATEST(CASE
                        WHEN EXISTS (SELECT 1 FROM preplan_stock_entitlement_events tracked
                            WHERE tracked.stock_reservation_id = owned.id)
                        THEN COALESCE((SELECT SUM(entitlement.effective_qty)
                            FROM v_preplan_stock_entitlement_beneficiary_balance entitlement
                            WHERE entitlement.stock_reservation_id = owned.id
                              AND entitlement.beneficiary_analysis_id = :analysisId
                              AND %s), 0)
                        WHEN owned.owner_id = :analysisId
                        THEN owned.qty-owned.consumed_qty-owned.released_qty
                        ELSE 0 END - COALESCE((SELECT used.qty
                            FROM jsonb_to_recordset(CAST(:previewUsed AS jsonb)) used(id uuid, qty numeric)
                            WHERE used.id=owned.id), 0), 0) AS qty
                        FROM stock_reservations owned
                        WHERE owned.goods_id = :goodsId
                          AND owned.color_id IS NOT DISTINCT FROM CAST(:colorId AS uuid)
                          AND owned.warehouse_id = :warehouseId
                          AND owned.owner_type = 'PREPLAN_ANALYSIS'
                          AND owned.status = 0 AND owned.is_deleted = FALSE
                ), amounts AS (
                    SELECT physical.*,
                        COALESCE((SELECT SUM(qty) FROM owned WHERE qualified),0) AS qualified_qty,
                        CASE WHEN local_normal THEN COALESCE((SELECT SUM(qty) FROM owned WHERE NOT qualified),0)
                             ELSE 0 END AS legacy_qty
                    FROM physical
                )
                SELECT GREATEST(LEAST(stock_qty-reserved_qty+qualified_qty+legacy_qty,
                    qualified_qty+CASE WHEN local_normal THEN GREATEST(stock_qty-reserved_qty+legacy_qty-safety_qty,0)
                                       ELSE 0 END),0)
                FROM amounts
                """.formatted(previewMaterials == null
                        ? "fn_analysis_plan_material_matches(:analysisItemId, entitlement.beneficiary_analysis_material_id)"
                        : previewMaterials.isEmpty()?"FALSE":"entitlement.beneficiary_analysis_material_id IN (:previewMaterials)"))
                .setParameter("analysisId", analysisId)
                .setParameter("plannedWarehouseId", plannedWarehouseId)
                .setParameter("goodsId", dimension.goodsId())
                .setParameter("colorId", dimension.colorId())
                .setParameter("warehouseId", dimension.warehouseId())
                .setParameter("previewPublic", priorPublic)
                .setParameter("previewUsed", new com.fasterxml.jackson.databind.ObjectMapper().valueToTree(
                        priorByReservation.entrySet().stream().map(entry -> Map.of("id", entry.getKey(), "qty", entry.getValue())).toList()).toString());
        if (previewMaterials == null) query.setParameter("analysisItemId", analysisItemId);
        else if(!previewMaterials.isEmpty()) query.setParameter("previewMaterials", previewMaterials);
        List<?> values = query.getResultList();
        return values.isEmpty() ? BigDecimal.ZERO : decimal(values.getFirst());
    }

    private record TransferDimension(UUID warehouseId, UUID goodsId, UUID colorId) {
    }

    @Override
    @Transactional(propagation = Propagation.MANDATORY)
    public void formalizePlanDemandTransfers(
            UUID packageId,
            List<PreparedPlanTransfer> prepared,
            List<FormalReservationSlice> formalReservations) {
        formalizePlanDemandTransfers(packageId, prepared, formalReservations, null, false);
    }

    @Override
    @Transactional(propagation = Propagation.MANDATORY)
    public void formalizePlanDemandTransfers(
            UUID packageId, List<PreparedPlanTransfer> prepared,
            List<FormalReservationSlice> formalReservations, UUID actorId) {
        entitlement.requireFormalizationActor(actorId);
        formalizePlanDemandTransfers(packageId, prepared, formalReservations, actorId, true, null);
    }

    @Override
    @Transactional(propagation = Propagation.MANDATORY)
    public void formalizePlanDemandTransfersForCommand(
            UUID packageId, List<PreparedPlanTransfer> prepared,
            List<FormalReservationSlice> formalReservations, String commandKey) {
        if (commandKey == null || commandKey.isBlank()) {
            throw new ApiException(ErrorCode.VALIDATION_FAILED, "分批转正缺少命令键");
        }
        formalizePlanDemandTransfers(packageId, prepared, formalReservations, null, false, commandKey);
    }

    @Override
    @Transactional(propagation = Propagation.MANDATORY)
    public void formalizePlanDemandTransfersForCommand(UUID packageId,
            List<PreparedPlanTransfer> prepared, List<FormalReservationSlice> formalReservations,
            String commandKey, UUID actorId) {
        if (commandKey == null || commandKey.isBlank()) {
            throw new ApiException(ErrorCode.VALIDATION_FAILED, "持续补料转正缺少命令键");
        }
        entitlement.requireFormalizationActor(actorId);
        formalizePlanDemandTransfers(packageId, prepared, formalReservations, actorId, true, commandKey);
    }

    private void formalizePlanDemandTransfers(
            UUID packageId, List<PreparedPlanTransfer> prepared,
            List<FormalReservationSlice> formalReservations, UUID actorId, boolean explicitActor) {
        formalizePlanDemandTransfers(packageId, prepared, formalReservations, actorId, explicitActor, null);
    }

    /** @param commandKey 非空时拼进 FORMALIZE 幂等键(V595 线边仓分次补投)，空时保持下达一次性的原键。 */
    private void formalizePlanDemandTransfers(
            UUID packageId, List<PreparedPlanTransfer> prepared,
            List<FormalReservationSlice> formalReservations, UUID actorId, boolean explicitActor,
            String commandKey) {
        tx.bind();
        if (prepared == null || prepared.isEmpty()) return;
        List<FormalReservationSlice> formal = formalReservations == null
                ? List.of() : formalReservations.stream()
                .filter(value -> value != null && value.stockReservationId() != null)
                .toList();
        Set<UUID> reservationIds = new LinkedHashSet<>();
        prepared.forEach(value -> reservationIds.add(value.sourceStockReservationId()));
        formal.forEach(value -> reservationIds.add(value.stockReservationId()));
        Map<UUID, UUID> warehouseByReservation = new HashMap<>();
        NativeQueryResults.objectArrayRows(em.createNativeQuery("""
                SELECT id, warehouse_id FROM stock_reservations
                WHERE id IN (:ids) AND is_deleted = FALSE
                """).setParameter("ids", reservationIds))
                .forEach(row -> warehouseByReservation.put((UUID) row[0], (UUID) row[1]));
        Map<UUID, BigDecimal> availableByReservation = new LinkedHashMap<>();
        formal.forEach(value -> {
            if (availableByReservation.put(value.stockReservationId(), value.qty()) != null) {
                throw new IllegalStateException("Duplicate formal stock reservation");
            }
        });
        for (PreparedPlanTransfer slice : prepared) {
            UUID sourceWarehouse = warehouseByReservation.get(slice.sourceStockReservationId());
            if (sourceWarehouse == null || (slice.warehouseId() != null
                    && !sourceWarehouse.equals(slice.warehouseId()))) {
                throw new ApiException(ErrorCode.CONFLICT,
                        "分析备料权益的实际仓库已变化，请刷新后重试");
            }
            BigDecimal remaining = slice.qty();
            for (FormalReservationSlice target : formal) {
                if (remaining.signum() <= 0) break;
                if (!slice.demandId().equals(target.demandId())
                        || !sourceWarehouse.equals(warehouseByReservation.get(
                                target.stockReservationId()))) continue;
                BigDecimal available = availableByReservation.get(target.stockReservationId());
                BigDecimal take = remaining.min(available);
                if (take.signum() <= 0) continue;
                // 基础键 165 字符，事件键上限 200(V309)：命令键只拼 SHA-256 前 32 位。
                String key = "PREPLAN-FORMALIZE:" + packageId + ":" + slice.demandId() + ":"
                        + slice.sourceEntitlementEventId() + ":" + target.stockReservationId()
                        + (commandKey == null ? "" : ":" + CanonicalFingerprint.sha256(
                                List.of(commandKey)).substring(0, 32));
                if (explicitActor) {
                    entitlement.appendFormalize(packageId,
                            slice.sourceEntitlementEventId(), slice.sourceStockReservationId(),
                            slice.beneficiaryAnalysisId(), slice.beneficiaryAnalysisMaterialId(),
                            take, packageId, slice.demandId(), target.stockReservationId(), key, actorId);
                } else {
                    entitlement.appendFormalize(packageId,
                            slice.sourceEntitlementEventId(), slice.sourceStockReservationId(),
                            slice.beneficiaryAnalysisId(), slice.beneficiaryAnalysisMaterialId(),
                            take, packageId, slice.demandId(), target.stockReservationId(), key);
                }
                availableByReservation.put(target.stockReservationId(), available.subtract(take));
                remaining = remaining.subtract(take);
            }
            if (remaining.signum() > 0) {
                throw new ApiException(ErrorCode.CONFLICT,
                        "正式领料预留未覆盖分析备料权益的实际子仓数量");
            }
        }
    }

    @Override
    @Transactional(propagation = Propagation.MANDATORY)
    public void restorePlanDemandTransfers(
            Collection<UUID> formalReservationIds) {
        tx.bind();
        List<PreplanStockEntitlementService.Formalization> formalizations =
                entitlement.listActiveFormalizations(
                        formalReservationIds, true);
        for (PreplanStockEntitlementService.Formalization formalization
                : formalizations) {
            entitlement.appendRestore(
                    formalization.targetPackageId(), formalization,
                    "PREPLAN-RESTORE:" + formalization.formalizeEventId());
            entitlement.restorePhysicalAfterFormalRelease(
                    formalization.sourceStockReservationId(),
                    formalization.qty());
        }
    }

    // ============================ 内部原语 ============================

    private BigDecimal activeFormalMakeCommitment(UUID planItemId) {
        return decimal(em.createNativeQuery("""
                SELECT COALESCE(SUM(GREATEST(
                    peg.allocated_qty - peg.consumed_qty - peg.released_qty,
                    0)), 0)
                FROM production_material_supply_pegs peg
                WHERE peg.supply_type = 'PRODUCTION_PLAN_ITEM'
                  AND peg.supply_item_id = :planItemId
                  AND peg.status <> 'REVERSED'
                """).setParameter("planItemId", planItemId).getSingleResult());
    }

    BigDecimal exactAttributed(UUID allocationId) {
        return exactAttributed(allocationId,null);
    }

    private BigDecimal exactAttributed(UUID allocationId,UUID currentDocumentId) {
        return decimal(em.createNativeQuery("""
                SELECT COALESCE(SUM(peg.qty), 0)
                FROM preplan_analysis_stock_exact_pegs peg
                LEFT JOIN procurement_inspection_events disposition
                  ON disposition.id = peg.source_disposition_event_id
                LEFT JOIN procurement_inspection_items inspection
                  ON inspection.id = disposition.inspection_item_id
                LEFT JOIN (SELECT * FROM stock_documents archive_origin WHERE NULLIF(to_jsonb(archive_origin)->>'legacy_id','') IS NULL AND NULLIF(to_jsonb(archive_origin)->>'legacy_import_run_id','') IS NULL AND NOT fn_imported_business_document_row('stock_documents',to_jsonb(archive_origin))) stock_document
                  ON stock_document.id = peg.source_stock_document_id
                WHERE peg.supply_action_allocation_id = :allocationId
                  AND (
                      (
                          peg.source_receipt_type IN ('PURCHASE', 'SUBCONTRACT')
                          AND disposition.id IS NOT NULL
                          AND inspection.id IS NOT NULL
                          AND inspection.status <> 'REVERSED'
                      )
                      OR
                      (
                          peg.source_receipt_type = 'MAKE'
                          AND stock_document.id IS NOT NULL
                          AND (stock_document.status = 1 OR stock_document.id=CAST(:currentDocumentId AS uuid))
                          AND stock_document.is_deleted = FALSE
                      )
                  )
                """)
                .setParameter("allocationId", allocationId)
                .setParameter("currentDocumentId",currentDocumentId)
                .getSingleResult());
    }

    BigDecimal legacyMakeAttributed(UUID analysisId, UUID analysisItemId) {
        return decimal(em.createNativeQuery("""
                SELECT COALESCE(SUM(CASE
                    WHEN reservation.release_reason = 'TRANSFERRED_TO_PLAN'
                    THEN reservation.qty
                    ELSE reservation.qty - reservation.consumed_qty
                        - reservation.released_qty
                END), 0)
                FROM stock_reservations reservation
                JOIN (SELECT * FROM production_plan_items archive_origin WHERE NULLIF(to_jsonb(archive_origin)->>'legacy_id','') IS NULL AND NULLIF(to_jsonb(archive_origin)->>'legacy_import_run_id','') IS NULL AND NOT fn_imported_business_document_row('production_plan_items',to_jsonb(archive_origin))) plan_item
                  ON plan_item.id = reservation.supply_id
                 AND plan_item.is_deleted = FALSE
                JOIN (SELECT * FROM production_plans archive_origin WHERE NULLIF(to_jsonb(archive_origin)->>'legacy_id','') IS NULL AND NULLIF(to_jsonb(archive_origin)->>'legacy_import_run_id','') IS NULL AND NOT fn_imported_business_document_row('production_plans',to_jsonb(archive_origin))) plan
                  ON plan.id = plan_item.plan_id
                 AND plan.is_deleted = FALSE
                 AND plan.material_analysis_id = :analysisId
                 AND plan.material_analysis_item_id = :analysisItemId
                WHERE reservation.is_deleted = FALSE
                  AND (reservation.status = :effective
                       OR reservation.release_reason = 'TRANSFERRED_TO_PLAN')
                  AND reservation.owner_type = :ownerType
                  AND reservation.owner_id = :analysisId
                  AND reservation.supply_type = 'PRODUCTION_PLAN_ITEM'
                  AND NOT EXISTS (
                      SELECT 1
                      FROM preplan_analysis_stock_exact_pegs exact_peg
                      WHERE exact_peg.stock_reservation_id = reservation.id)
                """)
                .setParameter("effective", STATUS_EFFECTIVE)
                .setParameter("ownerType", OWNER_TYPE)
                .setParameter("analysisId", analysisId)
                .setParameter("analysisItemId", analysisItemId)
                .getSingleResult());
    }

    private PreplanStockEntitlementService.OriginAppendResult insertExactMakeReservation(
            UUID allocationId,
            UUID makeSourceAnalysisItemId,
            UUID analysisId,
            UUID analysisMaterialId,
            UUID warehouseId,
            UUID goodsId,
            UUID colorId,
            BigDecimal qtyBase,
            UUID planItemId,
            UUID stockDocumentId,
            UUID stockDocumentItemId) {
        return insertExactMakeReservation(allocationId, makeSourceAnalysisItemId, analysisId,
                analysisMaterialId, warehouseId, goodsId, colorId, qtyBase, planItemId,
                stockDocumentId, stockDocumentItemId, null);
    }

    private PreplanStockEntitlementService.OriginAppendResult insertExactMakeReservation(
            UUID allocationId, UUID makeSourceAnalysisItemId,
            UUID analysisId, UUID analysisMaterialId,
            UUID warehouseId, UUID goodsId, UUID colorId, BigDecimal qtyBase,
            UUID planItemId, UUID stockDocumentId, UUID stockDocumentItemId,
            UUID makePublicClaimId) {
        return insertExactMakeReservation(allocationId,makeSourceAnalysisItemId,analysisId,analysisMaterialId,warehouseId,goodsId,colorId,
                qtyBase,planItemId,stockDocumentId,stockDocumentItemId,makePublicClaimId,false);
    }

    private PreplanStockEntitlementService.OriginAppendResult insertExactMakeReservation(
            UUID allocationId,UUID makeSourceAnalysisItemId,UUID analysisId,UUID analysisMaterialId,UUID warehouseId,
            UUID goodsId,UUID colorId,BigDecimal qtyBase,UUID planItemId,UUID stockDocumentId,UUID stockDocumentItemId,
            UUID makePublicClaimId,boolean retainedOriginal) {
        // The FINISHED_IN header becomes APPROVED later in the same approve
        // transaction. Defer the exact-provenance constraint so V312 observes
        // the committed status without publishing an intermediate header state.
        em.createNativeQuery("""
                SET CONSTRAINTS
                    trg_check_preplan_analysis_stock_exact_peg DEFERRED
                """).executeUpdate();
        String key = makePublicClaimId != null
                ? "PREPLAN-MAKE-PUBLIC:" + stockDocumentItemId + ":" + makePublicClaimId
                : allocationId == null
                ? "PREPLAN-MAKE-ANCHOR:" + stockDocumentItemId + ":" + makeSourceAnalysisItemId
                : "PREPLAN-MAKE-EXACT:" + stockDocumentItemId + ":" + allocationId + (retainedOriginal?":"+analysisMaterialId:"");
        insertReservation(
                analysisId, warehouseId, goodsId, colorId, qtyBase,
                SUPPLY_PRODUCTION_PLAN_ITEM, planItemId,
                "PRODUCTION_INBOUND", stockDocumentId, key);
        UUID reservationId = NativeQueryResults.typedRows(em.createNativeQuery("""
                        SELECT id
                        FROM stock_reservations
                        WHERE idempotency_key = :key
                          AND is_deleted = FALSE
                        """).setParameter("key", key), UUID.class).stream()
                .findFirst()
                .orElseThrow(() -> new IllegalStateException(
                        "MAKE exact reservation was not persisted"));
        UUID actorId = currentUser.requireId();
        em.createNativeQuery("""
                INSERT INTO preplan_analysis_stock_exact_pegs (
                    id, stock_reservation_id,
                    supply_action_allocation_id, make_source_analysis_item_id, make_public_claim_id,
                    origin_analysis_id, origin_analysis_material_id,
                    beneficiary_analysis_id, beneficiary_analysis_material_id,
                    qty, source_receipt_type, source_receipt_id,
                    source_disposition_event_id,
                    source_stock_document_id, source_stock_document_item_id,
                    beneficiary_reason, idempotency_key,
                    created_by, updated_by
                ) VALUES (
                    :id, :reservationId, :allocationId, :makeSourceItemId, :makePublicClaimId,
                    :analysisId, :materialId,
                    :analysisId, :materialId,
                    :qty, 'MAKE', :stockDocumentId,
                    NULL, :stockDocumentId, :stockDocumentItemId,
                    'ORIGIN_MAKE', :key, :actorId, :actorId
                )
                ON CONFLICT (idempotency_key) DO NOTHING
                """)
                .setParameter("id", UUID.randomUUID())
                .setParameter("reservationId", reservationId)
                .setParameter("allocationId", allocationId)
                .setParameter("makeSourceItemId", makeSourceAnalysisItemId)
                .setParameter("makePublicClaimId", makePublicClaimId)
                .setParameter("analysisId", analysisId)
                .setParameter("materialId", analysisMaterialId)
                .setParameter("qty", qtyBase)
                .setParameter("stockDocumentId", stockDocumentId)
                .setParameter("stockDocumentItemId", stockDocumentItemId)
                .setParameter("key", key)
                .setParameter("actorId", actorId)
                .executeUpdate();
        UUID exactPegId = NativeQueryResults.typedRows(em.createNativeQuery("""
                        SELECT id
                        FROM preplan_analysis_stock_exact_pegs
                        WHERE idempotency_key = :key
                        """).setParameter("key", key), UUID.class).stream()
                .findFirst()
                .orElseThrow(() -> new IllegalStateException(
                        "MAKE exact peg was not persisted"));
        return entitlement.appendOriginMake(
                stockDocumentItemId, reservationId,
                analysisId, analysisMaterialId, qtyBase,
                exactPegId, stockDocumentId, stockDocumentItemId,
                "PREPLAN-ENTITLEMENT-MAKE:" + stockDocumentItemId
                        + ":" + (makePublicClaimId == null ? allocationId : makePublicClaimId)
                        + (retainedOriginal?":"+analysisMaterialId:""));
    }

    BigDecimal legacyAttributed(
            UUID analysisId, String supplyType, UUID externalItemId) {
        return decimal(em.createNativeQuery("""
                        SELECT COALESCE(SUM(CASE
                            WHEN reservation.release_reason = 'TRANSFERRED_TO_PLAN'
                            THEN reservation.qty
                            ELSE reservation.qty - reservation.consumed_qty
                                - reservation.released_qty
                        END), 0)
                        FROM stock_reservations reservation
                        WHERE reservation.is_deleted = FALSE
                          AND (reservation.status = :effective
                               OR reservation.release_reason = 'TRANSFERRED_TO_PLAN')
                          AND reservation.owner_type = :ownerType
                          AND reservation.owner_id = :analysisId
                          AND reservation.supply_type = :supplyType
                          AND reservation.supply_id = :externalItemId
                          AND NOT EXISTS (
                              SELECT 1
                              FROM preplan_analysis_stock_exact_pegs peg
                              WHERE peg.stock_reservation_id = reservation.id)
                        """)
                .setParameter("effective", STATUS_EFFECTIVE)
                .setParameter("ownerType", OWNER_TYPE)
                .setParameter("analysisId", analysisId)
                .setParameter("supplyType", supplyType)
                .setParameter("externalItemId", externalItemId)
                .getSingleResult());
    }

    private PreplanStockEntitlementService.OriginAppendResult insertExactReservation(
            UUID allocationId,
            UUID analysisId,
            UUID analysisMaterialId,
            UUID warehouseId,
            UUID goodsId,
            UUID colorId,
            BigDecimal qtyBase,
            String supplyType,
            UUID supplyId,
            String receiptType,
            UUID receiptId,
            UUID dispositionEventId,
            UUID warehouseStockInItemId) {
        return insertExactReservation(allocationId,analysisId,analysisMaterialId,warehouseId,goodsId,colorId,qtyBase,supplyType,
                supplyId,receiptType,receiptId,dispositionEventId,warehouseStockInItemId,false);
    }

    private PreplanStockEntitlementService.OriginAppendResult insertExactReservation(UUID allocationId,UUID analysisId,UUID analysisMaterialId,
            UUID warehouseId,UUID goodsId,UUID colorId,BigDecimal qtyBase,String supplyType,UUID supplyId,String receiptType,UUID receiptId,
            UUID dispositionEventId,UUID warehouseStockInItemId,boolean retainedOriginal) {
        String key = "PREPLAN-EXACT-PEG:" + warehouseStockInItemId + ":" + allocationId + (retainedOriginal?":"+analysisMaterialId:"");
        insertReservation(
                analysisId, warehouseId, goodsId, colorId, qtyBase,
                supplyType, supplyId, receiptType + "_RECEIPT", receiptId, key);
        UUID reservationId = NativeQueryResults.typedRows(em.createNativeQuery("""
                        SELECT id
                        FROM stock_reservations
                        WHERE idempotency_key = :key
                          AND is_deleted = FALSE
                        """).setParameter("key", key), UUID.class).stream()
                .findFirst()
                .orElseThrow(() -> new IllegalStateException(
                        "exact peg reservation was not persisted"));
        UUID actorId = currentUser.requireId();
        em.createNativeQuery("""
                        INSERT INTO preplan_analysis_stock_exact_pegs (
                            id, stock_reservation_id,
                            supply_action_allocation_id,
                            origin_analysis_id, origin_analysis_material_id,
                            beneficiary_analysis_id, beneficiary_analysis_material_id,
                            qty, source_receipt_type, source_receipt_id,
                            source_disposition_event_id, beneficiary_reason,
                            idempotency_key, created_by, updated_by
                        ) VALUES (
                            :id, :reservationId,
                            :allocationId,
                            :analysisId, :analysisMaterialId,
                            :analysisId, :analysisMaterialId,
                            :qty, :receiptType, :receiptId,
                            :eventId, 'ORIGIN_RECEIPT',
                            :key, :actorId, :actorId
                        )
                        ON CONFLICT (idempotency_key) DO NOTHING
                        """)
                .setParameter("id", UUID.randomUUID())
                .setParameter("reservationId", reservationId)
                .setParameter("allocationId", allocationId)
                .setParameter("analysisId", analysisId)
                .setParameter("analysisMaterialId", analysisMaterialId)
                .setParameter("qty", qtyBase)
                .setParameter("receiptType", receiptType)
                .setParameter("receiptId", receiptId)
                .setParameter("eventId", dispositionEventId)
                .setParameter("key", key)
                .setParameter("actorId", actorId)
                .executeUpdate();
        UUID exactPegId = NativeQueryResults.typedRows(em.createNativeQuery("""
                        SELECT id
                        FROM preplan_analysis_stock_exact_pegs
                        WHERE idempotency_key = :key
                        """).setParameter("key", key), UUID.class).stream()
                .findFirst()
                .orElseThrow(() -> new IllegalStateException(
                        "exact peg was not persisted"));
        return entitlement.appendOriginIqc(
                warehouseStockInItemId, reservationId,
                analysisId, analysisMaterialId, qtyBase,
                exactPegId, receiptType, receiptId, dispositionEventId,
                "PREPLAN-ENTITLEMENT-IQC:" + warehouseStockInItemId
                        + ":" + allocationId + (retainedOriginal?":"+analysisMaterialId:""));
    }

    private record RetainedReceiptSource(UUID original,BigDecimal remaining,BigDecimal capacity,BigDecimal received,boolean sourceValid) {
        RetainedReceiptSource(UUID original,BigDecimal remaining){this(original,remaining,remaining,BigDecimal.ZERO,true);}
    }

    /** One read for the whole receipt, reused across its allocations and lines. */
    private Map<UUID,List<RetainedReceiptSource>> retainedReceiptSources(UUID analysisId) {
        Map<UUID,List<RetainedReceiptSource>> result=new LinkedHashMap<>();
        for(Object[] row:NativeQueryResults.objectArrayRows(em.createNativeQuery("""
                SELECT retained.allocation_id,retained.original_material_id,retained.current_qty,
                    retained.received_qty,GREATEST(retained.current_qty-retained.received_qty,0),retained.source_valid
                FROM fn_preplan_aggregate_retained_private_sources(:analysis) retained
                JOIN production_material_analysis_materials original ON original.id=retained.original_material_id
                JOIN production_material_analysis_items owner ON owner.id=original.analysis_item_id
                ORDER BY original.id
                """).setParameter("analysis",analysisId)))
            result.computeIfAbsent((UUID)row[0],ignored->new ArrayList<>()).add(new RetainedReceiptSource((UUID)row[1],decimal(row[4]),decimal(row[2]),decimal(row[3]),Boolean.TRUE.equals(row[5])));
        return result;
    }

    /** Cumulative weighted boundaries conserve even one ten-thousandth. */
    private static List<RetainedReceiptSource> retainedReceiptSlices(List<RetainedReceiptSource> sources,BigDecimal requested) {
        BigDecimal total=sources.stream().map(RetainedReceiptSource::remaining).reduce(BigDecimal.ZERO,BigDecimal::add);
        if(total.signum()==0)return List.of();
        BigDecimal take=requested.min(total).setScale(4,java.math.RoundingMode.DOWN);
        BigDecimal capacity=sources.stream().map(RetainedReceiptSource::capacity).reduce(BigDecimal.ZERO,BigDecimal::add);
        BigDecimal received=sources.stream().map(RetainedReceiptSource::received).reduce(BigDecimal.ZERO,BigDecimal::add);
        BigDecimal cumulative=received.add(take).min(capacity),prefix=BigDecimal.ZERO,previous=BigDecimal.ZERO;
        List<BigDecimal> deficits=new ArrayList<>();
        for(var source:sources) {
            prefix=prefix.add(source.capacity());
            BigDecimal boundary=cumulative.multiply(prefix).divide(capacity,4,java.math.RoundingMode.DOWN);
            deficits.add(boundary.subtract(previous).subtract(source.received()).max(BigDecimal.ZERO).min(source.remaining()));
            previous=boundary;
        }
        BigDecimal deficitTotal=deficits.stream().reduce(BigDecimal.ZERO,BigDecimal::add);
        // Current source caps may have changed after older receipts. Preserve
        // every historical share and use only each owner's remaining right.
        if(deficitTotal.compareTo(take)<0) {deficits=sources.stream().map(RetainedReceiptSource::remaining).toList();deficitTotal=total;}
        prefix=BigDecimal.ZERO;previous=BigDecimal.ZERO;
        List<RetainedReceiptSource> slices=new ArrayList<>();
        for(int index=0;index<sources.size();index++) {
            var source=sources.get(index);prefix=prefix.add(deficits.get(index));
            BigDecimal boundary=take.multiply(prefix).divide(deficitTotal,4,java.math.RoundingMode.DOWN);
            BigDecimal qty=boundary.subtract(previous);previous=boundary;
            if(qty.signum()>0)slices.add(new RetainedReceiptSource(source.original(),qty));
            sources.set(index,new RetainedReceiptSource(source.original(),source.remaining().subtract(qty),source.capacity(),source.received().add(qty),source.sourceValid()));
        }
        return slices;
    }

    private void requireNoUnprovenCancelledMaterial(UUID material) {
        if(Boolean.TRUE.equals(em.createNativeQuery("""
                SELECT EXISTS(SELECT 1 FROM production_material_analysis_materials material
                  JOIN preplan_aggregate_batches parent ON parent.anchor_analysis_item_id=material.analysis_item_id
                  JOIN preplan_supply_actions action ON action.id=parent.action_id AND action.status='CANCELLED'
                  WHERE material.id=:material)
                """).setParameter("material",material).getSingleResult()))
            throw new ApiException(ErrorCode.CONFLICT,"原共享父批次已撤回，子供给缺少可验证的原始私有来源；请先核对责任后收货");
    }

    private static void requireRetainedSourcesWritable(List<RetainedReceiptSource> sources) {
        if(sources.stream().anyMatch(source->!source.sourceValid()))
            throw new ApiException(ErrorCode.CONFLICT,"独立子供给的原始来源、BOM或旧路径实收需先核对；本次收货未改变库存及私有归属");
    }

    /** Same prelocked document/analysis/inventory footprint as the existing
     * receipt wakeup. Refresh before reading any new private/public quota;
     * current physical output never determines its own node requirement. */
    private void refreshRetainedReceiptSnapshots(List<UUID> analyses) {
        for(UUID id:analyses.stream().distinct().sorted().toList()) {
            boolean retained=Boolean.TRUE.equals(em.createNativeQuery("""
                    SELECT EXISTS(SELECT 1 FROM preplan_aggregate_batches parent
                      JOIN preplan_supply_actions action ON action.id=parent.action_id AND action.analysis_id=:analysis AND action.status='CANCELLED'
                      WHERE parent.analysis_id=:analysis)
                    """).setParameter("analysis",id).getSingleResult());
            if(retained)admissionSnapshots.getObject().refreshLocked(id);
        }
    }

    private void insertReservation(
            UUID analysisId,
            UUID warehouseId,
            UUID goodsId,
            UUID colorId,
            BigDecimal qtyBase,
            String supplyType,
            UUID supplyId,
            String sourceDocType,
            UUID sourceDocId,
            String idempotencyKey) {
        UUID actorId = currentUser.requireId();
        em.createNativeQuery("""
                        INSERT INTO stock_reservations (
                            id, order_item_id, goods_id, color_id, warehouse_id,
                            qty, consumed_qty, released_qty, status, source,
                            source_doc_type, source_doc_id,
                            owner_type, owner_id, purpose, demand_id,
                            supply_type, supply_id, idempotency_key,
                            created_at, updated_at, created_by, updated_by,
                            is_deleted, lock_version
                        ) VALUES (
                            :id, NULL, :goodsId, :colorId, :warehouseId,
                            :qty, 0, 0, :status, :source,
                            :sourceDocType, :sourceDocId,
                            :ownerType, :ownerId, :purpose, NULL,
                            :supplyType, :supplyId, :key,
                            now(), now(), :actorId, :actorId,
                            FALSE, 0
                        )
                        ON CONFLICT (idempotency_key)
                        WHERE idempotency_key IS NOT NULL
                        DO NOTHING
                        """)
                .setParameter("id", UUID.randomUUID())
                .setParameter("goodsId", goodsId)
                .setParameter("colorId", colorId)
                .setParameter("warehouseId", warehouseId)
                .setParameter("qty", qtyBase)
                .setParameter("status", STATUS_EFFECTIVE)
                .setParameter("source", SOURCE_PREPLAN_ANALYSIS)
                .setParameter("sourceDocType", sourceDocType)
                .setParameter("sourceDocId", sourceDocId)
                .setParameter("ownerType", OWNER_TYPE)
                .setParameter("ownerId", analysisId)
                .setParameter("purpose", PURPOSE)
                .setParameter("supplyType", supplyType)
                .setParameter("supplyId", supplyId)
                .setParameter("key", idempotencyKey)
                .setParameter("actorId", actorId)
                .executeUpdate();
    }

    private void requireAnalysisCancellationSafe(UUID analysisId) {
        List<UUID> relations = NativeQueryResults.typedRows(
                em.createNativeQuery("""
                        SELECT reallocation.id
                        FROM preplan_material_reallocations reallocation
                        WHERE reallocation.status IN ('OPEN', 'PARTIAL')
                          AND (reallocation.from_analysis_id = :analysisId
                               OR reallocation.to_analysis_id = :analysisId)
                        ORDER BY reallocation.id
                        FOR UPDATE OF reallocation
                        """).setParameter("analysisId", analysisId), UUID.class);
        if (!relations.isEmpty()) {
            throw new ApiException(ErrorCode.CONFLICT,
                    "该分析仍有未补齐的跨分析让料；请先撤销未使用让料，"
                            + "或等待优先补齐完成后再取消");
        }
        List<UUID> subcontractCustody = NativeQueryResults.typedRows(em.createNativeQuery("""
                SELECT handoff.id
                FROM subcontract_component_stock_handoffs handoff
                JOIN preplan_stock_entitlement_events source_event
                  ON source_event.id = handoff.source_entitlement_event_id
                JOIN stock_reservations target ON target.id = handoff.target_reservation_id
                WHERE source_event.beneficiary_analysis_id = :analysisId
                  AND target.qty > target.released_qty
                ORDER BY handoff.id
                FOR UPDATE OF target
                """).setParameter("analysisId", analysisId), UUID.class);
        if (!subcontractCustody.isEmpty()) {
            throw new ApiException(ErrorCode.CONFLICT,
                    "该产品的物料已交给委外领料；请先在委外任务中心撤回仓库还没发出的领料，已发出的先完成发料红冲，恢复原归属后再取消分析");
        }
    }

    private static String activeComponentHandoff(String reservationId) {
        return """
                EXISTS (SELECT 1 FROM subcontract_component_stock_handoffs component_handoff
                        JOIN stock_reservations component_target
                          ON component_target.id = component_handoff.target_reservation_id
                        WHERE component_handoff.source_reservation_id = %s
                          AND component_target.qty > component_target.released_qty)
                """.formatted(reservationId);
    }

    private void requireReservationsReallocationSafe(Collection<UUID> ids,String label){requireReservationsReallocationSafe(ids,label,true);}
    private void requireReservationsReallocationSafe(
            Collection<UUID> reservationIds, String operationLabel,boolean lock) {
        List<UUID> ids = reservationIds == null
                ? List.of()
                : reservationIds.stream()
                        .filter(Objects::nonNull).distinct().sorted().toList();
        if (ids.isEmpty()) return;
        List<UUID> relations = NativeQueryResults.typedRows(
                em.createNativeQuery("""
                        SELECT reallocation.id
                        FROM preplan_material_reallocations reallocation
                        JOIN preplan_stock_entitlement_events event
                          ON event.reallocation_id = reallocation.id
                        WHERE event.stock_reservation_id IN (:reservationIds)
                          AND reallocation.status IN (
                              'OPEN', 'PARTIAL', 'FULFILLED')
                        ORDER BY reallocation.id
                        %s
                        """.formatted(lock?"FOR UPDATE OF reallocation":"")).setParameter("reservationIds", ids), UUID.class);
        if (!relations.isEmpty()) {
            throw new ApiException(ErrorCode.CONFLICT,
                    operationLabel + "关联库存仍参与跨分析让料/优先补齐；"
                            + "请先显式撤销未使用让料或取消未领料正式计划");
        }
        List<UUID> foreignBeneficiaries = NativeQueryResults.typedRows(
                em.createNativeQuery("""
                        SELECT reservation.id
                        FROM stock_reservations reservation
                        JOIN preplan_analysis_stock_exact_pegs exact_peg
                          ON exact_peg.stock_reservation_id = reservation.id
                        JOIN v_preplan_stock_entitlement_beneficiary_balance balance
                          ON balance.stock_reservation_id = reservation.id
                        WHERE reservation.id IN (:reservationIds)
                          AND (balance.beneficiary_analysis_id
                                  <> exact_peg.origin_analysis_id
                               OR balance.beneficiary_analysis_material_id
                                  <> exact_peg.origin_analysis_material_id)
                        ORDER BY reservation.id
                        %s
                        """.formatted(lock?"FOR UPDATE OF reservation":"")).setParameter("reservationIds", ids), UUID.class);
        if (!foreignBeneficiaries.isEmpty()) {
            throw new ApiException(ErrorCode.CONFLICT,
                    operationLabel + "会影响其他分析当前受益权益；"
                            + "请先显式撤销让料或取消未领料正式计划");
        }
    }

    /** 对称释放：先锁定完整作用域；任何部分/全部正式转移都使整次释放失败关闭。 */
    private void releaseRows(
            String whereClause,
            Map<String, Object> params,
            String releaseReason) {
        jakarta.persistence.Query query = em.createNativeQuery("""
                SELECT r.id, r.qty, r.consumed_qty, r.released_qty,
                       r.goods_id, r.color_id, r.status,
                       CASE WHEN %s THEN 'TRANSFERRED_TO_SUBCONTRACT' ELSE r.release_reason END
                FROM stock_reservations r
                WHERE r.is_deleted = FALSE
                  AND (r.status = :effective
                       OR r.release_reason = 'TRANSFERRED_TO_PLAN'
                       OR %s)
                  AND r.owner_type = :ownerType
                  AND %s
                ORDER BY r.created_at, r.id
                FOR UPDATE OF r
                """.formatted(activeComponentHandoff("r.id"), activeComponentHandoff("r.id"), whereClause))
                .setParameter("effective", STATUS_EFFECTIVE)
                .setParameter("ownerType", OWNER_TYPE);
        params.forEach(query::setParameter);
        List<Object[]> rows = NativeQueryResults.objectArrayRows(query);
        requireReservationsReallocationSafe(
                rows.stream().map(row -> (UUID) row[0]).toList(),
                "库存归属释放");

        if (rows.stream().anyMatch(row ->
                "TRANSFERRED_TO_PLAN".equals(row[7]) || "TRANSFERRED_TO_SUBCONTRACT".equals(row[7]))) {
            throw new ApiException(ErrorCode.CONFLICT,
                    "该分析归属库存仍有未恢复正式转移(生产或委外)；请先撤回未领料计划或未出仓草稿完成RESTORE，"
                            + "已领料或出仓则禁止取消或释放归属");
        }
        applyRelease(rows, releaseReason);
    }

    private void applyRelease(List<Object[]> rows, String releaseReason) {
        UUID actorId = currentUser.requireId();
        for (Object[] row : rows) {
            UUID reservationId = (UUID) row[0];
            BigDecimal qty = decimal(row[1]);
            BigDecimal consumed = decimal(row[2]);
            BigDecimal released = decimal(row[3]);
            BigDecimal effective = qty.subtract(consumed).subtract(released);
            if (effective.signum() <= 0) {
                continue;
            }
            inventoryLock.lock(new InventoryKey((UUID) row[4], (UUID) row[5]));
            entitlement.appendReleaseForReservation(
                    reservationId, reservationId,
                    "PREPLAN-RELEASE:" + reservationId);
            em.createNativeQuery("""
                            UPDATE stock_reservations
                            SET released_qty = qty,
                                status = :done,
                                release_reason = :reason,
                                lock_version = lock_version + 1,
                                updated_at = now(),
                                updated_by = :actorId
                            WHERE id = :id
                            """)
                    .setParameter("done", STATUS_DONE)
                    .setParameter("reason", releaseReason)
                    .setParameter("actorId", actorId)
                    .setParameter("id", reservationId)
                    .executeUpdate();
        }
    }

    private void applyBeneficiaryReleaseSlices(
            List<PreplanStockEntitlementService.ReservationRelease> slices,
            String releaseReason) {
        UUID actorId = currentUser.requireId();
        for (PreplanStockEntitlementService.ReservationRelease slice : slices) {
            inventoryLock.lock(new InventoryKey(
                    slice.goodsId(), slice.colorId()));
            int updated = em.createNativeQuery("""
                            UPDATE stock_reservations
                            SET released_qty = released_qty + :releaseQty,
                                status = CASE
                                    WHEN qty - consumed_qty - released_qty =
                                         :releaseQty
                                        THEN :done
                                    ELSE :effective
                                END,
                                release_reason = CASE
                                    WHEN qty - consumed_qty - released_qty =
                                         :releaseQty
                                        THEN COALESCE(release_reason, :reason)
                                    ELSE release_reason
                                END,
                                lock_version = lock_version + 1,
                                updated_at = now(),
                                updated_by = :actorId
                            WHERE id = :id
                              AND is_deleted = FALSE
                              AND owner_type = :ownerType
                              AND qty - consumed_qty - released_qty >=
                                  :releaseQty
                            """)
                    .setParameter("releaseQty", slice.qty())
                    .setParameter("done", STATUS_DONE)
                    .setParameter("effective", STATUS_EFFECTIVE)
                    .setParameter("reason", releaseReason)
                    .setParameter("actorId", actorId)
                    .setParameter("id", slice.stockReservationId())
                    .setParameter("ownerType", OWNER_TYPE)
                    .executeUpdate();
            if (updated != 1) {
                throw new ApiException(ErrorCode.CONFLICT,
                        "分析取消时库存权益切片已发生变化，请刷新后重试");
            }
        }
    }

    private void closeFulfilledReallocations(
            UUID analysisId,
            String closeReason,
            String cancellationIdempotencyKey) {
        List<Object[]> rows = NativeQueryResults.objectArrayRows(
                em.createNativeQuery("""
                        SELECT reallocation.id, reallocation.lock_version
                        FROM preplan_material_reallocations reallocation
                        WHERE reallocation.status = 'FULFILLED'
                          AND (reallocation.from_analysis_id = :analysisId
                               OR reallocation.to_analysis_id = :analysisId)
                        ORDER BY reallocation.id
                        FOR UPDATE OF reallocation
                        """).setParameter("analysisId", analysisId));
        UUID actorId = currentUser.requireId();
        for (Object[] row : rows) {
            UUID reallocationId = (UUID) row[0];
            long lockVersion = ((Number) row[1]).longValue();
            String closeKey = "ANALYSIS-CANCEL:"
                    + PlanningPackageFingerprint.sha256(List.of(
                            analysisId.toString(), reallocationId.toString(),
                            cancellationIdempotencyKey));
            String closeHash = PlanningPackageFingerprint.sha256(List.of(
                    "CANCEL_FULFILLED_REALLOCATION",
                    analysisId.toString(), reallocationId.toString(),
                    cancellationIdempotencyKey, closeReason));
            int updated = em.createNativeQuery("""
                            UPDATE preplan_material_reallocations
                            SET status = 'CANCELLED',
                                closed_by = :actorId,
                                closed_at = now(),
                                close_reason = :reason,
                                close_idempotency_key = :closeKey,
                                close_request_hash = :closeHash,
                                lock_version = lock_version + 1,
                                updated_by = :actorId
                            WHERE id = :id
                              AND status = 'FULFILLED'
                              AND lock_version = :lockVersion
                            """)
                    .setParameter("actorId", actorId)
                    .setParameter("reason", closeReason)
                    .setParameter("closeKey", closeKey)
                    .setParameter("closeHash", closeHash)
                    .setParameter("id", reallocationId)
                    .setParameter("lockVersion", lockVersion)
                    .executeUpdate();
            if (updated != 1) {
                throw new ApiException(ErrorCode.CONFLICT,
                        "已补齐让料记录发生并发变化，请刷新后重试");
            }
        }
    }
    void applyOriginPriority(
            PreplanStockEntitlementService.OriginAppendResult origin) {
        applyOriginPriority(List.of(origin));
    }

    void applyOriginPriority(List<PreplanStockEntitlementService.OriginAppendResult> origins) {
        List<UUID> inserted = origins.stream().filter(PreplanStockEntitlementService.OriginAppendResult::inserted)
                .map(PreplanStockEntitlementService.OriginAppendResult::eventId).distinct().toList();
        if (inserted.isEmpty()) return;
        // A readiness hook may prepare all materials of a task. Finish the
        // higher-priority ownership hooks for every source before it runs.
        originHooks.orderedStream().forEach(hook -> inserted.forEach(hook::applyPriorityForOriginEvent));
    }

    private static String normalizeReason(String reason, String fallback) {
        return reason == null || reason.isBlank() ? fallback : reason.strip();
    }

    private static BigDecimal decimal(Object value) {
        return value == null ? BigDecimal.ZERO : (BigDecimal) value;
    }
}
