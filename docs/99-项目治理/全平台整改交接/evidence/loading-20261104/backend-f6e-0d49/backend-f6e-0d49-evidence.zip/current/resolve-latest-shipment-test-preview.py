import hashlib
import json
from pathlib import Path

root=Path(__file__).resolve().parents[4]
out=root/'build/loading-validation/upstream-2dd3e-backend-preview'
path='server/src/test/java/com/uten/imp/businesschain/SalesShipmentFinanceReleaseRateEndToEndTest.java'
def text(label):return (out/label/path).read_text(encoding='utf-8').replace('\r\n','\n')
base,main,task=text('base'),text('main'),text('task')
assert base.replace('RELEASED|7.200000|','RELEASED|7.2|').replace('RELEASED|7.000000|','RELEASED|7|').replace('RELEASED|1.000000|','RELEASED|1|')==main
assert 'new BigDecimal(expected).compareTo(actual)' in task
assert 'rs.getBigDecimal(2)' in task
assert 'assertEquals(type,actual.type());assertEquals(source,actual.source());' in task
assert 'assertEquals(1,releaseEvents(draft.getId()).size())' in task
assert 'assertEquals(2,events.size())' in task
staged=out/'staged'/path;staged.parent.mkdir(parents=True,exist_ok=True)
staged.write_bytes((out/'task'/path).read_bytes())
proof={'mode':'Ignored resolved preview only. Actual B35319 source is untouched.',
       'path':path,'decision':'Preserve task typed ReleaseEvent/GetBigDecimal exact-value assertions; upstream only removes insignificant six-place padding from five textual expectations.',
       'numericSemantics':'BigDecimal.compareTo tests exact mathematical value, not an epsilon or rounding. Event count/type/source and null revoked rate remain asserted; wrong significant digits still fail.',
       'mainDeltaIsOnlyExpectedTextPadding':True,
       'baseSha256':hashlib.sha256((out/'base'/path).read_bytes()).hexdigest(),
       'mainSha256':hashlib.sha256((out/'main'/path).read_bytes()).hexdigest(),
       'taskAndResolvedSha256':hashlib.sha256(staged.read_bytes()).hexdigest()}
(out/'shipment-test-reviewed-resolution.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'resolved':path,'sourceChanged':False,'mainOnlyTextPadding':True}))
