import hashlib
import json
import subprocess
import zipfile
from datetime import datetime, timezone
from pathlib import Path

base=Path(__file__).resolve().parent
root=base.parents[3]
acceptance=json.loads((base/'backend-current-acceptance.json').read_text(encoding='utf-8'))
assert acceptance['allRequiredJavaGreen'] is True and acceptance['requiredJavaClasses']==47
assert acceptance['uniqueJavaTests']==289 and all(acceptance[name]==0 for name in ['javaFailed','javaErrors','javaSkipped'])
source=json.loads((base/'source-input.json').read_text(encoding='utf-8-sig'))
inventory=json.loads((base/'complete-input-inventory.json').read_text(encoding='utf-8'))
assert acceptance['sourceAggregateSha256']==source['aggregateSha256']
baseline='f6e0d8532e6e11239243b4fb2149fb90410395ba'
git=subprocess.run(['git','-C',str(root),'ls-tree','-r','-z',baseline],check=True,capture_output=True).stdout
baseline_files={}
for item in git.split(b'\0'):
    if not item:continue
    metadata,path=item.split(b'\t',1)
    mode,kind,digest=metadata.decode('ascii').split()
    if kind=='blob':baseline_files[path.decode('utf-8')]=digest
declared={entry['path']:entry['sha256'] for entry in source['files']+inventory['supplementalFiles']}
assert len(declared)==7354 and set(declared)==set(inventory['inventoryPaths'])
source_delta=[]
for relative,expected in sorted(declared.items()):
    raw=(root/relative).read_bytes()
    assert hashlib.sha256(raw).hexdigest()==expected,relative
    git_blob=hashlib.sha1(b'blob '+str(len(raw)).encode('ascii')+b'\0'+raw).hexdigest()
    if baseline_files.get(relative)!=git_blob:
        source_delta.append({'path':relative,'sha256':expected,'gitBlobSha1':git_blob,'baselineBlobSha1':baseline_files.get(relative)})

destination=root/'docs/99-项目治理/全平台整改交接/evidence/loading-20261104/backend-f6e-0d49'
destination.mkdir(exist_ok=False)
archive=destination/'backend-f6e-0d49-evidence.zip'
members={}
def add(path,name):
    raw=path.read_bytes()
    assert name not in members,name
    members[name]={'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw)}
    stream.writestr(name,raw)
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as stream:
    for path in sorted(base.rglob('*')):
        if not path.is_file() or '__pycache__' in path.parts or 'coordinator-classes' in path.parts:continue
        add(path,'current/'+path.relative_to(base).as_posix())
    historical=root/'server/build/loading-validation/main-f6e-scoped'
    for name in ['draft-scoped-pg-receipt','legacy-private-missing-weight-function-receipt']:
        for path in sorted((historical/name).rglob('*')):
            if path.is_file():add(path,'historical-a5ed/'+name+'/'+path.relative_to(historical/name).as_posix())
    for entry in source_delta:
        add(root/entry['path'],'source-delta-from-f6e/'+entry['path'])
    delta_manifest=json.dumps({'baselineMain':baseline,'sourceAggregateSha256':source['aggregateSha256'],
        'completeInputInventoryAggregateSha256':inventory['completeInputInventoryAggregateSha256'],
        'policy':'Only declared7354 source inputs differing from the immutable f6e baseline are bundled. Unchanged inputs are reconstructed from that baseline; all input hashes and path inventory remain in current/source-input.json and current/complete-input-inventory.json.',
        'changedOrAddedSources':source_delta},ensure_ascii=False,indent=2).encode('utf-8')+b'\n'
    name='source-delta-from-f6e/manifest.json'
    members[name]={'sha256':hashlib.sha256(delta_manifest).hexdigest(),'bytes':len(delta_manifest)}
    stream.writestr(name,delta_manifest)
with zipfile.ZipFile(archive,'r') as verify:
    assert verify.testzip() is None
    assert len(verify.namelist())==len(set(verify.namelist()))==len(members)
    for name,expected in members.items():
        raw=verify.read(name)
        assert len(raw)==expected['bytes'] and hashlib.sha256(raw).hexdigest()==expected['sha256'],name
index={'sealedAtUtc':datetime.now(timezone.utc).isoformat(),'stage':'f6e-composed backend, superseded Main observed later; never label this latest496 validation',
       'sourceAggregateSha256':source['aggregateSha256'],'completeInputInventoryAggregateSha256':inventory['completeInputInventoryAggregateSha256'],
       'baselineMain':baseline,'latestObservedMainOutsideThisRuntime':'4963476ed13a3f7d3eb06da7f683cf66425b4ec4',
       'javaClasses':47,'uniqueJavaTests':289,'failed':0,'errors':0,'skipped':0,
       'legacyCaveat':acceptance['legacyCaveat'],'sourceDeltaFiles':len(source_delta),
       'archive':archive.name,'archiveSha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'archiveBytes':archive.stat().st_size,
       'archiveEntries':len(members),'crcChecked':True,'everyMemberSha256Checked':True,'members':members,
       'noCompanyDbWrites':True,'noMainWrites':True,'noPublication':True}
(destination/'index.json').write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
for name in ['backend-current-acceptance.json','source-input.json','complete-input-inventory.json','legacy-qualified-case-coverage.json','performance-scope-notes.json']:
    (destination/name).write_bytes((base/name).read_bytes())
print(json.dumps({'destination':str(destination),'classes':47,'uniqueJavaTests':289,'sourceDeltaFiles':len(source_delta),
                  'archiveSha256':index['archiveSha256'],'archiveBytes':index['archiveBytes'],'entries':len(members),'crcAndAllMemberShaChecked':True}))
