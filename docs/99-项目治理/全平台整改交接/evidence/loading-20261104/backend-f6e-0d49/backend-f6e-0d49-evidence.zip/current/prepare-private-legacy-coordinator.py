from pathlib import Path

base=Path(__file__).resolve().parent
original=(base.parent/'main-f6e-scoped/LegacySqlFixtureCoordinator.java').read_text(encoding='utf-8')
updated=original.replace('LegacySqlFixtureCoordinator','LegacySqlCurrentFixtureCoordinator')
updated=updated.replace('main-f6e-scoped/legacy-private-16','main-f6e-metadata/legacy-private-current')
updated=updated.replace('legacy_bootstrap_f6e_loading','legacy_bootstrap_f6e_metadata')
(base/'LegacySqlCurrentFixtureCoordinator.java').write_text(updated,encoding='utf-8',newline='\n')
print('Prepared ignored coordinator; original safety gate and SQL modules unchanged')
