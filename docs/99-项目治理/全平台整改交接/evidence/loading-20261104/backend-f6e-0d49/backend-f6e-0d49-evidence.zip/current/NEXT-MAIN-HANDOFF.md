# Latest Main composition checkpoint

Backend product source remains frozen at primary `0d49fabceb36b97e6c871ab47762231f59bf4533e1bbdb46deab690c75377bbb`, complete input inventory `37195a9255368b61933f8c657439f5206211e96334b236d5b025455041bc5bd3` (7000 primary +354 supplemental =7354 paths).

Current owned native exec is **35319**, `metadata-B`, test JVM55152. Do not cancel or change its source. A37842 naturally completed0,28classes/212passed, source/pathset0drift sealed by63395. B has18completed classes/71passed/0bad/skip; last `LegacyQuantityAdoptionCompatibilityPostgresTest` still runs. FinanceApplications8, real Draft10 including ordinary-owner/foreign/no-view/revoke/ABA/late-publication, and sales/MAKE/RESTORE workflows have passed. Observe native exit and seal B before source changes. B evidence is for the f6-composed source, never relabel it latest Main.

`seal-current-group.py metadata-B B`, then `seal-current-union.py` only after B naturally completes. Both assert actual native0, exact required classes/nonzero tests, no failures/errors/skips, canonical source hashes and full7354 pathset. Union requires47 unique classes and6 current growth fixtures. Preserve any failure first.

Current claims service sample is round-frozen under `current-source-claims-sample/`:34,198.3217ms global11batches/1001current drafts versus56.3409ms selected1batch/1relatedheader, same real claim. SHA `d805a86b40222656324fc8c66cba7178e7303d101683bdef3a02f85477a86a4b`. Provenance has actual passing class10 and a running-B snapshot. This is one service fixture sample, not HTTP/client/SLA. Old a5ed sample53,284.555→80.822ms remains separately sealed, never overwritten or combined.

Latest observed Main is **4963476ed13a3f7d3eb06da7f683cf66425b4ec4**. New committed Main1060..1065 conflict numerically with old candidate1060..1064. No new source has been applied. Root says Main has1004committed SQL (990integer versions+14subversions), max1065. Recheck latest head and every committed blob before final stage.

If no further versions appear, move the five uncommitted candidate bodies once in original semantic order:

- verified legacy adoption1060→1066;
- return proof1061→1067;
- direct MAKE capacity1062→1068;
- expense reversal event1063→1069;
- legitimate top-level execution view1064→1070.

Then total1009/max1070, return schema gate1067, mapping/bootstrap-v22 unchanged. Preserve all committed SQL bytes, including V990_1 and V999_1..13. Version identity uses integer segment tuples;999_10 differs from999_1 and must not be parsed as a floating/decimal number. Do not choose final numbers or mutate source while B is live.

Read-only triplets and staging are in `NEW/build/loading-validation/upstream-2dd3e-backend-preview/` (`review.json`, `staging-review.json`, base/main/task/staged/conflicts). Base=f6Main committed bytes; task=current0d49; Main=fixed2dd3ea. All69server paths are snapshotted with per-file SHA.63adopt, after newline normalization5clean auto and1manual shipment test. Later2dd→496 changes only3additional server tests, no prod/SQL. `latest-observed-six-path-equivalence.json` proves the six overlap paths have no2dd→496 committed delta.

Root independently reviewed all six and wrote `root-independent-semantic-peer.json`. Purchase/Subcontract staged specs preserve task's database pending-case predicate verbatim, while inverse row-proof replacements and restoring Main spec make the rest exactly Main. Sales inverse row-proof replacements make whole file exactly Main. ProcurementFinanceReviewReadonly staged equals Main after newline normalization. ClosedCredit preserves Main's helper arity/resource guard and task's exact/MAX/RESTORE tests. Shipment source remains typed JDBC BigDecimal with exact compareTo (no epsilon), event count/type/source/null assertions; Main only removed five insignificant textual paddings. `shipment-test-reviewed-resolution.json` proves that decision. All are ignored previews, not product writes or runtime claims.

Main1060 patches the UPDATE changed-anchor of `fn_guard_document_quantity_adoption`; candidate legacy patches its INSERT entry and receipt weight entry with separate checked anchors. Keep both, never replace the whole function from an old migration. Main1062/1065 reference-price policy functions/columns and source-revision authority, Main1063 precision/claim relevant-update triggers and Main1064 high-risk permission metadata must remain byte exact. Candidate capacity and expense functions/CHECK have separate targets. Actual new merged migration/affected guards still need validation.

After B closes: seal/archive this f6-stage accurately, compose once against then-current Main, rename five candidates/update gate/docs/fixtures using Main's `MigrationSqlResources` semantic resource helper where applicable, refresh the four explicit CAS resolution pins against final Main head and final candidate bytes. Current four pins target oldf6 and cannot authorize a later overwrite. No Main/product/SQL application has happened in this preview. Root/fresh integration own Dart/WPF/canonical docs/final Main CAS. Backend owner alone edits server/SQL; no company DB writes, push, deploy or physical hot exit.
