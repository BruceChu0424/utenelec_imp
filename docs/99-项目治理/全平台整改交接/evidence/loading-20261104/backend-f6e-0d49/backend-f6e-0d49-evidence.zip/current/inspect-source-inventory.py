import json
from collections import Counter
from pathlib import Path
base=Path(__file__).resolve().parent
root=base.parents[3]
manifest=json.loads((base/'source-input.json').read_text(encoding='utf-8-sig'))
expected={entry['path'] for entry in manifest['files']}
result={}
for anchor in ['server/src/main','server/src/test','server/legacy_migration']:
    actual={str(path.relative_to(root)).replace('\\','/') for path in (root/anchor).rglob('*')
            if path.is_file() and '__pycache__' not in path.parts and path.suffix!='.pyc'}
    selected={path for path in expected if path.startswith(anchor+'/')}
    result[anchor]={'manifest':len(selected),'actual':len(actual),'manifestOnly':sorted(selected-actual)[:25],
                    'actualOnly':sorted(actual-selected)[:30],
                    'manifestExtensions':dict(Counter(Path(path).suffix for path in selected)),
                    'extraExtensions':dict(Counter(Path(path).suffix for path in actual-selected))}
result['externalManifestPaths']=sorted(path for path in expected if not any(path.startswith(anchor+'/') for anchor in ['server/src/main','server/src/test','server/legacy_migration']))
(base/'source-inventory-discovery.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result,ensure_ascii=False))
