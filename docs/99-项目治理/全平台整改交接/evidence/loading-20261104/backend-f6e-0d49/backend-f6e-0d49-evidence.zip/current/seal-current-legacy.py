import hashlib
import json
import re
import sys
import unittest
from pathlib import Path

base=Path(__file__).resolve().parent
root=base.parents[3]
sys.path.insert(0,str(root/'server/legacy_migration'))
modules=['test_verify_rehearsal_counter_baseline','test_bootstrap_target_inventory','test_compose_bootstrap','test_verify_rehearsal_result']
def flatten(suite):
    for test in suite:
        if isinstance(test,unittest.TestSuite):
            yield from flatten(test)
        else:
            yield test.id()
ids=sorted(flatten(unittest.TestSuite(unittest.defaultTestLoader.loadTestsFromName(name) for name in modules)))
assert len(ids)==len(set(ids))==67
cli='test_compose_bootstrap.BootstrapComposerTest.test_cli_rejects_before_emitting_any_partial_module'
assert cli in ids
source=json.loads((base/'source-input.json').read_text(encoding='utf-8-sig'))['aggregateSha256']
names=['legacy-private-current','legacy-focused-67','legacy-cli-launcher']
executions={name:json.loads((base/(name+'-execution.json')).read_text(encoding='utf-8-sig')) for name in names}
assert all(record['sourceAggregateSha256']==source for record in executions.values())
assert [executions[name]['actualExitCode'] for name in names]==[0,1,0]
focus=(base/'legacy-focused-67.log').read_text(encoding='utf-8',errors='replace')
assert 'Ran 67 tests' in focus and 'FAILED (errors=1)' in focus and 'WinError 5' in focus
assert focus.count('\nERROR: ')==1 and 'ERROR: test_cli_rejects_before_emitting_any_partial_module' in focus
cli_log=(base/'legacy-cli-launcher.log').read_text(encoding='utf-8',errors='replace')
assert 'Ran 1 test' in cli_log and '\nOK' in cli_log and cli in cli_log
sql=(base/'legacy-private-current.log').read_text(encoding='utf-8',errors='replace')
sql_ids=re.findall(r'^test_\w+ \((test_[^)]+)\) \.\.\. ok\s*$',sql,re.M)
assert len(sql_ids)==len(set(sql_ids))==18 and 'Ran 18 tests' in sql and '\nOK' in sql
proof=json.loads((base/'legacy-private-current-receipt.json').read_text(encoding='utf-8-sig'))
assert proof['pythonActualExitCode']==0 and proof['containerNaturallyClosed'] is True
ledger=[{'id':name,'status':'passed','qualifiedRun':'legacy-cli-launcher' if name==cli else 'legacy-focused-67',
         'qualification':'Exact original CLI case rerun with established executable launcher; original failure preserved' if name==cli else 'Actually passed in the 67-case native exit1 run; no failed case is counted here'} for name in ids]
ledger += [{'id':name,'status':'passed','qualifiedRun':'legacy-private-current','qualification':'Whole real private PostgreSQL module run, original safety gate and validation asserts'} for name in sorted(sql_ids)]
assert len({entry['id'] for entry in ledger})==85
artifacts=[]
for name in names:
    for suffix in ['.log','-execution.json']:
        path=base/(name+suffix)
        artifacts.append({'path':str(path.relative_to(root)).replace('\\','/'),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
receipt={'primarySourceAggregateSha256':source,'nativeRunsAllGreen':False,
         'originalFocusedWholeRun':{'actualExitCode':1,'tests':67,'passed':66,'errors':1,'failed':0,'skipped':0},
         'correctedOriginalCliCase':{'actualExitCode':0,'tests':1,'passed':1,'skipped':0},
         'privatePostgresWholeRun':{'actualExitCode':0,'tests':18,'passed':18,'failed':0,'errors':0,'skipped':0},
         'qualification':'The directly launched embedded interpreter did not restore sys.executable to its runnable launcher, so CreateProcess failed before the one CLI case could evaluate its original assertions. Only that exact case was rerun using the established launcher; no production/test source or safety assertion changed. The 67-case native run remains RED and is never relabelled exit0.',
         'selectedUniqueCaseCoverage':85,'caseLedger':ledger,'artifacts':artifacts,
         'full684DiscoveryGreen':False,'companyDatabaseWritten':False}
(base/'legacy-qualified-case-coverage.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'uniqueSelectedCaseCoverage':85,'privatePgWhole18':True,'focusedWhole67NativeExit':1,'exactOriginalCliRerun':1,'nativeRunsAllGreen':False}))
