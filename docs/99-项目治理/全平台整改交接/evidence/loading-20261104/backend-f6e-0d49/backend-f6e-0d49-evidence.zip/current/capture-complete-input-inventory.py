import concurrent.futures
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path
from backend_inventory import ANCHORS,FIXED,source_paths,external_resources

base=Path(__file__).resolve().parent
root=base.parents[3]
manifest=json.loads((base/'source-input.json').read_text(encoding='utf-8-sig'))
primary={entry['path']:entry['sha256'] for entry in manifest['files']}
paths=source_paths(root)
assert set(primary)<=paths
def capture(path):
    return {'path':path,'sha256':hashlib.sha256((root/path).read_bytes()).hexdigest()}
with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
    supplemental=list(pool.map(capture,sorted(paths-set(primary))))
compiled=[]
for path,target in external_resources(root):
    digest=hashlib.sha256((root/path).read_bytes()).hexdigest()
    assert hashlib.sha256((root/target).read_bytes()).hexdigest()==digest,(path,target)
    compiled.append({'sourcePath':path,'compiledPath':target,'sha256':digest})
all_hashes={**primary,**{entry['path']:entry['sha256'] for entry in supplemental}}
complete=hashlib.sha256(''.join(path+'\0'+all_hashes[path]+'\n' for path in sorted(all_hashes)).encode('utf-8')).hexdigest()
inventory={'capturedAtUtc':datetime.now(timezone.utc).isoformat(),'primaryDeclaredSourceAggregateSha256':manifest['aggregateSha256'],
           'primaryFiles':len(primary),'completeInputInventoryAggregateSha256':complete,
           'aggregateAlgorithm':'SHA256 sorted UTF8 path+NUL+sha+LF','inventoryPaths':sorted(paths),
           'policy':{'anchors':ANCHORS,'fixedFiles':FIXED,'excluded':'__pycache__ and .pyc only; POM external resources selected by original include/exclude patterns'},
           'supplementalFiles':supplemental,'compiledExternalResources':compiled,
           'provenance':'Supplementary path-set/source capture before formal A/B. No product source changed after the original 7000-file 0d49 compilation; every external packaged resource equals the frozen compiled byte. Primary manifests/earlier receipts remain untouched.',
           'compileExecutionSha256':hashlib.sha256((base/'compile-execution.json').read_bytes()).hexdigest()}
(base/'complete-input-inventory.json').write_text(json.dumps(inventory,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'primarySource':manifest['aggregateSha256'],'completeInputInventory':complete,'primaryFiles':len(primary),'supplementalFiles':len(supplemental),'totalPaths':len(paths),'compiledExternalResources':len(compiled)}))
