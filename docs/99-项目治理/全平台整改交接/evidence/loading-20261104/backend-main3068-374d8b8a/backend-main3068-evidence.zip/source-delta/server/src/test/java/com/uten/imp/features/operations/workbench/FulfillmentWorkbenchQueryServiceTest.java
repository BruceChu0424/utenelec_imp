package com.uten.imp.features.operations.workbench;

import jakarta.persistence.EntityManager;
import jakarta.persistence.Query;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.springframework.security.access.prepost.PreAuthorize;

import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.sql.Date;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

class FulfillmentWorkbenchQueryServiceTest {

    @Test void subcontractExportUsesTheSameTerminalStatusAndBoundTableFiltersAsItsHistoryList() {
        EntityManager em=mock(EntityManager.class);Query rows=mock(Query.class);
        when(em.createNativeQuery(anyString())).thenReturn(rows);
        Object[] value=taskRow("SUBCONTRACT","SUBCONTRACT_ORDER",UUID.randomUUID(),UUID.randomUUID());
        when(rows.getResultList()).thenReturn(Collections.singletonList(value));
        var access=fullTaskAccess();
        when(access.documentAccess("SUBCONTRACT","SUBCONTRACT_ORDER"))
                .thenReturn(new FulfillmentWorkbenchAccessPolicy.DocumentAccess(true,false));
        var table=FulfillmentWorkbenchTableQuery.from("docNo","desc",java.util.Map.of(
                "f.planNo","PP-001","search.goods","轴套"),null,null,null,null);
        var payload=new FulfillmentWorkbenchQueryService(em,access).exportSubcontract("COMPLETED","轴套","",
                LocalDate.of(2026,8,1),LocalDate.of(2026,8,31),table,500);
        assertEquals(1,payload.total());
        assertEquals(value[1],payload.rows().getFirst().get("taskId"));
        assertEquals("轴套",payload.rows().getFirst().get("goods"));
        assertEquals(BigDecimal.TEN,payload.rows().getFirst().get("requiredQty"));
        assertEquals("件",payload.rows().getFirst().get("unitName"));
        assertEquals("DOC-001",payload.rows().getFirst().get("docNo"));
        verify(rows).setParameter("status","COMPLETED");
        verify(rows).setParameter("department","SUBCONTRACT");
        verify(rows).setParameter("date_from",LocalDate.of(2026,8,1));
        ArgumentCaptor<String> sql=ArgumentCaptor.forClass(String.class);verify(em).createNativeQuery(sql.capture());
        assertTrue(sql.getValue().contains("task_status = :status"));
        assertTrue(sql.getValue().contains(table.filterSql(null)));
        assertTrue(sql.getValue().contains(table.orderSql()));
    }

    @Test void subcontractExportRejectsTheDifferentPendingDrawProjectionBeforeReadingAnyFacts() {
        EntityManager em=mock(EntityManager.class);
        var service=new FulfillmentWorkbenchQueryService(em,fullTaskAccess());
        for(String stage:List.of("","WAITING_ORDER","DRAW_OPEN"))
            org.junit.jupiter.api.Assertions.assertThrows(com.uten.imp.common.web.ApiException.class,
                    ()->service.exportSubcontract(stage,"","",null,null,null,500));
        org.mockito.Mockito.verifyNoInteractions(em);
    }

    @Test void requestAndApplicationRowsExposeTheirApprovedPhysicalStageDifference() throws Exception {
        var service=new FulfillmentWorkbenchQueryService(mock(EntityManager.class),fullTaskAccess());
        var enrich=FulfillmentWorkbenchQueryService.class.getDeclaredMethod("enrichTableRows",String.class,String.class);
        enrich.setAccessible(true);
        for(String department:List.of("PURCHASE","SUBCONTRACT")) {
            String sql=(String)enrich.invoke(service,"fixture_rows",department);
            String type=department.equals("PURCHASE")?"PURCHASE_REQUEST":"SUBCONTRACT_APPLICATION";
            assertTrue(sql.contains("WHEN base.action_doc_type='"+type+"' THEN ((base.fulfilled_qty)-(base.required_qty))"));
            assertTrue(sql.contains("difference_item.received_qty"));
            assertFalse(sql.contains("base.allocated_qty)-(base.required_qty)"));
        }
    }

    @Test void displayOnlyDetailsMoveAfterThePageUnlessTheyControlGlobalSelection() {
        for(String keyword:List.of("","轴套")) {
            EntityManager em=mock(EntityManager.class);Query rows=mock(Query.class);
            when(em.createNativeQuery(anyString())).thenReturn(rows);
            when(rows.getResultList()).thenReturn(pageResult(List.of(),new Object[]{0L,0L,0L,BigDecimal.ZERO},List.of(),List.of(),0L,List.of()));
            var access=fullTaskAccess();when(access.canAccessWarehouseTasks()).thenReturn(true);
            new FulfillmentWorkbenchQueryService(em,access).query("WAREHOUSE","READY_TO_PICK",keyword,"",null,null,1,20);
            ArgumentCaptor<String> sql=ArgumentCaptor.forClass(String.class);verify(em).createNativeQuery(sql.capture());
            if(keyword.isEmpty()) {
                assertTrue(sql.getValue().indexOf("production_product ON TRUE")>sql.getValue().indexOf("LEFT JOIN page_rows ON TRUE"));
                assertFalse(sql.getValue().contains("base.action_doc_type='DRAW' AND mapping.document_type='DRAW'"));
            } else assertTrue(sql.getValue().contains("base.action_doc_type='DRAW' AND mapping.document_type='DRAW'"));
        }
        assertTrue(new FulfillmentWorkbenchTableQuery("differenceQty","asc",java.util.Map.of(),null,null,null,null).requiresDifference());
        assertTrue(new FulfillmentWorkbenchTableQuery(null,null,java.util.Map.of("search.differenceQty",">0"),null,null,null,null).requiresDifference());
        assertFalse(new FulfillmentWorkbenchTableQuery(null,null,java.util.Map.of(),null,null,null,null).requiresDifference());
    }

    @Test void continuationResponseExplicitlyOmitsMetadataWhileKeepingExactTotalAndCapabilities() throws Exception {
        EntityManager em=mock(EntityManager.class);Query rows=mock(Query.class);
        when(em.createNativeQuery(anyString())).thenReturn(rows);
        Object[] raw=java.util.Arrays.copyOf(taskRow("PURCHASE","PURCHASE_ORDER",UUID.randomUUID(),UUID.randomUUID()),51);raw[50]=7L;
        when(rows.getResultList()).thenReturn(java.util.Collections.singletonList(raw));
        var access=fullTaskAccess();
        when(access.documentAccess("PURCHASE","PURCHASE_ORDER"))
                .thenReturn(new FulfillmentWorkbenchAccessPolicy.DocumentAccess(true,true));
        var page=new FulfillmentWorkbenchQueryService(em,access).query("PURCHASE","IN_PROGRESS","","",null,null,2,2,null,
                com.uten.imp.application.port.WarehouseTaskScopePort.WarehouseTaskScope.ALL,false);
        assertFalse(page.metadataIncluded());assertEquals(7,page.total());assertEquals(4,page.totalPages());
        assertEquals(1,page.items().size());org.junit.jupiter.api.Assertions.assertNull(page.summary());
        org.junit.jupiter.api.Assertions.assertNull(page.facets());org.junit.jupiter.api.Assertions.assertNull(page.nullCounts());
        assertTrue(page.capabilities().canCreatePurchaseOrder());
        var json=new com.fasterxml.jackson.databind.ObjectMapper().findAndRegisterModules().valueToTree(page);
        assertFalse(json.path("metadataIncluded").asBoolean());assertTrue(json.path("summary").isNull());
        ArgumentCaptor<String> sql=ArgumentCaptor.forClass(String.class);verify(em).createNativeQuery(sql.capture());
        assertFalse(sql.getValue().contains("status_rows AS"));assertFalse(sql.getValue().contains("facet_values AS"));
    }

    @Test void purchaseExportStreamsEveryAuthorizedSourceRowWithoutTableMetadataQueries() {
        EntityManager em=mock(EntityManager.class);Query rows=mock(Query.class);
        when(em.createNativeQuery(anyString())).thenReturn(rows);
        var raw=new java.util.ArrayList<Object[]>();
        for(int index=0;index<1001;index++) {
            var value=taskRow("PURCHASE","PURCHASE_ORDER",UUID.randomUUID(),UUID.randomUUID());
            value[4]="PP-"+index;raw.add(value);
        }
        when(rows.getResultList()).thenReturn(raw.subList(0,500),raw.subList(500,1000),raw.subList(1000,1001));
        var pages=new java.util.ArrayList<com.uten.imp.common.export.ExportPayload>();
        com.uten.imp.common.export.ExportPayload result;
        var access=fullTaskAccess();
        when(access.documentAccess("PURCHASE","PURCHASE_ORDER")).thenReturn(new FulfillmentWorkbenchAccessPolicy.DocumentAccess(true,false));
        try(var sink=com.uten.imp.common.export.ExportPageSink.open(pages::add)) {
            result=new FulfillmentWorkbenchQueryService(em,access).exportPurchase("","","",null,null,null,1001);
        }
        assertEquals(1001,result.total());assertTrue(result.rows().isEmpty());
        assertEquals(List.of(500,500,1),pages.stream().map(p->p.rows().size()).toList());
        var values=pages.stream().flatMap(p->p.rows().stream()).toList();
        assertEquals(1001,values.stream().map(v->v.get("planNo")).distinct().count());
        assertEquals("PP-1000",values.getLast().get("planNo"));
        assertEquals(raw.getLast()[1],values.getLast().get("taskId"));
        assertTrue(values.stream().allMatch(v->BigDecimal.TEN.equals(v.get("requiredQty"))));
        verify(rows,org.mockito.Mockito.never()).getSingleResult();
        ArgumentCaptor<String> sql=ArgumentCaptor.forClass(String.class);verify(em,times(3)).createNativeQuery(sql.capture());
        assertTrue(sql.getAllValues().stream().noneMatch(q->q.contains("CROSS JOIN LATERAL (VALUES")||q.contains("SELECT COUNT(*)")));
        assertTrue(sql.getValue().contains("department, action_doc_type, action_doc_id, action_item_id"));
    }
    @Test void legacyPurchaseExportRejects501RowsRatherThanPublishingTheFirst500() {
        EntityManager em=mock(EntityManager.class);Query rows=mock(Query.class);when(em.createNativeQuery(anyString())).thenReturn(rows);
        Object[] value=taskRow("PURCHASE","PURCHASE_ORDER",UUID.randomUUID(),UUID.randomUUID());
        var access=fullTaskAccess();
        when(access.documentAccess("PURCHASE","PURCHASE_ORDER")).thenReturn(new FulfillmentWorkbenchAccessPolicy.DocumentAccess(true,false));
        when(rows.getResultList()).thenReturn(java.util.Collections.nCopies(500,value),java.util.Collections.singletonList(value));
        try(var scope=new com.uten.imp.common.export.LegacyExportBudget(1).open()) {
            var error=org.junit.jupiter.api.Assertions.assertThrows(com.uten.imp.common.web.ApiException.class,()->
                    new FulfillmentWorkbenchQueryService(em,access).exportPurchase("","","",null,null,null,100_000));
            assertEquals(com.uten.imp.common.web.ErrorCode.VALIDATION_FAILED,error.getCode());
        }
    }
    @Test void anEmptyPurchaseExportDoesNotRunBadgesFacetsOrSummary() {
        EntityManager em=mock(EntityManager.class);Query rows=mock(Query.class);when(em.createNativeQuery(anyString())).thenReturn(rows);
        when(rows.getResultList()).thenReturn(List.of());
        var payload=new FulfillmentWorkbenchQueryService(em,fullTaskAccess()).exportPurchase("","","",null,null,null,500);
        assertEquals(0,payload.total());assertFalse(payload.columns().isEmpty());
        verify(em).createNativeQuery(anyString());verify(rows,org.mockito.Mockito.never()).getSingleResult();
    }

    @Test
    void purchaseEntryUsesOneAggregateWithoutRowsTableFacetsOrDerivedJoins() {
        EntityManager em = mock(EntityManager.class);
        Query aggregate = mock(Query.class);
        when(em.createNativeQuery(anyString())).thenReturn(aggregate);
        when(aggregate.getResultList()).thenReturn(List.of(
                new Object[]{"WAITING_ORDER", 4L, 1L, 4L, new BigDecimal("12")},
                new Object[]{"ORDER_PENDING_APPROVAL", 2L, 0L, 2L, new BigDecimal("7")},
                new Object[]{"COMPLETED", 20L, 0L, 0L, BigDecimal.ZERO}));
        FulfillmentWorkbenchPage page = new FulfillmentWorkbenchQueryService(em, fullTaskAccess())
                .overview("PURCHASE", "", com.uten.imp.application.port.WarehouseTaskScopePort.WarehouseTaskScope.ALL);

        assertTrue(page.items().isEmpty());
        assertTrue(page.facets().isEmpty());
        assertEquals(26L, page.summary().totalTasks());
        assertEquals(6L, page.summary().pendingTasks());
        assertEquals(new BigDecimal("19"), page.summary().openQty());
        assertEquals(2L, page.summary().statusCounts().get("IN_PROGRESS"));
        assertTrue(page.capabilities().canCreatePurchaseOrder());
        ArgumentCaptor<String> sql = ArgumentCaptor.forClass(String.class);
        verify(em).createNativeQuery(sql.capture());
        assertTrue(sql.getValue().contains("v_procurement_decomposition_tasks"));
        assertFalse(sql.getValue().contains("OFFSET"));
        assertFalse(sql.getValue().contains("CROSS JOIN LATERAL (VALUES"));
        assertFalse(sql.getValue().contains("closure_state"));
        assertTrue(sql.getValue().contains("CASE WHEN action_doc_type='PURCHASE_ORDER' AND task_status='FINANCE_REJECTED' "
                + "THEN 'FINANCE_REJECTED' ELSE exception_code END"));
    }

    @Test
    void warehouseEntryDoesNotReadRowsWithoutWarehouseTaskAccess() {
        EntityManager em = mock(EntityManager.class);
        FulfillmentWorkbenchPage page = new FulfillmentWorkbenchQueryService(em,
                mock(FulfillmentWorkbenchAccessPolicy.class)).overview("WAREHOUSE", "",
                com.uten.imp.application.port.WarehouseTaskScopePort.WarehouseTaskScope.ALL);
        assertEquals(0, page.summary().totalTasks());
        verify(em, times(0)).createNativeQuery(anyString());
    }

    private static FulfillmentWorkbenchAccessPolicy fullTaskAccess() {
        var access = mock(FulfillmentWorkbenchAccessPolicy.class);
        when(access.canCreatePurchaseOrder()).thenReturn(true);
        when(access.canCreateSubcontractOrder()).thenReturn(true);
        when(access.canDecideSubcontractShortDelivery()).thenReturn(true);
        when(access.documentAccess(anyString(), org.mockito.ArgumentMatchers.eq("ORDER")))
                .thenReturn(new FulfillmentWorkbenchAccessPolicy.DocumentAccess(true, true));
        when(access.orderTaskScope(anyString(), anyString(), anyString()))
                .thenReturn(new com.uten.imp.security.DocumentAccessPolicy.NativeReadScope("1=1", null, Set.of()));
        return access;
    }

    @Test
    void exceptionFilterAndOptionsAreEvaluatedByTheDatabaseNotTheCurrentPage() {
        EntityManager em = mock(EntityManager.class);
        Query rows = mock(Query.class);
        when(em.createNativeQuery(anyString()))
                .thenReturn(rows);

        when(rows.getResultList()).thenReturn(pageResult(
                List.of(),
                new Object[]{5L, 2L, 4L, new BigDecimal("12")},
                Collections.singletonList(new Object[]{"UNPEGGED", 3L}),
                Collections.singletonList(new Object[]{"OVERDUE_SHORTAGE", 2L}),
                4L,
                List.of()));

        FulfillmentWorkbenchAccessPolicy accessPolicy =
                mock(FulfillmentWorkbenchAccessPolicy.class);
        FulfillmentWorkbenchPage result = new FulfillmentWorkbenchQueryService(em, accessPolicy)
                .query("PURCHASE", "UNPEGGED", "轴套", "OVERDUE_ANY", null, null, 2, 20);

        verify(rows).setParameter("exception", "OVERDUE_ANY");
        assertEquals(2L, result.summary().exceptionCounts().get("OVERDUE_SHORTAGE"));

        ArgumentCaptor<String> sql = ArgumentCaptor.forClass(String.class);
        verify(em).createNativeQuery(sql.capture());
        assertTrue(sql.getAllValues().getFirst().contains("OVERDUE_ANY"));
        assertTrue(sql.getAllValues().getFirst().contains("exception_code IS NOT NULL"));
    }

    @Test
    void pendingCardCountIgnoresTheActiveStatusCardFilter() {
        EntityManager em = mock(EntityManager.class);
        Query rows = mock(Query.class);
        when(em.createNativeQuery(anyString()))
                .thenReturn(rows);

        when(rows.getResultList()).thenReturn(pageResult(
                List.of(),
                new Object[]{3L, 0L, 0L, BigDecimal.ZERO},
                List.of(),
                List.of(),
                9L,
                List.of()));

        FulfillmentWorkbenchPage result = new FulfillmentWorkbenchQueryService(
                        em, mock(FulfillmentWorkbenchAccessPolicy.class))
                .query("PURCHASE", "COMPLETED", "", "", null, null, 1, 20);

        // 「待完成」聚合忽略所选状态和日期，不被「已完成」卡清零。
        assertEquals(9L, result.summary().pendingTasks());

        ArgumentCaptor<String> sql = ArgumentCaptor.forClass(String.class);
        verify(em).createNativeQuery(sql.capture());
        assertTrue(sql.getAllValues().getFirst().contains("OPEN_ANY"));
        assertTrue(sql.getAllValues().getLast().contains("open_line_count>0"));
    }

    @Test
    void openAnyStatusSentinelFiltersByOpenQuantity() {
        EntityManager em = mock(EntityManager.class);
        Query rows = mock(Query.class);
        when(em.createNativeQuery(anyString()))
                .thenReturn(rows);

        when(rows.getResultList()).thenReturn(pageResult(
                List.of(),
                new Object[]{6L, 1L, 6L, new BigDecimal("30")},
                List.of(),
                List.of(),
                6L,
                List.of()));

        FulfillmentWorkbenchPage result = new FulfillmentWorkbenchQueryService(
                        em, mock(FulfillmentWorkbenchAccessPolicy.class))
                .query("SUBCONTRACT", "OPEN_ANY", "", "", null, null, 1, 20);

        // OPEN_ANY 哨兵原样下传 SQL（按 open_qty > 0 过滤），不当作真实 task_status。
        verify(rows).setParameter("status", "OPEN_ANY");
        assertEquals(6L, result.summary().pendingTasks());
    }

    @Test
    void purchaseCountUsesRequestLineDecompositionProjection() {
        EntityManager em = mock(EntityManager.class);
        Query countQuery = mock(Query.class);
        when(em.createNativeQuery(anyString())).thenReturn(countQuery);
        when(countQuery.getSingleResult()).thenReturn(new Object[]{7L, 5L, 2L, 0L});

        long count = new FulfillmentWorkbenchQueryService(
                em, fullTaskAccess())
                .countPending("PURCHASE");

        assertEquals(7L, count);
        ArgumentCaptor<String> sql = ArgumentCaptor.forClass(String.class);
        verify(em).createNativeQuery(sql.capture());
        String captured = sql.getValue();
        assertTrue(captured.contains("v_procurement_decomposition_tasks"));
        assertTrue(captured.contains("open_qty > 0"));
        // 红徽章只数「等本部门动手」的两档（2026-09-11）：等待财务审核 / 财务已通过
        // 下一步在财务和供应商手上，是监控数，混进合计会让工作台卡片数字对不上
        // 页面里各红色分段之和。
        assertTrue(captured.contains("decomposition.task_status = 'FINANCE_REJECTED'"));
        assertTrue(captured.contains("decomposition.task_status = 'WAITING_ORDER' AND decomposition.open_qty > 0"));
        assertFalse(captured.contains("subcontract_short_delivery_cases"));
        assertFalse(captured.contains("ORDER_PENDING_APPROVAL"));
        verify(countQuery).setParameter("department", "PURCHASE");
    }

    /**
     * 委外红数只数申请待分解、财务驳回与回厂短交待判定; 「可领料」的委外任务是「领料」分段的红数,
     * 由委外领料模块单独登记, 这里不能再数一遍; 前置自制合成行已经删除。采购分支不带委外片段。
     */
    @Test
    void subcontractPendingCountLeavesDrawableTasksToTheDrawSegmentAndPurchaseStaysUntouched() {
        EntityManager em = mock(EntityManager.class);
        Query countQuery = mock(Query.class);
        when(em.createNativeQuery(anyString())).thenReturn(countQuery);
        when(countQuery.getSingleResult()).thenReturn(new Object[]{2L, 1L, 1L, 0L});
        FulfillmentWorkbenchQueryService service = new FulfillmentWorkbenchQueryService(
                em, fullTaskAccess());

        assertEquals(2L, service.countPending("SUBCONTRACT"));
        assertEquals(2L, service.countPending("PURCHASE"));

        ArgumentCaptor<String> sql = ArgumentCaptor.forClass(String.class);
        verify(em, times(2)).createNativeQuery(sql.capture());
        String subcontract = sql.getAllValues().getFirst();
        assertTrue(subcontract.contains("decomposition.task_status = 'WAITING_ORDER'"));
        assertTrue(subcontract.contains("decomposition.task_status = 'FINANCE_REJECTED'"));
        assertTrue(subcontract.contains("subcontract_short_delivery_cases"));
        assertFalse(subcontract.contains("fn_subcontract_draw_summary"));
        assertFalse(subcontract.contains("preplan_subcontract_make_tasks"));
        String purchase = sql.getAllValues().getLast();
        assertFalse(purchase.contains("subcontract_short_delivery_cases"));
        assertTrue(purchase.contains("decomposition.action_doc_type = 'PURCHASE_ORDER'"));
    }

    /** 黄数只数财审三档(等待财务审核 / 财务已通过 / 财务已退回), 采购与委外同一口径。 */
    @Test
    void inProgressCountOnlyCountsTheThreeFinanceStages() {
        EntityManager em = mock(EntityManager.class);
        Query countQuery = mock(Query.class);
        when(em.createNativeQuery(anyString())).thenReturn(countQuery);
        when(countQuery.getSingleResult()).thenReturn(1L);
        FulfillmentWorkbenchQueryService service = new FulfillmentWorkbenchQueryService(
                em, fullTaskAccess());

        assertEquals(1L, service.countInProgress("SUBCONTRACT"));
        assertEquals(1L, service.countInProgress("PURCHASE"));

        ArgumentCaptor<String> sql = ArgumentCaptor.forClass(String.class);
        verify(em, times(2)).createNativeQuery(sql.capture());
        for (String captured : sql.getAllValues()) {
            assertFalse(captured.contains("decomposition.open_qty > 0 AND"));
            assertTrue(captured.contains(
                    "task_status IN ('ORDER_PENDING_APPROVAL', 'FINANCE_APPROVED', 'FINANCE_REJECTED')"));
        }
    }

    /**
     * ADR-143 §4.1: 已批准委外订货单的「进行中」状态列按领料模型取第一个命中, 可领料逐明细按
     * fn_subcontract_draw_summary 判; 分段计数仍按 task_status 分桶, IN_PROGRESS 只数财审三档。
     */
    @Test
    void subcontractOrderStagesFollowTheDrawModelAndStatusCountsStayOnTaskStatus() {
        EntityManager em = mock(EntityManager.class);
        Query rows = mock(Query.class);
        when(em.createNativeQuery(anyString()))
                .thenReturn(rows);

        when(rows.getResultList()).thenReturn(pageResult(
                List.of(),
                new Object[]{3L, 0L, 3L, new BigDecimal("30")},
                List.of(
                new Object[]{"FINANCE_APPROVED", 1L},
                new Object[]{"WAITING_ORDER", 4L}),
                List.of(),
                3L,
                List.of()));
        FulfillmentWorkbenchAccessPolicy accessPolicy = mock(FulfillmentWorkbenchAccessPolicy.class);
        when(accessPolicy.canCreateSubcontractOrder()).thenReturn(true);

        FulfillmentWorkbenchPage page = new FulfillmentWorkbenchQueryService(em, accessPolicy)
                .query("SUBCONTRACT", "WAITING_ORDER", "", "", null, null, 1, 20);

        assertEquals(4L, page.summary().statusCounts().get("WAITING_ORDER"));
        assertEquals(1L, page.summary().statusCounts().get("IN_PROGRESS"), "黄数只数财审三档");
        assertFalse(page.summary().statusCounts().containsKey("WAITING_COMPONENT_STOCK"));

        ArgumentCaptor<String> sql = ArgumentCaptor.forClass(String.class);
        verify(em).createNativeQuery(sql.capture());
        String rowsSql = sql.getAllValues().getFirst();
        assertTrue(rowsSql.contains("v.task_id, v.package_id, v.plan_id, v.plan_no"));
        assertTrue(rowsSql.contains("ARRAY[v.action_item_id::text] AS action_item_ids"));
        assertFalse(rowsSql.contains("GROUP BY v.department, v.action_doc_type, v.action_doc_id"));
        assertTrue(rowsSql.contains("received_item.id = base.action_item_id"));
        assertTrue(rowsSql.contains("short_case.order_item_id = base.action_item_id"));
        List<String> precedence = List.of(
                "THEN 'SHORT_DELIVERY'", "THEN 'WAITING_MORE_BATCH'", "THEN 'TOLERANT_SHORT'",
                "THEN 'RECEIVED_PENDING_STOCK'", "WHEN progress.any_drawable THEN 'DRAWABLE'",
                "WHEN progress.any_draw_submitted THEN 'DRAW_SUBMITTED'", "THEN 'PARTIAL_RECEIVED'",
                "WHEN progress.any_issued THEN 'AT_SUPPLIER'", "ELSE 'WAITING_MATERIAL' END",
                "AND bom_gap.bom_missing THEN 'BOM_MISSING'",
                "WHEN kit.open_qty > 0 AND kit.orderable_lines = 0 THEN 'WAITING_KIT'",
                "WHEN kit.open_qty > 0 AND kit.orderable_qty < kit.open_qty THEN 'KIT_PARTIAL'");
        int previous = -1;
        for (String stage : precedence) {
            int at = rowsSql.indexOf(stage);
            assertTrue(at > previous, "状态列优先级顺序: " + stage);
            previous = at;
        }
        assertTrue(rowsSql.contains("CROSS JOIN LATERAL fn_subcontract_draw_summary(draw_item.id) draw_summary"));
        // ADR-143 §二.3：委外申请里有缺 BOM 的委外件时不能生成订货单, 状态列为「缺 BOM·已通知研发」。
        // ADR-156：直属物料一套都不够的申请也不能生成订货单(等物料齐套), 可下单数量只读库函数。
        assertTrue(rowsSql.contains(
                "AND base.open_line_count > 0 AND NOT COALESCE(bom_gap.bom_missing, FALSE)"
                        + " AND COALESCE(kit.orderable_lines, 0) > 0) AS can_create_order"));
        assertTrue(rowsSql.contains("WITH kit_base AS MATERIALIZED"));
        assertTrue(rowsSql.contains("WHERE department = 'SUBCONTRACT'"));
        assertTrue(rowsSql.contains("kit_quantities AS MATERIALIZED"));
        assertTrue(rowsSql.contains("fn_subcontract_application_orderable_batch(ARRAY("));
        assertTrue(rowsSql.contains("JOIN kit_quantities quantity ON quantity.application_item_id = kit_ref.item_id::uuid"));
        assertFalse(rowsSql.contains("fn_subcontract_application_kit_qty("), "no per-ID global pool rescan");
        assertTrue(rowsSql.contains("kit.orderable_qty AS orderable_qty"));
        assertTrue(rowsSql.contains("NOT EXISTS (SELECT 1 FROM fn_subcontract_draw_edges(gap_item.goods_id))"));
        assertTrue(rowsSql.contains("bom_gap.rd_task_no AS rd_task_no"));
        assertTrue(rowsSql.contains("OR (:status NOT IN ('OPEN_ANY', 'IN_PROGRESS') AND task_status = :status)"));
        for (String removed : List.of("flow_mode", "component", "AWAITING_OUTBOUND", "OUTBOUND_WAITING_COMPONENT",
                "preplan_subcontract_make", "SUBCONTRACT_MAKE_TASK", "SUPPLIER_SELF_SUPPLIED", "self_supplied")) {
            assertFalse(rowsSql.contains(removed), removed);
        }
        String statusSql = sql.getAllValues().getFirst();
        // ADR-143 §二.3: 缺 BOM 的申请行留在「待处理」段, 但单独按 BOM_MISSING 分桶, 不计入该段红数。
        assertTrue(statusSql.contains(
                "SELECT CASE WHEN display_stage='BOM_MISSING' THEN 'BOM_MISSING' ELSE task_status END AS status_key"));
        assertTrue(statusSql.contains("GROUP BY 1"));
        assertFalse(statusSql.contains("WAITING_COMPONENT_STOCK"));
    }

    /** 采购按任务状态展示；已生效单据的改量复核有明确文案，不拼委外领料片段。 */
    @Test
    void purchaseRowsUseTaskStatusAsDisplayStage() {
        EntityManager em = mock(EntityManager.class);
        Query rows = mock(Query.class);
        when(em.createNativeQuery(anyString()))
                .thenReturn(rows);

        when(rows.getResultList()).thenReturn(pageResult(
                List.of(),
                new Object[]{0L, 0L, 0L, BigDecimal.ZERO},
                List.of(),
                List.of(),
                0L,
                List.of()));

        new FulfillmentWorkbenchQueryService(em, mock(FulfillmentWorkbenchAccessPolicy.class))
                .query("PURCHASE", "", "", "", null, null, 1, 20);

        ArgumentCaptor<String> sql = ArgumentCaptor.forClass(String.class);
        verify(em).createNativeQuery(sql.capture());
        String rowsSql = sql.getAllValues().getFirst();
        assertTrue(rowsSql.contains("THEN 'FINANCE_REVIEW_PENDING'"));
        assertTrue(rowsSql.contains("THEN 'FINANCE_REVIEW_REJECTED'"));
        assertTrue(rowsSql.contains("ELSE base.task_status END"));
        assertFalse(rowsSql.contains("fn_subcontract_draw_summary"));
        assertFalse(rowsSql.contains("component"));
        assertTrue(rowsSql.contains("OR (:status NOT IN ('OPEN_ANY', 'IN_PROGRESS') AND task_status = :status)"));
    }

    /** 第 37 列 display_stage 读进行对象, 脱敏/透传两条路都不丢; 短行 (旧 34 列) 为 null. */
    @Test
    void displayStageAndOrderCapabilityAreReadFromTheRowAndSurviveActionCopy() {
        EntityManager em = mock(EntityManager.class);
        Query rows = mock(Query.class);
        Query sources = mock(Query.class);
        when(em.createNativeQuery(anyString()))
                .thenReturn(rows, sources);

        UUID documentId = UUID.randomUUID();
        Object[] wide = java.util.Arrays.copyOf(
                taskRow("SUBCONTRACT", "SUBCONTRACT_APPLICATION", documentId, UUID.randomUUID()), 37);
        wide[35] = Boolean.TRUE;
        wide[36] = "WAITING_ORDER";

        when(rows.getResultList()).thenReturn(pageResult(
                List.of(
                wide, taskRow("SUBCONTRACT", "SUBCONTRACT_APPLICATION", UUID.randomUUID(), UUID.randomUUID())),
                new Object[]{2L, 0L, 2L, BigDecimal.TEN},
                List.of(),
                List.of(),
                0L,
                List.of()));
        FulfillmentWorkbenchAccessPolicy accessPolicy = mock(FulfillmentWorkbenchAccessPolicy.class);
        when(accessPolicy.documentAccess("SUBCONTRACT", "SUBCONTRACT_APPLICATION"))
                .thenReturn(new FulfillmentWorkbenchAccessPolicy.DocumentAccess(true, true));

        FulfillmentWorkbenchPage page = new FulfillmentWorkbenchQueryService(em, accessPolicy)
                .query("SUBCONTRACT", "", "", "", null, null, 1, 20);

        FulfillmentTaskRow ready = page.items().getFirst();
        assertEquals("WAITING_ORDER", ready.displayStage());
        assertTrue(ready.canCreateOrder());
        assertEquals(null, page.items().get(1).displayStage());
    }

    @Test
    void warehouseCountUsesTheFulfillmentProjectionAndOpenQuantity() {
        EntityManager em = mock(EntityManager.class);
        Query countQuery = mock(Query.class);
        when(em.createNativeQuery(anyString())).thenReturn(countQuery);
        when(countQuery.getSingleResult()).thenReturn(4L);
        FulfillmentWorkbenchAccessPolicy accessPolicy =
                mock(FulfillmentWorkbenchAccessPolicy.class);
        when(accessPolicy.canHandleWarehouseTasks()).thenReturn(true);

        long count = new FulfillmentWorkbenchQueryService(
                em, accessPolicy)
                .countPending("WAREHOUSE");

        assertEquals(4L, count);
        ArgumentCaptor<String> sql = ArgumentCaptor.forClass(String.class);
        verify(em).createNativeQuery(sql.capture());
        // One requested DRAW or one pending material-definition request is one task.
        assertTrue(sql.getValue().contains("FROM (SELECT * FROM v_fulfillment_workbench archive_scope"));
        assertTrue(sql.getValue().contains("WHERE NOT fn_imported_business_document('production_plans',archive_scope.plan_id)) v"));
        assertTrue(sql.getValue().contains("mapping.demand_id=v.task_id"));
        assertTrue(sql.getValue().contains("draw_doc.warehouse_id AS warehouse_id"));
        assertTrue(sql.getValue().contains("open_line_count > 0"));
        assertTrue(sql.getValue().contains("fn_production_draw_requested(draw_doc.id)"));
        assertTrue(sql.getValue().contains("AND NOT COALESCE(actual_warehouse.is_line_side,FALSE)"));
        assertTrue(sql.getValue().contains("production_material_discovery_requests"));
        assertTrue(sql.getValue().contains("request.status='PENDING'"));
        verify(countQuery).setParameter("department", "WAREHOUSE");
    }

    @Test
    void warehouseListAndStatusBreakdownRequireTheSameExplicitRequest() {
        EntityManager em = mock(EntityManager.class);
        Query query = mock(Query.class);
        when(em.createNativeQuery(anyString())).thenReturn(query);
        when(query.getResultList()).thenReturn(List.of());
        FulfillmentWorkbenchAccessPolicy access = mock(FulfillmentWorkbenchAccessPolicy.class);
        when(access.canHandleWarehouseTasks()).thenReturn(true);

        new FulfillmentWorkbenchQueryService(em, access).warehouseStatusBreakdown();

        ArgumentCaptor<String> sql = ArgumentCaptor.forClass(String.class);
        verify(em).createNativeQuery(sql.capture());
        assertTrue(sql.getValue().contains(FulfillmentWorkbenchQueryService.WAREHOUSE_DOCUMENT_ROWS));
        assertTrue(sql.getValue().contains("fn_production_draw_requested(draw_doc.id)"));
    }

    @Test void warehouseUnknownMaterialRequestsHaveTheirOwnStatusAndCountOnceWithoutInventingQuantity() {
        EntityManager em = mock(EntityManager.class);
        Query query = mock(Query.class);
        when(em.createNativeQuery(anyString())).thenReturn(query);
        when(query.getResultList()).thenReturn(List.of(new Object[]{"READY_TO_PICK", 3L},
                new Object[]{"PARTIAL", 2L}, new Object[]{"MATERIALS_TO_DEFINE", 4L}));
        FulfillmentWorkbenchAccessPolicy access = mock(FulfillmentWorkbenchAccessPolicy.class);
        when(access.canHandleWarehouseTasks()).thenReturn(true);
        var counts = new FulfillmentWorkbenchQueryService(em, access).warehouseStatusBreakdown(
                new com.uten.imp.application.port.WarehouseTaskScopePort.WarehouseTaskScope(true, List.of(), true));
        assertEquals(4L, counts.get("MATERIALS_TO_DEFINE"));
        assertEquals(9L, counts.get("OPEN_ANY"));
        ArgumentCaptor<String> sql = ArgumentCaptor.forClass(String.class);
        verify(em).createNativeQuery(sql.capture());
        assertTrue(sql.getValue().contains("material.qty, 'MATERIALS_TO_DEFINE'"));
        assertTrue(sql.getValue().contains("jsonb_to_recordset(request.requested_materials)"));
        assertTrue(sql.getValue().contains("request.status='PENDING'"));
        assertTrue(sql.getValue().contains("NOT plan.is_closed"));
        assertTrue(sql.getValue().contains("warehouse_id IS NULL OR"));
        verify(query).setParameter("warehouse_scope", "");
    }

    /** 生产领料任务中心表头排序(2026-09-24): 按生产计划号排, 白名单字段;
     *  2026-09-25 单号列统一: 仓库多跑一次 docNo(领料单号)分面查询, 桶随响应带回。 */
    @Test
    void warehouseRowsSortByPlanNumberAndCarryDocNoFacets() {
        EntityManager em = mock(EntityManager.class);
        Query rows = mock(Query.class);
        when(em.createNativeQuery(anyString()))
                .thenReturn(rows);

        when(rows.getResultList()).thenReturn(pageResult(
                List.of(),
                new Object[]{0L, 0L, 0L, BigDecimal.ZERO},
                List.of(),
                List.of(),
                0L,
                List.of(new Object[]{"LL2609001", 2L}, new Object[]{null, 1L})));
        FulfillmentWorkbenchAccessPolicy access = mock(FulfillmentWorkbenchAccessPolicy.class);
        when(access.canAccessWarehouseTasks()).thenReturn(true);

        FulfillmentWorkbenchPage result = new FulfillmentWorkbenchQueryService(em, access).query(
                "WAREHOUSE", "OPEN_ANY", "", "", null, null, 1, 20,
                new FulfillmentWorkbenchTableQuery("planNo", "desc", java.util.Map.of(), null, null, null, null));

        ArgumentCaptor<String> sql = ArgumentCaptor.forClass(String.class);
        verify(em).createNativeQuery(sql.capture());
        assertTrue(sql.getAllValues().getFirst().contains("NULLIF(plan_no,'') DESC NULLS LAST, task_id"));
        // 表头名称汇总(2026-10-30): 仓库分面改为 docNo/planNo/goods/colorName 多列
        // VALUES 分组(各列排除自身筛选), 与列表同一份 WHERE。
        String whole = sql.getAllValues().getLast();
        String facets = whole.substring(whole.indexOf("facet_rows AS (") + "facet_rows AS (".length());
        assertTrue(facets.contains("CROSS JOIN LATERAL (VALUES"));
        assertTrue(facets.contains("('docNo',visible_doc_no"));
        assertTrue(facets.contains("('colorName',NULLIF(color_name,'')"));
        assertTrue(facets.contains("GROUP BY facet.key, facet.value"));
        assertEquals(1, result.facets().size());
        assertEquals("LL2609001", result.facets().get("docNo").getFirst().value());
        assertEquals(2L, result.facets().get("docNo").getFirst().count());
        // 看不见领料单号的行（对象范围裁剪/物料待定）计进 nullCounts，不混进桶。
        assertEquals(1L, result.nullCounts().get("docNo"));
    }

    @Test
    void warehouseSortOnlyColumnsAreWhitelistedAndNeverBecomeFilters() {
        assertEquals("NULLIF(warehouse_name,'') ASC NULLS LAST, task_id",
                new FulfillmentWorkbenchTableQuery("warehouseName", "asc", java.util.Map.of(),
                        null, null, null, null).orderSql());
        assertEquals("open_qty DESC NULLS LAST, task_id",
                new FulfillmentWorkbenchTableQuery("openQty", "desc", java.util.Map.of(),
                        null, null, null, null).orderSql());
        assertEquals("difference_qty ASC NULLS LAST, task_id",
                new FulfillmentWorkbenchTableQuery("differenceQty", "asc", java.util.Map.of(),
                        null, null, null, null).orderSql());
        assertEquals("goods_code DESC NULLS LAST, task_id",
                new FulfillmentWorkbenchTableQuery("goodsCode", "desc", java.util.Map.of(),
                        null, null, null, null).orderSql());
        org.junit.jupiter.api.Assertions.assertThrows(com.uten.imp.common.web.ApiException.class,
                () -> new FulfillmentWorkbenchTableQuery("warehouseName", "asc",
                        java.util.Map.of("warehouseName", "成品仓库"), null, null, null, null));
        org.junit.jupiter.api.Assertions.assertThrows(com.uten.imp.common.web.ApiException.class,
                () -> new FulfillmentWorkbenchTableQuery("warehouse_name;--", "asc",
                        java.util.Map.of(), null, null, null, null));
    }

    @Test
    void differenceHeaderUsesExactBoundComparisonsAndKeepsUnknownFactsUnknown() {
        var table = FulfillmentWorkbenchTableQuery.from("differenceQty", "asc", java.util.Map.of(
                "search.differenceQty", "-9007199254740993.0001..0"), null, null, null, null);
        String sql = table.filterSql(null);
        assertTrue(sql.contains("visible_doc_no IS NOT NULL"));
        assertTrue(sql.contains("COALESCE(goods_count,0)<=1"));
        assertTrue(sql.contains("COALESCE(open_line_count,0)<=1"));
        assertTrue(sql.contains("COALESCE(cardinality(action_item_ids),0)<=1"));
        assertTrue(sql.contains("THEN difference_qty END) BETWEEN :numeric_differenceQty_lower AND :numeric_differenceQty_upper"));
        assertFalse(sql.contains("-9007199254740993.0001"));
        assertFalse(sql.contains("COALESCE(difference_qty"));
        Query query = mock(Query.class);
        table.bind(query);
        verify(query).setParameter("numeric_differenceQty_lower", new BigDecimal("-9007199254740993.0001"));
        verify(query).setParameter("numeric_differenceQty_upper", BigDecimal.ZERO);
        assertEquals("", table.filterSql("differenceQty"));
        for (String value : List.of("-1", "!=0", ">=0.0001")) {
            var comparison = FulfillmentWorkbenchTableQuery.from("differenceQty", "asc", java.util.Map.of(
                    "search.differenceQty", value), null, null, null, null);
            assertTrue(comparison.filterSql(null).contains(":numeric_differenceQty"));
        }
        for (String invalid : List.of("1..-1", "abc", "1;SELECT 1", "1".repeat(129)))
            org.junit.jupiter.api.Assertions.assertThrows(com.uten.imp.common.web.ApiException.class,
                    () -> FulfillmentWorkbenchTableQuery.from("differenceQty", "asc",
                            java.util.Map.of("search.differenceQty", invalid), null, null, null, null));
    }

    @Test
    void columnTextSearchesRemainBoundAndIndependentFromExactFacetValues() {
        var table = FulfillmentWorkbenchTableQuery.from("supplierName", "asc", java.util.Map.of(
                "f.goods", "goods-uuid", "search.goods", "开关 面板", "search.goodsCode", "M3_20%",
                "search.supplierName", "华东"), null, null, null, null);
        String sql = table.filterSql(null);
        // colorName 进入精确筛选白名单(2026-10-30)后参数序号整体后移一位。
        assertTrue(sql.contains("goods_id::text = :filter_2"));
        assertTrue(sql.contains(":filter_8"));
        assertTrue(sql.contains(":filter_9"));
        assertTrue(sql.contains("lower(COALESCE(goods_name,''))"), "the goods-name header only searches names");
        assertTrue(sql.contains("lower(COALESCE(goods_code,''))"), "the independent code header still searches codes");
        assertFalse(sql.contains("concat_ws(' ',goods_code,goods_name)"), "a code match must not satisfy a name-column word");
        assertFalse(sql.contains("M3_20%"));
        assertFalse(sql.contains("华东"));
        Query query = mock(Query.class);
        table.bind(query);
        verify(query).setParameter("filter_2", "goods-uuid");
        verify(query).setParameter("filter_8", "开关 面板");
        verify(query).setParameter("filter_9", "M3_20%");
        org.junit.jupiter.api.Assertions.assertThrows(com.uten.imp.common.web.ApiException.class,
                () -> FulfillmentWorkbenchTableQuery.from("needDate", "asc",
                        java.util.Map.of("search.goods);DROP TABLE goods;--", "x"), null, null, null, null));
    }

    @Test
    void maliciousFacetValuesStayBoundAndExcludedFacetsKeepTheOtherParameterIdentities() {
        String value = "x' OR TRUE; DROP TABLE goods;--";
        var table = FulfillmentWorkbenchTableQuery.from("goods", "DESC", java.util.Map.of(
                "f.docNo", value, "search.goods", value, "f.goods", "__null__"), null, null, null, null);
        String sql = table.filterSql("docNo");
        assertFalse(sql.contains(value));
        assertTrue(sql.contains("goods_id::text IS NULL"));
        assertFalse(sql.contains("visible_doc_no ="));
        Query query = mock(Query.class);
        table.bindFilters(query, "docNo");
        verify(query).setParameter("filter_8", value);
        org.mockito.Mockito.verifyNoMoreInteractions(query);
        assertEquals("goods_code DESC NULLS LAST, goods_name DESC NULLS LAST, task_id", table.orderSql());
        org.junit.jupiter.api.Assertions.assertThrows(com.uten.imp.common.web.ApiException.class,
                () -> FulfillmentWorkbenchTableQuery.from("goods", "desc; SELECT pg_sleep(1)",
                        java.util.Map.of(), null, null, null, null));
    }

    @Test
    void warehouseCountIsZeroOutsideTheWarehouseOrganizationScope() {
        EntityManager em = mock(EntityManager.class);
        FulfillmentWorkbenchAccessPolicy accessPolicy =
                mock(FulfillmentWorkbenchAccessPolicy.class);

        long count = new FulfillmentWorkbenchQueryService(
                em, accessPolicy).countPending("WAREHOUSE");

        assertEquals(0L, count);
        verify(em, org.mockito.Mockito.never()).createNativeQuery(anyString());
    }

    @Test
    void actionMetadataIsMaskedWhenTheExactDocumentPermissionIsMissing() {
        EntityManager em = mock(EntityManager.class);
        Query rows = mock(Query.class);
        when(em.createNativeQuery(anyString()))
                .thenReturn(rows);

        UUID documentId = UUID.randomUUID();
        UUID documentItemId = UUID.randomUUID();

        when(rows.getResultList()).thenReturn(pageResult(
                Collections.singletonList(taskRow(
                "PURCHASE", "PURCHASE_ORDER", documentId, documentItemId)),
                new Object[]{1L, 0L, 1L, BigDecimal.ONE},
                List.of(),
                List.of(),
                0L,
                List.of()));
        FulfillmentWorkbenchAccessPolicy accessPolicy =
                mock(FulfillmentWorkbenchAccessPolicy.class);
        when(accessPolicy.documentAccess("PURCHASE", "PURCHASE_ORDER"))
                .thenReturn(new FulfillmentWorkbenchAccessPolicy.DocumentAccess(false, false));

        FulfillmentWorkbenchPage page =
                new FulfillmentWorkbenchQueryService(em, accessPolicy)
                        .query("PURCHASE", "", "", "", null, null, 1, 20);

        FulfillmentTaskRow task = page.items().getFirst();
        assertTrue(task.actionDocRestricted());
        assertEquals(null, task.actionDocType());
        assertEquals(null, task.actionDocId());
        assertEquals(null, task.actionDocNo());
        assertEquals(null, task.actionDocItemId());
        assertEquals(null, task.actionDocStatus());
        assertTrue(!task.actionDocCanView());
        assertTrue(!task.actionDocCanEdit());
    }

    @Test
    void actionAndBatchCapabilitiesUseSeparateViewAndEditPermissions() {
        EntityManager em = mock(EntityManager.class);
        Query rows = mock(Query.class);
        when(em.createNativeQuery(anyString()))
                .thenReturn(rows);

        UUID documentId = UUID.randomUUID();
        UUID documentItemId = UUID.randomUUID();

        when(rows.getResultList()).thenReturn(pageResult(
                Collections.singletonList(taskRow(
                "PURCHASE", "PURCHASE_REQUEST", documentId, documentItemId)),
                new Object[]{1L, 0L, 1L, BigDecimal.ONE},
                List.of(),
                List.of(),
                0L,
                List.of()));
        FulfillmentWorkbenchAccessPolicy accessPolicy =
                mock(FulfillmentWorkbenchAccessPolicy.class);
        when(accessPolicy.documentAccess("PURCHASE", "PURCHASE_REQUEST"))
                .thenReturn(new FulfillmentWorkbenchAccessPolicy.DocumentAccess(true, false));
        when(accessPolicy.canCreatePurchaseOrder()).thenReturn(true);

        FulfillmentWorkbenchPage page =
                new FulfillmentWorkbenchQueryService(em, accessPolicy)
                        .query("PURCHASE", "", "", "", null, null, 1, 20);

        FulfillmentTaskRow task = page.items().getFirst();
        assertEquals(documentId, task.actionDocId());
        assertEquals(documentItemId, task.actionDocItemId());
        assertTrue(task.actionDocCanView());
        assertTrue(!task.actionDocCanEdit());
        assertTrue(!task.actionDocRestricted());
        assertTrue(page.capabilities().canCreatePurchaseOrder());
    }

    @Test
    void purchaseCountEndpointGuardsPurchaseReadPermissions() throws Exception {
        Method method = FulfillmentWorkbenchController.class.getDeclaredMethod("purchaseCount");
        assertEquals(
                "hasAnyAuthority('purchase_request:view','purchase_order:view','purchase_receipt:view','purchase_return:view')",
                method.getAnnotation(PreAuthorize.class).value());
    }

    @Test
    void warehouseCountEndpointRequiresStockDocumentView() throws Exception {
        Method method = FulfillmentWorkbenchController.class.getDeclaredMethod(
                "warehouseCount", java.util.UUID.class);
        assertEquals(
                "hasAuthority('stock_doc:view')",
                method.getAnnotation(PreAuthorize.class).value());
    }

    @Test
    void controllerReadPermissionsMatchFlutterAnyPermissionGuards() throws Exception {
        assertPermission(
                "warehouse",
                "hasAnyAuthority('stock_doc:view')");
        assertPermission(
                "purchase",
                "hasAnyAuthority('purchase_request:view','purchase_order:view','purchase_receipt:view','purchase_return:view')");
        assertPermission(
                "subcontract",
                "hasAnyAuthority('subcontract_inquiry:view','subcontract_application:view','subcontract_order:view','subcontract_receipt:view','subcontract_material_issue:view','subcontract_return:view','subcontract_material_return:view','subcontract_waste:view')");
    }

    private static void assertPermission(String methodName, String expected) throws Exception {
        // 控制器读端点签名：status/exception/keyword + dateFrom/dateTo + 分页。
        Method method = java.util.Arrays.stream(FulfillmentWorkbenchController.class.getDeclaredMethods())
                .filter(candidate -> candidate.getName().equals(methodName)).findFirst().orElseThrow();
        assertEquals(expected, method.getAnnotation(PreAuthorize.class).value());
    }

    /** Native page rows and metadata arrive together, including the empty-page aggregate row. */
    private static List<Object[]> pageResult(List<Object[]> items, Object[] summary,
                                            List<Object[]> statuses, List<Object[]> exceptions,
                                            long pending, List<Object[]> docNoFacets) {
        try {
            var mapper = new com.fasterxml.jackson.databind.ObjectMapper();
            var statusCounts = new java.util.LinkedHashMap<String, Long>();
            for (Object[] row : statuses) statusCounts.put((String) row[0], ((Number) row[1]).longValue());
            var exceptionCounts = new java.util.LinkedHashMap<String, Long>();
            for (Object[] row : exceptions) exceptionCounts.put((String) row[0], ((Number) row[1]).longValue());
            var facets = new java.util.ArrayList<Object[]>();
            for (Object[] row : docNoFacets) facets.add(new Object[]{"docNo", row[0], row[0], row[1]});
            List<Object[]> nativeRows = items.isEmpty() ? Collections.singletonList(new Object[50]) : items;
            var result = new java.util.ArrayList<Object[]>();
            for (Object[] row : nativeRows) {
                Object[] combined = java.util.Arrays.copyOf(row, 58);
                if (row.length <= 37) combined[37] = true;
                System.arraycopy(summary, 0, combined, 50, 4);
                combined[54] = mapper.writeValueAsString(statusCounts);
                combined[55] = mapper.writeValueAsString(exceptionCounts);
                combined[56] = pending;
                combined[57] = mapper.writeValueAsString(facets);
                result.add(combined);
            }
            return result;
        } catch (com.fasterxml.jackson.core.JsonProcessingException failure) {
            throw new IllegalStateException(failure);
        }
    }

    private static Object[] taskRow(
            String department,
            String documentType,
            UUID documentId,
            UUID documentItemId) {
        return new Object[]{
                department,
                UUID.randomUUID(),
                UUID.randomUUID(),
                UUID.randomUUID(),
                "PP-001",
                UUID.randomUUID(),
                "原材料仓",
                UUID.randomUUID(),
                "MAT-001",
                "轴套",
                "φ20",
                null,
                "",
                UUID.randomUUID(),
                "件",
                "PURCHASE",
                BigDecimal.TEN,
                BigDecimal.ZERO,
                BigDecimal.ZERO,
                BigDecimal.ZERO,
                BigDecimal.TEN,
                "WAITING_SUPPLY",
                Date.valueOf(LocalDate.of(2026, 8, 1)),
                null,
                null,
                OffsetDateTime.parse("2026-08-01T10:00:00+08:00"),
                documentType,
                documentId,
                "DOC-001",
                documentItemId,
                "1",
                // 2026-09-03 按单据归组新增列：单货品行 goods_count=1、
                // open_line_count=1、action_item_ids=null（stringArray 回空表）。
                1L,
                1L,
                null
        };
    }
}
