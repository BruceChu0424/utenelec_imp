import hashlib
import json
import subprocess
import sys
from pathlib import Path

root=Path(__file__).resolve().parents[4]
main_repo=Path('D:/Projects/uten_imp')
before='f6e0d8532e6e11239243b4fb2149fb90410395ba'
after=sys.argv[1] if len(sys.argv)==2 else '8cd41bc91e554b503df0835289c192b1d5b46da8'
assert len(after)==40 and set(after)<=set('0123456789abcdef')
out=root/('build/loading-validation/upstream-'+after[:5]+'-backend-preview')
out.mkdir(exist_ok=True)
def git(*args):
    return subprocess.run(['git','-C',str(main_repo),*args],check=True,capture_output=True).stdout
def names(ref):
    return set(git('ls-tree','-r','--name-only','-z',ref,'--','server').decode('utf-8').split('\0'))-{''}
old_names,new_names=names(before),names(after)
paths=git('diff','--no-renames','--name-only','-z',before,after,'--','server').decode('utf-8').split('\0')
records=[]
for path in sorted(set(paths)-{''}):
    data={}
    for label,ref,known in [('base',before,old_names),('main',after,new_names)]:
        data[label]=git('cat-file','blob',ref+':'+path) if path in known else None
    target=root/path
    data['task']=target.read_bytes() if target.is_file() else None
    hashes={label:hashlib.sha256(raw).hexdigest() if raw is not None else None for label,raw in data.items()}
    for label,raw in data.items():
        if raw is not None:
            saved=out/label/path;saved.parent.mkdir(parents=True,exist_ok=True);saved.write_bytes(raw)
    action='adopt_main' if data['task']==data['base'] else 'same' if data['task']==data['main'] else 'three_way_required'
    records.append({'path':path,**{label+'Sha256':digest for label,digest in hashes.items()},'action':action})
(out/'review.json').write_text(json.dumps({'mode':'Read-only preview; source/current B unchanged; no apply',
    'baseMain':before,'latestMain':after,'taskPrimarySource':'0d49fabceb36b97e6c871ab47762231f59bf4533e1bbdb46deab690c75377bbb',
    'entries':records},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'paths':len(records),'adoptMain':sum(row['action']=='adopt_main' for row in records),'same':sum(row['action']=='same' for row in records),'threeWayRequired':sum(row['action']=='three_way_required' for row in records),'productSourceChanged':False}))
