import hashlib
import json
import subprocess
from pathlib import Path

root=Path(__file__).resolve().parents[4]
out=root/'build/loading-validation/upstream-2dd3e-backend-preview'
review=json.loads((out/'review.json').read_text(encoding='utf-8'))
results=[]
for entry in review['entries']:
    path=entry['path']
    task=root/path
    digest=hashlib.sha256(task.read_bytes()).hexdigest() if task.is_file() else None
    assert digest==entry['taskSha256'],path
    action=entry['action']
    code=None
    diagnostic=''
    data=None
    if action=='adopt_main':
        data=(out/'main'/path).read_bytes() if entry['mainSha256'] else None
    elif action=='same':
        data=(out/'task'/path).read_bytes() if entry['taskSha256'] else None
    else:
        assert all(entry[label+'Sha256'] is not None for label in ['task','base','main']),path
        inputs=out/'merge-inputs'/hashlib.sha256(path.encode('utf-8')).hexdigest()[:12]
        inputs.mkdir(parents=True,exist_ok=True)
        names=[]
        for label in ['task','base','main']:
            target=inputs/(label+'.txt')
            original=(out/label/path).read_text(encoding='utf-8')
            target.write_text(original.replace('\r\n','\n').replace('\r','\n'),encoding='utf-8',newline='\n')
            names.append(str(target))
        merged=subprocess.run(['git','-C','D:/Projects/uten_imp','merge-file','--diff3','-p',*names],capture_output=True)
        code=merged.returncode
        diagnostic=merged.stderr.decode('utf-8',errors='replace')
        if code==0:
            data=merged.stdout;action='auto_merged'
        else:
            action='conflict';conflict=out/'conflicts'/path;conflict.parent.mkdir(parents=True,exist_ok=True);conflict.write_bytes(merged.stdout)
    if action!='conflict' and data is not None:
        staged=out/'staged'/path;staged.parent.mkdir(parents=True,exist_ok=True);staged.write_bytes(data)
    results.append({**entry,'stagedAction':action,'mergeExit':code,'diagnostic':diagnostic,
                    'stagedSha256':hashlib.sha256(data).hexdigest() if data is not None else None})
(out/'staging-review.json').write_text(json.dumps({
    'mode':'Ignored preview only. Do not apply while B35319 is live; final migration numbers remain unassigned until latest Main freeze.',
    'baseMain':review['baseMain'],'latestMain':review['latestMain'],'taskPrimarySource':review['taskPrimarySource'],
    'entries':results},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'paths':len(results),'autoMerged':sum(row['stagedAction']=='auto_merged' for row in results),
                  'conflicts':[row['path'] for row in results if row['stagedAction']=='conflict'],'sourceChanged':False}))
