from pathlib import Path
import xml.etree.ElementTree as ET

ANCHORS=('server/src/main','server/src/test','server/legacy_migration','contracts')
FIXED=('server/pom.xml','assets/fonts/OFL.txt')

def source_paths(root):
    paths=set()
    for anchor in ANCHORS:
        paths.update(str(path.relative_to(root)).replace('\\','/') for path in (root/anchor).rglob('*')
                     if path.is_file() and '__pycache__' not in path.parts and path.suffix!='.pyc')
    paths.update(path for path in FIXED if (root/path).is_file())
    for path,compiled in external_resources(root):
        paths.add(path)
    return paths

def external_resources(root):
    ns={'m':'http://maven.apache.org/POM/4.0.0'}
    pom=ET.parse(root/'server/pom.xml').getroot()
    result=[]
    for resource in pom.findall('m:build/m:resources/m:resource',ns):
        directory=resource.findtext('m:directory','',ns)
        if not directory.startswith('../'):
            continue
        source=(root/'server'/directory).resolve()
        source.relative_to(root)
        includes=[entry.text for entry in resource.findall('m:includes/m:include',ns)]
        excludes=[entry.text for entry in resource.findall('m:excludes/m:exclude',ns)]
        selected=set(path for pattern in includes for path in source.glob(pattern) if path.is_file()) if includes else set(path for path in source.rglob('*') if path.is_file())
        selected-=set(path for pattern in excludes for path in source.glob(pattern) if path.is_file())
        target=resource.findtext('m:targetPath','',ns)
        for path in selected:
            compiled=Path('server/target-loading-main-f6e-metadata/classes')/target/path.relative_to(source)
            result.append((str(path.relative_to(root)).replace('\\','/'),str(compiled).replace('\\','/')))
    return sorted(result)
